def parse_block_log(script_path):
    """解析 /tmp/yz_assert_log.jsonl 中的 [BLOCK] 行，生成结构化 JSON 列表"""
    results = []
    if not os.path.exists(LOG_PATH):
        return results

    with open(LOG_PATH, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            # 当前日志格式: [BLOCK] fn=xxxx
            if line.startswith("[BLOCK] fn="):
                fn = line[len("[BLOCK] fn="):]
                results.append({
                    "script": script_path,
                    "type": "dynamic_call_block",
                    "fn_var_or_name": fn
                })
            elif line.startswith("[EVAL]"):
                # [EVAL] line=10 这种格式
                results.append({
                    "script": script_path,
                    "type": "eval_exec",
                    "raw": line
                })

    return results
