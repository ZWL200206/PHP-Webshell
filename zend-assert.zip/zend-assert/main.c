#include "zend_compile.h"
#include "zend_alloc.h"
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <stdint.h>

typedef bool zend_bool;

static HashTable tainted_table;
static HashTable local_tainted_table;
static HashTable local_sink_table;
static HashTable var_source_table;
static HashTable func_source_table;
static HashTable sink_table;
static HashTable sink_var_table;
static HashTable sink_func_table;
static HashTable webshell_table;
// 全局变量值表，用于跟踪已赋值的变量值（用于字符串表达式评估）
static HashTable var_value_table;
// 新增：可疑点表
static HashTable suspect_site_table;
// 新增：动态补充的调用图边（caller -> callee 集合）
static HashTable call_graph_extra;
// 新增：静态调用图（caller -> callee 集合）
static HashTable call_graph_static;
// 当前正在分析的文件名（在入口处赋值）
static zend_string *current_filename = NULL;
// 当前正在分析的函数名（用于记录调用者）
static zend_string *current_function_name = NULL;
static int tainted_count = 0;
static int local_tainted_count = 0;
static int local_sink_count = 0;
static int sink_count = 0;
static int sink_var_count = 0;
static int sink_func_count = 0;
static int webshell_count = 0;
static int webshell = 0;
static int local_webshell = 0;
static int func_source_count = 0;
// 动态断言命中计数（建议2）
static int dynamic_webshell_hit = 0;

/* 标记：需要动态解析的节点（静态分析无法确定） */
#define AST_NEED_DYNAMIC_RESOLVE 0x1000

static void local_taint_track(zend_ast *ast);
static inline zend_bool ast_kind_is_decl(zend_ast_kind kind);
static inline zend_bool ast_is_name(zend_ast *ast, zend_ast *parent, uint32_t i);
static inline zend_bool ast_is_type(zend_ast *ast, zend_ast *parent, uint32_t i);
static inline zend_bool ast_is_var_name(zend_ast *ast, zend_ast *parent, uint32_t i);
static inline zend_ast **ast_get_children(zend_ast *ast, uint32_t *count);
static void show_tokenname(zend_ast_kind kind);
static void traverse_ast(zend_ast *ast);
static void check_function(zend_ast* ast);
static void taint_propagate(zend_ast* ast, bool local);
static void taint_track(zend_ast *ast);
static void sink_propagate(zend_ast* ast, HashTable* var_table, int* var_count);
static void sink_track(zend_ast *ast, HashTable* var_table, int* var_count);
static void webshell_check(zend_ast *ast, bool local);
static int local_sink_check(zend_ast *ast);
static int has_sink_child(zend_ast *ast);
static void track_assignment(zend_ast *assign_ast, HashTable *var_table);
static void insert_assert_before(zend_ast **stmt_ptr, zend_arena **arena);
static void dynamic_function_analysis(zend_ast *ast);
static zend_string* evaluate_string_expression(zend_ast *expr);
static zend_string* evaluate_strtr_call(zend_ast *call_ast);
static zend_string* evaluate_concat_expression(zend_ast *expr);
static zend_string* evaluate_xor_expression(zend_ast *expr);
static zend_string* evaluate_or_expression(zend_ast *expr);
static zend_string* evaluate_and_expression(zend_ast *expr);
static zend_string* evaluate_string_call(zend_ast *call_ast);
static zend_string* evaluate_str_replace_call(zend_ast *call_ast);
static zend_string* evaluate_base64_decode_call(zend_ast *call_ast);
static zend_string* evaluate_url_decode_call(zend_ast *call_ast, zend_bool raw);
static zend_string* evaluate_rot13_call(zend_ast *call_ast);
static zend_bool is_known_sink_function(zend_string *func_name);
static void add_sink_var_from_assignment(zend_ast *var_node, zend_string *func_name);
// 栈结构，用于存储节点指针
typedef struct Stack {
    zend_ast** data;
    int top;
    int capacity;
} Stack;


// 初始化栈
void initStack(Stack *stack, int capacity) {
    //Stack* stack = (Stack*)malloc(sizeof(Stack));
    stack->data = (zend_ast**)malloc(sizeof(zend_ast*) * capacity);
    stack->top = 0;
    stack->capacity = capacity;
}

// 判断栈是否满
int isFull(Stack* stack) {
    return stack->top == stack->capacity;
}

// 入栈操作
void push(Stack* stack, zend_ast* item) {
    if (isFull(stack)) {
        // 栈已满，处理溢出情况
        return;
    }
    stack->data[stack->top++] = item;
}

// 判断栈是否空
int isEmpty(Stack* stack) {
    return stack->top == 0;
}

// 出栈操作
zend_ast* pop(Stack* stack) {
    if (isEmpty(stack)) {
        // 栈为空，处理下溢情况
        return NULL;
    }

    return stack->data[--stack->top];
}

// 识别ast节点是声明类型
static inline zend_bool ast_kind_is_decl(zend_ast_kind kind) {
        return kind == ZEND_AST_FUNC_DECL || kind == ZEND_AST_CLOSURE
                || kind == ZEND_AST_ARROW_FUNC
                || kind == ZEND_AST_METHOD || kind == ZEND_AST_CLASS;
}
// 判断当前节点是否代表一个名称
static inline zend_bool ast_is_name(zend_ast *ast, zend_ast *parent, uint32_t i) {
        if (!ast) {
                return 0;
        }
        if (ast->kind != ZEND_AST_ZVAL || Z_TYPE_P(zend_ast_get_zval(ast)) != IS_STRING) {
                return 0;
        }

        if (parent->kind == ZEND_AST_NAME_LIST) {
                return 1;
        }
        if (parent->kind == ZEND_AST_TYPE_INTERSECTION) {
                return 1;
        }
        if (parent->kind == ZEND_AST_TYPE_UNION) {
                return 1;
        }

        if (i == 0) {
                return parent->kind == ZEND_AST_CATCH || parent->kind == ZEND_AST_CLASS
                        || parent->kind == ZEND_AST_PARAM || parent->kind == ZEND_AST_METHOD_REFERENCE
                        || parent->kind == ZEND_AST_CALL || parent->kind == ZEND_AST_CONST
                        || parent->kind == ZEND_AST_NEW || parent->kind == ZEND_AST_STATIC_CALL
                        || parent->kind == ZEND_AST_CLASS_CONST || parent->kind == ZEND_AST_STATIC_PROP
                        || parent->kind == ZEND_AST_PROP_GROUP || parent->kind == ZEND_AST_CLASS_NAME
                        || parent->kind == ZEND_AST_ATTRIBUTE
                        ;
        }

        if (i == 2) {
                return parent->kind == ZEND_AST_CLASS_CONST_GROUP;
        }

        if (i == 1) {
                return parent->kind == ZEND_AST_INSTANCEOF;
        }
        if (i == 3) {
                return parent->kind == ZEND_AST_FUNC_DECL || parent->kind == ZEND_AST_CLOSURE
                        || parent->kind == ZEND_AST_ARROW_FUNC
                        || parent->kind == ZEND_AST_METHOD;
        }

        if (i == 4) {
                return parent->kind == ZEND_AST_CLASS;
        }

        return 0;
}

/* Assumes that ast_is_name is already true */
// 在已确定AST节点是名称的前提下，进一步判断该名称是否表示一个类型
static inline zend_bool ast_is_type(zend_ast *ast, zend_ast *parent, uint32_t i) {
        if (parent->kind == ZEND_AST_TYPE_INTERSECTION) {
                return 1;
        }
        if (parent->kind == ZEND_AST_TYPE_UNION) {
                return 1;
        }
        if (i == 0) {
                return parent->kind == ZEND_AST_PARAM
                        || parent->kind == ZEND_AST_PROP_GROUP
                        ;
        }
        if (i == 2) {
                return parent->kind == ZEND_AST_CLASS_CONST_GROUP;
        }

        if (i == 3) {
                return parent->kind == ZEND_AST_CLOSURE || parent->kind == ZEND_AST_FUNC_DECL
                        || parent->kind == ZEND_AST_ARROW_FUNC
                        || parent->kind == ZEND_AST_METHOD;
        }
        if (i == 4) {
                return parent->kind == ZEND_AST_CLASS;
        }
        return 0;
}
// 判断一个AST节点是否表示一个变量名称
static inline zend_bool ast_is_var_name(zend_ast *ast, zend_ast *parent, uint32_t i) {
        return (parent->kind == ZEND_AST_STATIC && i == 0)
                || (parent->kind == ZEND_AST_CATCH && i == 1 && ast != NULL);
}
// 获取给定AST节点的子节点，并返回子节点数组以及子节点的数量
static inline zend_ast **ast_get_children(zend_ast *ast, uint32_t *count) {
        if (!ast) {
                *count = 0;
                return NULL;
        }
        
        if (ast_kind_is_decl(ast->kind)) {
                zend_ast_decl *decl = (zend_ast_decl *) ast;
                *count = 5;
                return decl->child;
        } else if (zend_ast_is_list(ast)) {
                zend_ast_list *list = zend_ast_get_list(ast);
                if (!list) {
                        *count = 0;
                        return NULL;
                }
                // 限制 children 的最大值，防止越界访问
                uint32_t children_count = list->children;
                // 添加额外的安全检查：确保 children_count 是合理的值
                if (children_count == 0) {
                        *count = 0;
                        return NULL;
                }
                if (children_count > 1000) {
                        children_count = 1000;  // 增加限制以处理大型AST
                }
                *count = children_count;
                // 确保 child 数组指针有效
                if (!list->child) {
                        *count = 0;
                        return NULL;
                }
                return list->child;
        } else {
                *count = zend_ast_get_num_children(ast);
                // 限制 count 的最大值
                if (*count > 100) {
                        *count = 100;  // 增加限制以处理大型AST
                }
                return ast->child;
        }
}

static void show_tokenname(zend_ast_kind kind) {
  switch (kind) {
    case ZEND_AST_ZVAL:
      printf("ZEND_AST_ZVAL\n");
      break;
    case ZEND_AST_CONSTANT:
      printf("ZEND_AST_CONSTANT\n");
      break;
    case ZEND_AST_ZNODE:
      printf("ZEND_AST_ZNODE\n");
      break;
    case ZEND_AST_FUNC_DECL:
      printf("ZEND_AST_FUNC_DECL\n");
      break;
    case ZEND_AST_CLOSURE:
      printf("ZEND_AST_CLOSURE\n");
      break;
    case ZEND_AST_METHOD:
      printf("ZEND_AST_METHOD\n");
      break;
    case ZEND_AST_CLASS:
      printf("ZEND_AST_CLASS\n");
      break;
    case ZEND_AST_ARROW_FUNC:
      printf("ZEND_AST_ARROW_FUNC\n");
      break;
    case ZEND_AST_ARG_LIST:
      printf("ZEND_AST_ARG_LIST\n");
      break;
    case ZEND_AST_ARRAY:
      printf("ZEND_AST_ARRAY\n");
      break;
    case ZEND_AST_ENCAPS_LIST:
      printf("ZEND_AST_ENCAPS_LIST\n");
      break;
    case ZEND_AST_EXPR_LIST:
      printf("ZEND_AST_EXPR_LIST\n");
      break;
    case ZEND_AST_STMT_LIST:
      printf("ZEND_AST_STMT_LIST\n");
      break;
    case ZEND_AST_IF:
      printf("ZEND_AST_IF\n");
      break;
    case ZEND_AST_SWITCH_LIST:
      printf("ZEND_AST_SWITCH_LIST\n");
      break;
    case ZEND_AST_CATCH_LIST:
      printf("ZEND_AST_CATCH_LIST\n");
      break;
    case ZEND_AST_PARAM_LIST:
      printf("ZEND_AST_PARAM_LIST\n");
      break;
    case ZEND_AST_CLOSURE_USES:
      printf("ZEND_AST_CLOSURE_USES\n");
      break;
    case ZEND_AST_PROP_DECL:
      printf("ZEND_AST_PROP_DECL\n");
      break;
    case ZEND_AST_CONST_DECL:
      printf("ZEND_AST_CONST_DECL\n");
      break;
    case ZEND_AST_CLASS_CONST_DECL:
      printf("ZEND_AST_CLASS_CONST_DECL\n");
      break;
    case ZEND_AST_NAME_LIST:
      printf("ZEND_AST_NAME_LIST\n");
      break;
    case ZEND_AST_TRAIT_ADAPTATIONS:
      printf("ZEND_AST_TRAIT_ADAPTATIONS\n");
      break;
    case ZEND_AST_USE:
      printf("ZEND_AST_USE\n");
      break;
    case ZEND_AST_TYPE_UNION:
      printf("ZEND_AST_TYPE_UNION\n");
      break;
    case ZEND_AST_TYPE_INTERSECTION:
      printf("ZEND_AST_TYPE_INTERSECTION\n");
      break;
    case ZEND_AST_ATTRIBUTE_LIST:
      printf("ZEND_AST_ATTRIBUTE_LIST\n");
      break;
    case ZEND_AST_ATTRIBUTE_GROUP:
      printf("ZEND_AST_ATTRIBUTE_GROUP\n");
      break;
    case ZEND_AST_MATCH_ARM_LIST:
      printf("ZEND_AST_MATCH_ARM_LIST\n");
      break;
    case ZEND_AST_MODIFIER_LIST:
      printf("ZEND_AST_MODIFIER_LIST\n");
      break;
    case ZEND_AST_MAGIC_CONST:
      printf("ZEND_AST_MAGIC_CONST\n");
      break;
    case ZEND_AST_TYPE:
      printf("ZEND_AST_TYPE\n");
      break;
    case ZEND_AST_CONSTANT_CLASS:
      printf("ZEND_AST_CONSTANT_CLASS\n");
      break;
    case ZEND_AST_CALLABLE_CONVERT:
      printf("ZEND_AST_CALLABLE_CONVERT\n");
      break;
    case ZEND_AST_VAR:
      printf("ZEND_AST_VAR\n");
      break;
    case ZEND_AST_CONST:
      printf("ZEND_AST_CONST\n");
      break;
    case ZEND_AST_UNPACK:
      printf("ZEND_AST_UNPACK\n");
      break;
    case ZEND_AST_UNARY_PLUS:
      printf("ZEND_AST_UNARY_PLUS\n");
      break;
    case ZEND_AST_UNARY_MINUS:
      printf("ZEND_AST_UNARY_MINUS\n");
      break;
    case ZEND_AST_CAST:
      printf("ZEND_AST_CAST\n");
      break;
    case ZEND_AST_EMPTY:
      printf("ZEND_AST_EMPTY\n");
      break;
    case ZEND_AST_ISSET:
      printf("ZEND_AST_ISSET\n");
      break;
    case ZEND_AST_SILENCE:
      printf("ZEND_AST_SILENCE\n");
      break;
    case ZEND_AST_SHELL_EXEC:
      printf("ZEND_AST_SHELL_EXEC\n");
      break;
    case ZEND_AST_CLONE:
      printf("ZEND_AST_CLONE\n");
      break;
    case ZEND_AST_EXIT:
      printf("ZEND_AST_EXIT\n");
      break;
    case ZEND_AST_PRINT:
      printf("ZEND_AST_PRINT\n");
      break;
    case ZEND_AST_INCLUDE_OR_EVAL:
      printf("ZEND_AST_INCLUDE_OR_EVAL\n");
      break;
    case ZEND_AST_UNARY_OP:
      printf("ZEND_AST_UNARY_OP\n");
      break;
    case ZEND_AST_PRE_INC:
      printf("ZEND_AST_PRE_INC\n");
      break;
    case ZEND_AST_PRE_DEC:
      printf("ZEND_AST_PRE_DEC\n");
      break;
    case ZEND_AST_POST_INC:
      printf("ZEND_AST_POST_INC\n");
      break;
    case ZEND_AST_POST_DEC:
      printf("ZEND_AST_POST_DEC\n");
      break;
    case ZEND_AST_YIELD_FROM:
      printf("ZEND_AST_YIELD_FROM\n");
      break;
    case ZEND_AST_CLASS_NAME:
      printf("ZEND_AST_CLASS_NAME\n");
      break;
    case ZEND_AST_GLOBAL:
      printf("ZEND_AST_GLOBAL\n");
      break;
    case ZEND_AST_UNSET:
      printf("ZEND_AST_UNSET\n");
      break;
    case ZEND_AST_RETURN:
      printf("ZEND_AST_RETURN\n");
      break;
    case ZEND_AST_LABEL:
      printf("ZEND_AST_LABEL\n");
      break;
    case ZEND_AST_REF:
      printf("ZEND_AST_REF\n");
      break;
    case ZEND_AST_HALT_COMPILER:
      printf("ZEND_AST_HALT_COMPILER\n");
      break;
    case ZEND_AST_ECHO:
      printf("ZEND_AST_ECHO\n");
      break;
    case ZEND_AST_THROW:
      printf("ZEND_AST_THROW\n");
      break;
    case ZEND_AST_GOTO:
      printf("ZEND_AST_GOTO\n");
      break;
    case ZEND_AST_BREAK:
      printf("ZEND_AST_BREAK\n");
      break;
    case ZEND_AST_CONTINUE:
      printf("ZEND_AST_CONTINUE\n");
      break;
    case ZEND_AST_DIM:
      printf("ZEND_AST_DIM\n");
      break;
    case ZEND_AST_PROP:
      printf("ZEND_AST_PROP\n");
      break;
    case ZEND_AST_NULLSAFE_PROP:
      printf("ZEND_AST_NULLSAFE_PROP\n");
      break;
    case ZEND_AST_STATIC_PROP:
      printf("ZEND_AST_STATIC_PROP\n");
      break;
    case ZEND_AST_CALL:
      printf("ZEND_AST_CALL\n");
      break;
    case ZEND_AST_CLASS_CONST:
      printf("ZEND_AST_CLASS_CONST\n");
      break;
    case ZEND_AST_ASSIGN:
      printf("ZEND_AST_ASSIGN\n");
      break;
    case ZEND_AST_ASSIGN_REF:
      printf("ZEND_AST_ASSIGN_REF\n");
      break;
    case ZEND_AST_ASSIGN_OP:
      printf("ZEND_AST_ASSIGN_OP\n");
      break;
    case ZEND_AST_BINARY_OP:
      printf("ZEND_AST_BINARY_OP\n");
      break;
    case ZEND_AST_GREATER:
      printf("ZEND_AST_GREATER\n");
      break;
    case ZEND_AST_GREATER_EQUAL:
      printf("ZEND_AST_GREATER_EQUAL\n");
      break;
    case ZEND_AST_AND:
      printf("ZEND_AST_AND\n");
      break;
    case ZEND_AST_OR:
      printf("ZEND_AST_OR\n");
      break;
    case ZEND_AST_ARRAY_ELEM:
      printf("ZEND_AST_ARRAY_ELEM\n");
      break;
    case ZEND_AST_NEW:
      printf("ZEND_AST_NEW\n");
      break;
    case ZEND_AST_INSTANCEOF:
      printf("ZEND_AST_INSTANCEOF\n");
      break;
    case ZEND_AST_YIELD:
      printf("ZEND_AST_YIELD\n");
      break;
    case ZEND_AST_COALESCE:
      printf("ZEND_AST_COALESCE\n");
      break;
    case ZEND_AST_ASSIGN_COALESCE:
      printf("ZEND_AST_ASSIGN_COALESCE\n");
      break;
    case ZEND_AST_STATIC:
      printf("ZEND_AST_STATIC\n");
      break;
    case ZEND_AST_WHILE:
      printf("ZEND_AST_WHILE\n");
      break;
    case ZEND_AST_DO_WHILE:
      printf("ZEND_AST_DO_WHILE\n");
      break;
    case ZEND_AST_IF_ELEM:
      printf("ZEND_AST_IF_ELEM\n");
      break;
    case ZEND_AST_SWITCH:
      printf("ZEND_AST_SWITCH\n");
      break;
    case ZEND_AST_SWITCH_CASE:
      printf("ZEND_AST_SWITCH_CASE\n");
      break;
    case ZEND_AST_DECLARE:
      printf("ZEND_AST_DECLARE\n");
      break;
    case ZEND_AST_USE_TRAIT:
      printf("ZEND_AST_USE_TRAIT\n");
      break;
    case ZEND_AST_TRAIT_PRECEDENCE:
      printf("ZEND_AST_TRAIT_PRECEDENCE\n");
      break;
    case ZEND_AST_METHOD_REFERENCE:
      printf("ZEND_AST_METHOD_REFERENCE\n");
      break;
    case ZEND_AST_NAMESPACE:
      printf("ZEND_AST_NAMESPACE\n");
      break;
    case ZEND_AST_USE_ELEM:
      printf("ZEND_AST_USE_ELEM\n");
      break;
    case ZEND_AST_TRAIT_ALIAS:
      printf("ZEND_AST_TRAIT_ALIAS\n");
      break;
    case ZEND_AST_GROUP_USE:
      printf("ZEND_AST_GROUP_USE\n");
      break;
    case ZEND_AST_ATTRIBUTE:
      printf("ZEND_AST_ATTRIBUTE\n");
      break;
    case ZEND_AST_MATCH:
      printf("ZEND_AST_MATCH\n");
      break;
    case ZEND_AST_MATCH_ARM:
      printf("ZEND_AST_MATCH_ARM\n");
      break;
    case ZEND_AST_NAMED_ARG:
      printf("ZEND_AST_NAMED_ARG\n");
      break;
    case ZEND_AST_METHOD_CALL:
      printf("ZEND_AST_METHOD_CALL\n");
      break;
    case ZEND_AST_NULLSAFE_METHOD_CALL:
      printf("ZEND_AST_NULLSAFE_METHOD_CALL\n");
      break;
    case ZEND_AST_STATIC_CALL:
      printf("ZEND_AST_STATIC_CALL\n");
      break;
    case ZEND_AST_CONDITIONAL:
      printf("ZEND_AST_CONDITIONAL\n");
      break;
    case ZEND_AST_TRY:
      printf("ZEND_AST_TRY\n");
      break;
    case ZEND_AST_CATCH:
      printf("ZEND_AST_CATCH\n");
      break;
    case ZEND_AST_PROP_GROUP:
      printf("ZEND_AST_PROP_GROUP\n");
      break;
    case ZEND_AST_PROP_ELEM:
      printf("ZEND_AST_PROP_ELEM\n");
      break;
    case ZEND_AST_CONST_ELEM:
      printf("ZEND_AST_CONST_ELEM\n");
      break;
    case ZEND_AST_CLASS_CONST_GROUP:
      printf("ZEND_AST_CLASS_CONST_GROUP\n");
      break;
    case ZEND_AST_CONST_ENUM_INIT:
      printf("ZEND_AST_CONST_ENUM_INIT\n");
      break;
    case ZEND_AST_FOR:
      printf("ZEND_AST_FOR\n");
      break;
    case ZEND_AST_FOREACH:
      printf("ZEND_AST_FOREACH\n");
      break;
    case ZEND_AST_ENUM_CASE:
      printf("ZEND_AST_ENUM_CASE\n");
      break;
    case ZEND_AST_PARAM:
      printf("ZEND_AST_PARAM\n");
      break;

    default: break;
  }
}

// Initialize tainted and father properties of the ast.
// Track all nodes in the ast and set tainted = 0.
// Set the father of a node as the node direct point to it.

/* 从 eval 节点向上找，找到它所在的语句（stmt）以及语句列表（stmt_list） */
static zend_ast* find_stmt_and_list_for_node(zend_ast *node, zend_ast **out_stmt_list) {
    zend_ast *cur = node;
    zend_ast *parent = node ? node->father : NULL;

    while (parent) {
        if (parent->kind == ZEND_AST_STMT_LIST) {
            // cur 此时就是那条语句（可能是 eval 本身，也可能是 RETURN/ASSIGN 等）
            if (out_stmt_list) {
                *out_stmt_list = parent;
            }
            return cur;
        }
        cur = parent;
        parent = parent->father;
    }
    if (out_stmt_list) {
        *out_stmt_list = NULL;
    }
    return NULL;
}

static void traverse_ast(zend_ast *ast) {

  uint32_t count;
  Stack* stack = (Stack*)malloc(sizeof(Stack));
  initStack(stack, 10000);  // 增加栈大小以处理大型AST
  push(stack, ast);          // 将根节点加入栈

  while (!isEmpty(stack)) {

      zend_ast* current = pop(stack); // 从栈中取出一个节点
      if (!current) continue;
      if(current->kind > 1000){
         continue;
      }
      current->tainted = 0;
      show_tokenname(current->kind);

      /*
      if (current->kind == ZEND_AST_ZVAL) {
        zval *zv = zend_ast_get_zval(current);
        if (Z_TYPE_P(zv) == IS_STRING) {
          printf("zval is %s\n", Z_STRVAL_P(zv));
        }
      }
      */

      zend_ast **ast_child = ast_get_children(current,&count);
      if (!ast_child) {
          continue;  // 如果无法获取子节点，跳过
      }
      
      // 限制 count 的最大值，防止越界访问
      if (count > 1000) {
          count = 1000;  // 增加限制以处理大型AST
      }

      // 关键修复：对于非 list 节点，需要特别小心处理
      // 对于使用 struct hack 的节点，ast_child 指向的是节点内部的 child 数组
      // 我们需要确保不会访问超出实际分配范围的内存
      uint32_t actual_count = count;
      if (!zend_ast_is_list(current)) {
          // 对于非 list 节点，使用 zend_ast_get_num_children 获取实际的子节点数量
          uint32_t num_children = zend_ast_get_num_children(current);
          if (num_children < actual_count) {
              actual_count = num_children;  // 使用较小的值
          }
      }

      for (int i = 0; i < actual_count; i++) {
          int reverse_i = actual_count - i - 1;
          if (reverse_i < 0 || reverse_i >= actual_count) {
              continue;  // 防止数组越界
          }
          
          // 对于所有节点类型，都使用 ast_child 指针，但添加边界检查
          zend_ast *child = NULL;
          if (reverse_i < actual_count && ast_child != NULL) {
              child = ast_child[reverse_i];
          }
          
          if (child != NULL) {
              // 验证指针有效性：检查节点是否在有效内存范围内
              // 添加额外的安全检查：确保 child 指针对齐且指向有效内存
              // 检查指针是否对齐到至少 4 字节边界（大多数系统要求）
              if (((uintptr_t)child & 0x3) != 0) {
                  continue;  // 指针未对齐，可能是无效指针
              }
              
              // 尝试安全地读取 kind 字段
              zend_ast_kind kind = child->kind;
              if(kind == 0 || kind > 1000){
                   continue;  // 跳过无效的节点类型
              }
              // 只有在 kind 有效时才设置 father 和入栈
              child->father = current;
              push(stack, child); // 将非空子节点加入栈
          }
      }
  }
  free(stack->data); // 释放栈内存
  free(stack);

}

static void check_function(zend_ast* ast) {
  uint32_t count;
  uint32_t count1;

  if (ast->kind == ZEND_AST_FUNC_DECL) {
    zend_ast** ast_child = ast_get_children(ast,&count);
    zend_string* func_name = ((zend_ast_decl *)ast)->name;
    printf("func name is %s\n", func_name->val);
    zend_ast* param_node = NULL;
    zend_ast* stmt_node = NULL;

    
    for (int i = 0;i < count;i++) {
      if (ast_child[i] != NULL) {
        if (ast_child[i]->kind == ZEND_AST_PARAM_LIST) param_node = ast_child[i];
        if (ast_child[i]->kind == ZEND_AST_STMT_LIST) stmt_node = ast_child[i];
      }
    }

    if (param_node != NULL) {
      show_tokenname(param_node->kind);
      zend_ast **param_list = ast_get_children(param_node,&count1);
    }
    printf("hash clean start\n");
    zend_hash_clean(&local_tainted_table);
    local_tainted_count = 0;

    printf("local_taint_track start\n");
    if (stmt_node != NULL) {
      show_tokenname(stmt_node->kind);
      local_taint_track(stmt_node);
      local_webshell = 0;
      webshell_check(stmt_node, 1);
      printf("local_webshell = %d\n", local_webshell);
      if (local_webshell == 0) {

        zend_ast **param_list = NULL;
        count = 0;

        if (param_node != NULL) {
          show_tokenname(param_node->kind);
          param_list = ast_get_children(param_node,&count);
        }
        printf("hash clean start\n");
        zend_hash_clean(&local_tainted_table);
        local_tainted_count = 0;

        traverse_ast(ast);
        local_webshell = 0;

        printf("param count is %d\n", count);

        for (int i = 0;i < count;i++) {
          zend_ast* name_node = param_list[i]->child[1];
          show_tokenname(name_node->kind);

          zval *zv = zend_ast_get_zval(name_node);
          if (Z_TYPE_P(zv) == IS_STRING) {
            zend_string *var_name = zend_ast_get_str(name_node);
            printf("the tainted param name is %s\n", var_name->val);
            if (!zend_hash_exists(&local_tainted_table, var_name)) {
              zval local_taint_val;
              ZVAL_LONG(&local_taint_val, local_tainted_count);
              local_tainted_count++;
              zend_hash_add(&local_tainted_table, var_name, &local_taint_val);
            }
          }
        }

        local_taint_track(stmt_node);
        webshell_check(stmt_node, 1);
        printf("local_webshell = %d\n", local_webshell);
        if (local_webshell > 0) {
          zval sink_val;
          ZVAL_LONG(&sink_val, sink_count);
          sink_count++;
          printf("add func to sink table\n");
          zend_hash_add(&sink_table, func_name, &sink_val);
        } else {
          zend_hash_clean(&local_sink_table);
          local_sink_count = 0;
          printf("local sink track start\n");
          sink_track(stmt_node, &local_sink_table, &local_sink_count);
          printf("check local sink start\n");
          if (local_sink_check(stmt_node)) {
            zval sink_func_val;
            ZVAL_LONG(&sink_func_val, sink_func_count);
            sink_func_count++;
            printf("add func to sink func table\n");
            zend_hash_add(&sink_func_table, func_name, &sink_func_val);
          }
        }


      } else {
        if (local_webshell == 1) {
          zval webshell_val;
          ZVAL_LONG(&webshell_val, webshell_count);
          webshell_count++;
          printf("add func to webshell table\n");
          zend_hash_add(&webshell_table, func_name, &webshell_val);
        }

        if (local_webshell == 2) {
          zval func_source_val;
          ZVAL_LONG(&func_source_val, func_source_count);
          func_source_count++;
          printf("add func to func source table\n");
          zend_hash_add(&func_source_table, func_name, &func_source_val);
        }

      }
    }
  } 
}

static void taint_propagate(zend_ast* ast, bool local) {
  zend_ast *father_node = ast->father;
  while (father_node != NULL) {
    father_node->tainted = 1;
    show_tokenname(father_node->kind);

    // 如果父节点是 ARG_LIST，继续向上传播
    if (father_node->kind == ZEND_AST_ARG_LIST) {
      // ARG_LIST 的父节点应该是 CALL，继续传播
    }

    if (father_node->kind == ZEND_AST_CALL) { 
      zend_ast *next_node = father_node->child[0];
      if (next_node) {
        next_node->tainted = 1;
      }
      // 标记 CALL 节点本身为污点（如果参数是污点）
      // 这样 webshell_check 就能检测到
    }

    // If the tainted node in the right side of an assign statement,
    // add the variable in the left side to tainted table.
    if (father_node->kind == ZEND_AST_ASSIGN) {
      zend_ast *var_node = father_node->child[0];
      if (var_node && var_node->kind == ZEND_AST_DIM) {
        var_node = var_node->child[0];
        if (!var_node) continue;  // 防止空指针
      }
      if (var_node && var_node->kind == ZEND_AST_VAR) {
         zend_ast *name_node = var_node->child[0];
         if (name_node && name_node->kind == ZEND_AST_ZVAL) {
           zval *zv = zend_ast_get_zval(name_node);
           if (Z_TYPE_P(zv) == IS_STRING) {
            zend_string *var_name = zend_ast_get_str(name_node);
            printf("the tainted var name is %s\n", var_name->val);
            if (local) {
              if (!zend_hash_exists(&local_tainted_table, var_name)) {
                zval local_taint_val;
                ZVAL_LONG(&local_taint_val, local_tainted_count);
                local_tainted_count++;
                zend_hash_add(&local_tainted_table, var_name, &local_taint_val);
              }

            } else {
              if (!zend_hash_exists(&tainted_table, var_name)) {
                zval taint_val;
                ZVAL_LONG(&taint_val, tainted_count);
                tainted_count++;
                zend_hash_add(&tainted_table, var_name, &taint_val);
              }
            }
          }
          
        }
      }
    }

    if (father_node->kind == ZEND_AST_METHOD_CALL) {
      zend_ast *var_node = father_node->child[0];
      if (var_node && var_node->kind == ZEND_AST_VAR) {
         zend_ast *name_node = var_node->child[0];
         if (name_node && name_node->kind == ZEND_AST_ZVAL) {
            zval *zv = zend_ast_get_zval(name_node);
            if (Z_TYPE_P(zv) == IS_STRING) {
             zend_string *var_name = zend_ast_get_str(name_node);
             printf("the tainted class var name is %s\n", var_name->val);
             if (local) {
               if (!zend_hash_exists(&local_tainted_table, var_name)) {
                 zval local_taint_val;
                 ZVAL_LONG(&local_taint_val, local_tainted_count);
                 local_tainted_count++;
                 zend_hash_add(&local_tainted_table, var_name, &local_taint_val);
               }
 
             } else {
               if (!zend_hash_exists(&tainted_table, var_name)) {
                 zval taint_val;
                 ZVAL_LONG(&taint_val, tainted_count);
                 tainted_count++;
                 zend_hash_add(&tainted_table, var_name, &taint_val);
               }
             }
           }
         }
       }
    }


    if (father_node->kind == ZEND_AST_FOREACH) {
      uint32_t count;
      zend_ast **ast_child = ast_get_children(father_node,&count);
      for (int i = 0;i < count;i++) {
        zend_ast *var_node = father_node->child[i];
        if (var_node != NULL) {
          if (var_node->kind == ZEND_AST_VAR) {
            zend_ast *name_node = var_node->child[0];
            if (name_node && name_node->kind == ZEND_AST_ZVAL) {
              zval *zv = zend_ast_get_zval(name_node);
              if (Z_TYPE_P(zv) == IS_STRING) {
                zend_string *var_name = zend_ast_get_str(name_node);
                printf("the tainted var name is %s\n", var_name->val);
                if (local) {
                  if (!(zend_hash_exists(&var_source_table, var_name) || zend_hash_exists(&local_tainted_table, var_name))) {            
                    zval local_taint_val;
                    ZVAL_LONG(&local_taint_val, local_tainted_count);
                    local_tainted_count++;
                    zend_hash_add(&local_tainted_table, var_name, &local_taint_val);
                  }

                } else {
                  if (!(zend_hash_exists(&var_source_table, var_name) || zend_hash_exists(&tainted_table, var_name))) {
                    zval taint_val;
                    ZVAL_LONG(&taint_val, tainted_count);
                    tainted_count++;
                    zend_hash_add(&tainted_table, var_name, &taint_val);
                  }
                }
              }
            }
          }
        }
      }
    }

    father_node = father_node->father;
  }

}

// Firstly set the variables defined in source table (such as _POST, _GET) or in tainted table to tainted.
// Then, track the nodes on the path bewteen root and the tainted node and set them to tainted.
// Finally, if the statement is an assign statement, add the defined variable to the tainted table.
static void taint_track(zend_ast *ast) {

  uint32_t count;
  Stack* stack = (Stack*)malloc(sizeof(Stack));
  initStack(stack, 10000);  // 增加栈大小以处理大型AST
  push(stack, ast);          // 将根节点加入栈

  while (!isEmpty(stack)) {

    zend_ast* current = pop(stack); // 从栈中取出一个节点
    //printf("%d ", current->kind);  // 访问当前节点

    if (current->kind == ZEND_AST_VAR) {
      zend_ast *next_node = current->child[0];
      if (next_node && next_node->kind == ZEND_AST_ZVAL) {
        zval *zv = zend_ast_get_zval(next_node);
        if (zv && Z_TYPE_P(zv) == IS_STRING) {
          zend_string *var_name = zend_ast_get_str(next_node);
          // Check whether the variable is in source table or in tainted table or not.
          if ((zend_hash_exists(&var_source_table, var_name)) || (zend_hash_exists(&tainted_table, var_name))){
            printf("the var name is %s\n", Z_STRVAL_P(zv));
            next_node->tainted = 1; // set node to tainted


            // Set all nodes on the path between root to the tainted node to tainted.
            taint_propagate(next_node, 0);
          }
        }
      }
    }

    // 处理数组访问，如 $_GET['cmd']、$_POST['key'] 等
    if (current->kind == ZEND_AST_DIM) {
      zend_ast *var_node = current->child[0];
      if (var_node && var_node->kind == ZEND_AST_VAR) {
        zend_ast *name_node = var_node->child[0];
        if (name_node && name_node->kind == ZEND_AST_ZVAL) {
          zval *zv = zend_ast_get_zval(name_node);
          if (zv && Z_TYPE_P(zv) == IS_STRING) {
            zend_string *var_name = zend_ast_get_str(name_node);
            // 检查数组的基变量（如 $_GET、$_POST）是否在 source table 中
            if (zend_hash_exists(&var_source_table, var_name)) {
              printf("检测到数组访问污点源: %s[...] (var_name=%s)\n", Z_STRVAL_P(zv), Z_STRVAL_P(zv));
              // 标记整个 DIM 节点为污点
              current->tainted = 1;
              // 向上传播污点
              taint_propagate(current, 0);
            } else if (zend_hash_exists(&tainted_table, var_name)) {
              // 如果数组变量本身在 tainted_table 中，也标记为污点
              printf("检测到数组访问污点变量: %s[...] (var_name=%s)\n", Z_STRVAL_P(zv), Z_STRVAL_P(zv));
              current->tainted = 1;
              taint_propagate(current, 0);
            }
          }
        }
      }
    }

    if (current->kind == ZEND_AST_CALL) {
      zend_ast *next_node = current->child[0];
      if (next_node && next_node->kind == ZEND_AST_ZVAL) {
        zval *zv = zend_ast_get_zval(next_node);
        if (Z_TYPE_P(zv) == IS_STRING) {
          zend_string *func_name = zend_ast_get_str(next_node);
          // Check whether the variable is in source table or in tainted table or not.
          if ((zend_hash_exists(&func_source_table, func_name))){
            printf("the func name is %s\n", Z_STRVAL_P(zv));
            next_node->tainted = 1; // set node to tainted


            // Set all nodes on the path between root to the tainted node to tainted.
            taint_propagate(next_node, 0);
          }
        }
      }
    }


    zend_ast **ast_child = ast_get_children(current,&count);

    for (int i = 0; i < count; i++) { // 假设最多10个子节点
        int reverse_i = count - i - 1;
        if (ast_child[reverse_i] != NULL) {
            if (current->kind == ZEND_AST_ASSIGN) {
              i = 1;
              //printf("count is %d\n", count);
              zend_ast *var_node = current->child[0];
              //printf("var node kind is %d, %d\n", var_node->kind, ZEND_AST_VAR);
              if (var_node && var_node->kind == ZEND_AST_VAR) {
                zend_ast *next_node = var_node->child[0];
                //printf("next node kind is %d, %d\n", next_node->kind, ZEND_AST_ZVAL);
                if (next_node && next_node->kind == ZEND_AST_ZVAL) {
                  zval *zv = zend_ast_get_zval(next_node);
                  if (zv && Z_TYPE_P(zv) == IS_STRING) {
                    printf("the var name is %s\n", Z_STRVAL_P(zv));
                    zend_string *var_name = zend_ast_get_str(next_node);
                    if (var_name && zend_hash_exists(&tainted_table, var_name)) {
                      printf("the santized var is %s\n", var_name->val);
                      zend_hash_del(&tainted_table, var_name);
                    }
                  }
                }
              }

            }

            show_tokenname(ast_child[reverse_i]->kind);
            if (ast_child[reverse_i]->kind == ZEND_AST_FUNC_DECL) {
              printf("here\n");
              check_function(ast_child[reverse_i]);
              printf("there\n");
            } else {
              push(stack, ast_child[reverse_i]); // 将非空子节点加入栈
            }
        }
    }
  }
  free(stack->data); // 释放栈内存
  free(stack);

}

// Firstly set the variables defined in source table (such as _POST, _GET) or in tainted table to tainted.
// Then, track the nodes on the path bewteen root and the tainted node and set them to tainted.
// Finally, if the statement is an assign statement, add the defined variable to the tainted table.
static void local_taint_track(zend_ast *ast) {

  uint32_t count;
  Stack* stack = (Stack*)malloc(sizeof(Stack));
  initStack(stack, 10000);  // 增加栈大小以处理大型AST
  push(stack, ast);          // 将根节点加入栈

  while (!isEmpty(stack)) {

    zend_ast* current = pop(stack); // 从栈中取出一个节点
    //printf("%d ", current->kind);  // 访问当前节点

    if (current->kind == ZEND_AST_VAR) {
      zend_ast *next_node = current->child[0];
      if (next_node && next_node->kind == ZEND_AST_ZVAL) {
        zval *zv = zend_ast_get_zval(next_node);
        if (zv && Z_TYPE_P(zv) == IS_STRING) {
          zend_string *var_name = zend_ast_get_str(next_node);
          // Check whether the variable is in source table or in tainted table or not.
          if ((zend_hash_exists(&var_source_table, var_name)) || (zend_hash_exists(&local_tainted_table, var_name))){
            printf("the var name is %s\n", Z_STRVAL_P(zv));
            next_node->tainted = 1; // set node to tainted


            // Set all nodes on the path between root to the tainted node to tainted.
            taint_propagate(next_node, 1);
          }
        }
      }
    }

    // 处理数组访问，如 $_GET['cmd']、$_POST['key'] 等（本地污点追踪）
    if (current->kind == ZEND_AST_DIM) {
      zend_ast *var_node = current->child[0];
      if (var_node && var_node->kind == ZEND_AST_VAR) {
        zend_ast *name_node = var_node->child[0];
        if (name_node && name_node->kind == ZEND_AST_ZVAL) {
          zval *zv = zend_ast_get_zval(name_node);
          if (zv && Z_TYPE_P(zv) == IS_STRING) {
            zend_string *var_name = zend_ast_get_str(name_node);
            // 检查数组的基变量（如 $_GET、$_POST）是否在 source table 中
            if (zend_hash_exists(&var_source_table, var_name)) {
              printf("检测到数组访问污点源: %s[...] (var_name=%s, local)\n", Z_STRVAL_P(zv), Z_STRVAL_P(zv));
              // 标记整个 DIM 节点为污点
              current->tainted = 1;
              // 向上传播污点
              taint_propagate(current, 1);
            } else if (zend_hash_exists(&local_tainted_table, var_name) || zend_hash_exists(&tainted_table, var_name)) {
              // 如果数组变量本身在 tainted_table 中，也标记为污点
              printf("检测到数组访问污点变量: %s[...] (var_name=%s, local)\n", Z_STRVAL_P(zv), Z_STRVAL_P(zv));
              current->tainted = 1;
              taint_propagate(current, 1);
            }
          }
        }
      }
    }

    if (current->kind == ZEND_AST_CALL) {
      zend_ast *next_node = current->child[0];
      if (next_node && next_node->kind == ZEND_AST_ZVAL) {
        zval *zv = zend_ast_get_zval(next_node);
        if (Z_TYPE_P(zv) == IS_STRING) {
          zend_string *func_name = zend_ast_get_str(next_node);
          // Check whether the variable is in source table or in tainted table or not.
          if ((zend_hash_exists(&func_source_table, func_name))){
            printf("the func name is %s\n", Z_STRVAL_P(zv));
            next_node->tainted = 1; // set node to tainted


            // Set all nodes on the path between root to the tainted node to tainted.
            taint_propagate(next_node, 1);
          }
        }
      }
    }


    zend_ast **ast_child = ast_get_children(current,&count);

    for (int i = 0; i < count; i++) { // 假设最多10个子节点
        int reverse_i = count - i - 1;
        if (ast_child[reverse_i] != NULL) {
            if (current->kind == ZEND_AST_ASSIGN) {
              i = 1;
              //printf("count is %d\n", count);
              zend_ast *var_node = current->child[0];
              //printf("var node kind is %d, %d\n", var_node->kind, ZEND_AST_VAR);
              if (var_node && var_node->kind == ZEND_AST_VAR) {
                zend_ast *next_node = var_node->child[0];
                //printf("next node kind is %d, %d\n", next_node->kind, ZEND_AST_ZVAL);
                if (next_node && next_node->kind == ZEND_AST_ZVAL) {
                  zval *zv = zend_ast_get_zval(next_node);
                  printf("the var name is %s\n", Z_STRVAL_P(zv));
                  if (zv && Z_TYPE_P(zv) == IS_STRING) {
                    zend_string *var_name = zend_ast_get_str(next_node);
                    if (var_name && zend_hash_exists(&local_tainted_table, var_name)) {
                      printf("the santized var is %s\n", var_name->val);
                      zend_hash_del(&local_tainted_table, var_name);
                    }
                  }
                }
              }

            }

            push(stack, ast_child[reverse_i]); // 将非空子节点加入栈
        }
    }
  }
  free(stack->data); // 释放栈内存
  free(stack);

}

static void sink_propagate(zend_ast* ast, HashTable* var_table, int* var_count) {
  zend_ast *father_node = ast->father;
  while (father_node != NULL) {
    //father_node->tainted = 1;
    // If the tainted node in the right side of an assign statement,
    // add the variable in the left side to tainted table.
    if (father_node->kind == ZEND_AST_ASSIGN) {
      zend_ast *var_node = father_node->child[0];
      if (var_node && var_node->kind == ZEND_AST_DIM) {
        var_node = var_node->child[0];
        if (!var_node) return;  // 防止空指针
      }
      if (var_node && var_node->kind == ZEND_AST_VAR) {
         zend_ast *name_node = var_node->child[0];
         if (name_node) {
           zend_string *var_name = zend_ast_get_str(name_node);
           if (var_name) {
             printf("the sink var name is %s\n", var_name->val);
             if (!zend_hash_exists(var_table, var_name)) {
               zval sink_var_val;
               ZVAL_LONG(&sink_var_val, *var_count);
               (*var_count)++;
               zend_hash_add(var_table, var_name, &sink_var_val);
             }
           }
         }
       }
    }

    father_node = father_node->father;
  }

}

// Firstly set the variables defined in source table (such as _POST, _GET) or in tainted table to tainted.
// Then, track the nodes on the path bewteen root and the tainted node and set them to tainted.
// Finally, if the statement is an assign statement, add the defined variable to the tainted table.
static void sink_track(zend_ast *ast, HashTable* var_table, int* var_count) {

  uint32_t count;
  Stack* stack = (Stack*)malloc(sizeof(Stack));
  initStack(stack, 10000);  // 增加栈大小以处理大型AST
  push(stack, ast);          // 将根节点加入栈

  while (!isEmpty(stack)) {

    zend_ast* current = pop(stack); // 从栈中取出一个节点
    //printf("%d ", current->kind);  // 访问当前节点

    if (current->kind == ZEND_AST_ZVAL) {
      zval *zv = zend_ast_get_zval(current);
      if (Z_TYPE_P(zv) == IS_STRING) {
        zend_string *var_val = zend_ast_get_str(current);
        if (zend_hash_exists(&sink_table, var_val)) {
          printf("the sink var is %s\n", var_val->val);
          sink_propagate(current, var_table, var_count);
        }
      }
    }

    if (current->kind == ZEND_AST_VAR) {
      zend_ast *next_node = current->child[0];
      if (next_node && next_node->kind == ZEND_AST_ZVAL) {
        zval *zv = zend_ast_get_zval(next_node);
        if (zv) {
          printf("the var name is %s\n", Z_STRVAL_P(zv));
          if (Z_TYPE_P(zv) == IS_STRING) {
            zend_string *var_name = zend_ast_get_str(next_node);
            if (var_name && zend_hash_exists(var_table, var_name)) {
              printf("the sink var is %s\n", var_name->val);
              sink_propagate(current, var_table, var_count);
            }
          }
        }
      }
    }

    if (current->kind == ZEND_AST_CALL) {
      zend_ast *next_node = current->child[0];
      if (next_node && next_node->kind == ZEND_AST_ZVAL) {
        zval *zv = zend_ast_get_zval(next_node);
        printf("the var name is %s\n", Z_STRVAL_P(zv));
        if (Z_TYPE_P(zv) == IS_STRING) {
          zend_string *func_name = zend_ast_get_str(next_node);
          if (zend_hash_exists(&sink_func_table, func_name)) {
            printf("the sink func is %s\n", func_name->val);
            sink_propagate(current, var_table, var_count);
          }
        }
      }
    }

    zend_ast **ast_child = ast_get_children(current,&count);

    for (int i = 0; i < count; i++) { // 假设最多10个子节点
        int reverse_i = count - i - 1;
        if (ast_child[reverse_i] != NULL) {
            if (current->kind == ZEND_AST_ASSIGN) {
              i = 1;
              zend_ast *var_node = current->child[0];
              zend_ast *expr_node = current->child[1];
              //printf("var node kind is %d, %d\n", var_node->kind, ZEND_AST_VAR);
              if (var_node && var_node->kind == ZEND_AST_VAR) {
                zend_ast *next_node = var_node->child[0];
                //printf("next node kind is %d, %d\n", next_node->kind, ZEND_AST_ZVAL);
                if (next_node && next_node->kind == ZEND_AST_ZVAL) {
                  zval *zv = zend_ast_get_zval(next_node);
                  if (zv && Z_TYPE_P(zv) == IS_STRING) {
                    printf("the var name is %s\n", Z_STRVAL_P(zv));
                    zend_string *var_name = zend_ast_get_str(next_node);
                    
                    // 检查右侧表达式是否评估为危险函数名
                    if (expr_node) {
                      zend_string *resolved = evaluate_string_expression(expr_node);
                      if (resolved) {
                        printf("评估赋值表达式结果: %s\n", ZSTR_VAL(resolved));
                        
                        // 将变量值存储到 var_value_table 中（用于后续表达式评估）
                        zval var_val_zv;
                        ZVAL_STR(&var_val_zv, zend_string_copy(resolved));
                        zend_hash_update(&var_value_table, var_name, &var_val_zv);
                        
                        if (is_known_sink_function(resolved)) {
                          // 如果变量已经在 sink_var_table 中，保留它
                          // 如果不在，添加它
                          if (!zend_hash_exists(var_table, var_name)) {
                            zval sink_var_val;
                            ZVAL_LONG(&sink_var_val, *var_count);
                            (*var_count)++;
                            zend_hash_add(var_table, var_name, &sink_var_val);
                            printf("检测到危险函数变量赋值: $%s = %s，已添加到 sink_var_table\n", 
                                   var_name->val, ZSTR_VAL(resolved));
                          } else {
                            printf("变量 $%s 被重新赋值为危险函数 %s，保留在 sink_var_table\n", 
                                   var_name->val, ZSTR_VAL(resolved));
                          }
                        } else {
                          // 如果右侧不是危险函数，且变量在 sink_var_table 中，删除它
                          if (zend_hash_exists(var_table, var_name)) {
                            printf("变量 $%s 被重新赋值为非危险函数 %s，从 sink_var_table 中删除\n", 
                                   var_name->val, ZSTR_VAL(resolved));
                            zend_hash_del(var_table, var_name);
                          }
                        }
                        zend_string_release(resolved);
                      }
                    }
                  }
                }
              }

            }
            push(stack, ast_child[reverse_i]); // 将非空子节点加入栈
        }
    }
  }
  free(stack->data); // 释放栈内存
  free(stack);

}


// Firstly set the variables defined in source table (such as _POST, _GET) or in tainted table to tainted.
// Then, track the nodes on the path bewteen root and the tainted node and set them to tainted.
// Finally, if the statement is an assign statement, add the defined variable to the tainted table.
static int has_sink_child(zend_ast *ast) {

  uint32_t count;
  Stack* stack = (Stack*)malloc(sizeof(Stack));
  initStack(stack, 10000);  // 增加栈大小以处理大型AST
  push(stack, ast);          // 将根节点加入栈

  printf("has sink child start\n");

  while (!isEmpty(stack)) {

    zend_ast* current = pop(stack); // 从栈中取出一个节点
    //printf("%d ", current->kind);  // 访问当前节点

    if (current->kind == ZEND_AST_ZVAL) {
      zval *zv = zend_ast_get_zval(current);
      if (Z_TYPE_P(zv) == IS_STRING) {
        zend_string *var_val = zend_ast_get_str(current);
        if (zend_hash_exists(&sink_table, var_val)) {
          printf("the sink var is %s\n", var_val->val);
          return 1;
        }
      }
    }

    if (current->kind == ZEND_AST_VAR) {
      zend_ast *next_node = current->child[0];
      if (next_node && next_node->kind == ZEND_AST_ZVAL) {
        zval *zv = zend_ast_get_zval(next_node);
        if (zv && Z_TYPE_P(zv) == IS_STRING) {
          printf("the var name is %s\n", Z_STRVAL_P(zv));
          zend_string *var_name = zend_ast_get_str(next_node);
          if (var_name && zend_hash_exists(&local_sink_table, var_name)) {
            printf("the sink var is %s\n", var_name->val);
            return 1;
          }
        }
      }
    }

    if (current->kind == ZEND_AST_CALL) {
      zend_ast *next_node = current->child[0];
      if (next_node && next_node->kind == ZEND_AST_ZVAL) {
        zval *zv = zend_ast_get_zval(next_node);
        if (zv && Z_TYPE_P(zv) == IS_STRING) {
          printf("the var name is %s\n", Z_STRVAL_P(zv));
          zend_string *func_name = zend_ast_get_str(next_node);
          if (func_name && zend_hash_exists(&sink_func_table, func_name)) {
            printf("the sink func is %s\n", func_name->val);
            return 1;
          }
        }
      }
    }

    zend_ast **ast_child = ast_get_children(current,&count);

    for (int i = 0; i < count; i++) { // 假设最多10个子节点
        int reverse_i = count - i - 1;
        if (ast_child[reverse_i] != NULL) {
            push(stack, ast_child[reverse_i]); // 将非空子节点加入栈
        }
    }
  }
  free(stack->data); // 释放栈内存
  free(stack);

  return 0;
}

// Check whether the input script is a webshell or not.
// If there is a node which is a sink function or statement and tainted,
// the input script is a webshell.
static int local_sink_check(zend_ast *ast) {
  uint32_t count;
  Stack* stack = (Stack*)malloc(sizeof(Stack));
  initStack(stack, 10000);  // 增加栈大小以处理大型AST
  push(stack, ast);          // 将根节点加入栈
          
  while (!isEmpty(stack)) {
        
      zend_ast* current = pop(stack); // 从栈中取出一个节点

      if (current->kind == ZEND_AST_RETURN) {
        printf("current node is return\n");
        if (has_sink_child(current)) {
          return 1;
        }
      }
   
      zend_ast **ast_child = ast_get_children(current,&count);

      for (int i = 0; i < count; i++) { // 假设最多10个子节点
          int reverse_i = count - i - 1;
          if (ast_child[reverse_i] != NULL) {
              //if (ast_child[reverse_i]->kind != ZEND_AST_RETURN)
                push(stack, ast_child[reverse_i]); // 将非空子节点加入栈
          }
      }
  }
  free(stack->data); // 释放栈内存
  free(stack);

  return 0;
}

// Check whether the input script is a webshell or not.
// If there is a node which is a sink function or statement and tainted,
// the input script is a webshell.
static void webshell_check(zend_ast *ast, bool local) {
  uint32_t count;
  Stack* stack = (Stack*)malloc(sizeof(Stack));
  initStack(stack, 10000);  // 增加栈大小以处理大型AST
  push(stack, ast);          // 将根节点加入栈

  while (!isEmpty(stack)) {
      
      zend_ast* current = pop(stack); // 从栈中取出一个节点

    // Check whether the node is a sink and tainted.
    // eval($_POST['cmd'])
    // include $_POST['file']
    // require $_FILES['test']

    if ((current->kind == ZEND_AST_RETURN) && (current->tainted == 1) && (local)) {
      local_webshell = 2;
    }

    // 检测 eval() 调用
    // 即使参数无法静态求值，eval() 调用本身也是危险的
    if (current->kind == ZEND_AST_INCLUDE_OR_EVAL) {
      printf("DEBUG: 检测到 ZEND_AST_INCLUDE_OR_EVAL 节点 (attr=%d, tainted=%d)\n", current->attr, current->tainted);
      // 检查是否是 eval（而不是 include/require）
      // ZEND_AST_INCLUDE_OR_EVAL 的 attr 字段可以区分类型
      // ZEND_EVAL = (1<<0) = 1, ZEND_INCLUDE = (1<<1) = 2, ZEND_INCLUDE_ONCE = (1<<2) = 4, 
      // ZEND_REQUIRE = (1<<3) = 8, ZEND_REQUIRE_ONCE = (1<<4) = 16
      // 所有 eval() 调用都应该被检测，无论参数是否可静态求值
      if (current->attr == ZEND_EVAL || current->attr == 1) {
        // eval() 调用，无论参数是否可静态求值，都是危险的
        printf("检测到 eval() 调用 (attr=%d)\n", current->attr);
        if (!local)
          webshell = 1;
        else
          local_webshell = 1;
      } else if (current->tainted == 1) {
        // include/require 且参数被污染
        printf("检测到 include/require 调用且参数被污染 (attr=%d)\n", current->attr);
        if (!local)
          webshell = 1;
        else
          local_webshell = 1;
      } else {
        // 对于混淆代码，即使 attr 不是 ZEND_EVAL，如果参数是变量（可能是混淆的），也应该检测
        // 检查参数是否是变量或复杂表达式（可能是混淆的）
        if (current->child && current->child[0]) {
          zend_ast *arg = current->child[0];
          // 如果参数是变量或包含位运算的表达式，可能是混淆的 eval
          if (arg->kind == ZEND_AST_VAR || 
              arg->kind == ZEND_AST_CALL ||
              (arg->kind == ZEND_AST_BINARY_OP && 
               (arg->attr == ZEND_BW_XOR || arg->attr == ZEND_BW_OR || arg->attr == ZEND_BW_AND))) {
            printf("检测到可疑的 eval/include 调用（参数可能是混淆的，attr=%d, arg_kind=%d）\n", current->attr, arg->kind);
            if (!local)
              webshell = 1;
            else
              local_webshell = 1;
          } else {
            // 即使参数不是变量，如果是 eval 调用，也应该检测（可能是 attr 值不正确）
            // 为了安全起见，所有 ZEND_AST_INCLUDE_OR_EVAL 节点都应该被检测
            printf("警告: 检测到 ZEND_AST_INCLUDE_OR_EVAL 节点但未匹配任何条件 (attr=%d, arg_kind=%d)，默认标记为可疑\n", 
                   current->attr, arg ? arg->kind : -1);
            if (!local)
              webshell = 1;
            else
              local_webshell = 1;
          }
        } else {
          // 没有参数，但仍然是 eval/include 调用，应该检测
          printf("警告: 检测到 ZEND_AST_INCLUDE_OR_EVAL 节点但没有参数 (attr=%d)，默认标记为可疑\n", current->attr);
          if (!local)
            webshell = 1;
          else
            local_webshell = 1;
        }
      }
    }

    if ((current->kind == ZEND_AST_SHELL_EXEC) && (current->tainted == 1)){
      if (!local)
        webshell = 1;
      else
        local_webshell = 1;
    }

    if (current->kind == ZEND_AST_METHOD_CALL) {
      if (current->tainted == 1) {
        if (!local)
          webshell = 1;
        else
          local_webshell = 1;

      }

      /*
      if (!webshell) {
        zend_ast *name_node = current->child[0];
        if (name_node->kind == ZEND_AST_VAR)
          name_node = name_node->child[0];
        zval *zv = zend_ast_get_zval(name_node);
        if (Z_TYPE_P(zv) == IS_STRING) {
          zend_string *var_name = zend_ast_get_str(name_node);
          if (zend_hash_exists(&tainted_table, var_name)) {
            zend_ast *method_node = current->child[1];
            zval *zv1 = zend_ast_get_zval(method_node);
            if (Z_TYPE_P(zv1) == IS_STRING) {
              zend_string *method_name = zend_ast_get_str(method_node);
              if (zend_hash_exists(&sink_table, method_name)) {
                webshell = 1;
              }
            }
          }
        }
      }
      */
    }

    if (current->kind == ZEND_AST_CALL) {
      zend_ast *name_node = current->child[0];
      if (name_node) {
        // assert($_POST['cmd'])
        if (name_node->kind == ZEND_AST_ZVAL) {
          zval *zv = zend_ast_get_zval(name_node);
          if (zv && Z_TYPE_P(zv) == IS_STRING) {
            zend_string *func_name = zend_ast_get_str(name_node);
            printf("the func name is %s\n", Z_STRVAL_P(zv));
            printf("%d\n", zend_hash_exists(&sink_func_table, func_name));
            printf("%d\n", current->tainted);
            
            // 检查参数列表中是否有污点参数
            bool has_tainted_arg = false;
            if (current->tainted == 1) {
              has_tainted_arg = true;
              printf("函数 %s 的调用节点本身被标记为污点\n", Z_STRVAL_P(zv));
            } else {
              // 检查参数列表
              zend_ast **children = ast_get_children(current, &count);
              printf("函数 %s 的参数检查: children count=%u\n", Z_STRVAL_P(zv), count);
              if (children && count > 1) {
                zend_ast *arg_list = children[1];
                printf("参数列表节点类型: %d (ZEND_AST_ARG_LIST=%d)\n", 
                       arg_list ? arg_list->kind : -1, ZEND_AST_ARG_LIST);
                if (arg_list && arg_list->kind == ZEND_AST_ARG_LIST) {
                  zend_ast_list *args = zend_ast_get_list(arg_list);
                  if (args) {
                    printf("参数列表有 %u 个参数\n", args->children);
                    for (uint32_t i = 0; i < args->children; i++) {
                      zend_ast *arg = args->child[i];
                      if (!arg) {
                        printf("参数 %u 为空\n", i);
                        continue;
                      }
                      printf("参数 %u: kind=%d, tainted=%d\n", i, arg->kind, arg->tainted);
                      
                      // 检查参数节点是否被标记为污点
                      if (arg->tainted == 1) {
                        has_tainted_arg = true;
                        printf("检测到函数 %s 的第 %u 个参数是污点（tainted=1）\n", Z_STRVAL_P(zv), i);
                        break;
                      }
                      
                      // 如果参数是数组访问（如 $_GET['cmd']），直接检查基变量是否在 source table 中
                      if (arg->kind == ZEND_AST_DIM) {
                        zend_ast *dim_var = arg->child[0];
                        if (dim_var && dim_var->kind == ZEND_AST_VAR) {
                          zend_ast *dim_name = dim_var->child[0];
                          if (dim_name && dim_name->kind == ZEND_AST_ZVAL) {
                            zval *dim_zv = zend_ast_get_zval(dim_name);
                            if (dim_zv && Z_TYPE_P(dim_zv) == IS_STRING) {
                              zend_string *dim_var_name = zend_ast_get_str(dim_name);
                              if (zend_hash_exists(&var_source_table, dim_var_name)) {
                                has_tainted_arg = true;
                                printf("检测到函数 %s 的第 %u 个参数是数组访问污点源: %s[...]\n", 
                                       Z_STRVAL_P(zv), i, Z_STRVAL_P(dim_zv));
                                break;
                              }
                            }
                          }
                        }
                      }
                      
                      // 如果参数是变量，检查变量是否在 tainted_table 中
                      if (arg->kind == ZEND_AST_VAR) {
                        zend_ast *var_name_node = arg->child[0];
                        if (var_name_node && var_name_node->kind == ZEND_AST_ZVAL) {
                          zval *var_zv = zend_ast_get_zval(var_name_node);
                          if (var_zv && Z_TYPE_P(var_zv) == IS_STRING) {
                            zend_string *var_name = zend_ast_get_str(var_name_node);
                            if (zend_hash_exists(&tainted_table, var_name) || 
                                zend_hash_exists(&var_source_table, var_name)) {
                              has_tainted_arg = true;
                              printf("检测到函数 %s 的第 %u 个参数是污点变量: $%s\n", 
                                     Z_STRVAL_P(zv), i, Z_STRVAL_P(var_zv));
                              break;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
            
            // 检查回调函数参数（对于接受回调的函数，如 array_intersect_ukey, array_filter 等）
            bool has_dangerous_callback = false;
            bool has_suspicious_callback = false;
            zend_ast **children = ast_get_children(current, &count);
            if (children && count > 1) {
              zend_ast *arg_list = children[1];
              if (arg_list && arg_list->kind == ZEND_AST_ARG_LIST) {
                zend_ast_list *args = zend_ast_get_list(arg_list);
                if (args && args->children > 0) {
                  // 对于 array_intersect_ukey, array_filter 等函数，最后一个参数通常是回调函数
                  // 检查最后一个参数是否评估为危险函数名
                  zend_ast *callback_arg = args->child[args->children - 1];
                  if (callback_arg) {
                    zend_string *callback_name = evaluate_string_expression(callback_arg);
                    if (callback_name) {
                      printf("评估回调函数参数: %s\n", ZSTR_VAL(callback_name));
                      if (is_known_sink_function(callback_name)) {
                        has_dangerous_callback = true;
                        printf("检测到危险回调函数: %s -> %s\n", Z_STRVAL_P(zv), ZSTR_VAL(callback_name));
                      }
                      zend_string_release(callback_name);
                    } else {
                      // 如果无法静态评估，检查回调参数是否是变量或包含污点
                      // 对于混淆的代码，回调参数可能是变量（如 $ch）或包含污点的表达式（如 $ch."ert"）
                      if (callback_arg->tainted == 1) {
                        has_suspicious_callback = true;
                        printf("检测到可疑回调函数参数（污点）: %s 的回调参数被标记为污点\n", Z_STRVAL_P(zv));
                      } else if (callback_arg->kind == ZEND_AST_VAR || 
                                 callback_arg->kind == ZEND_AST_BINARY_OP ||
                                 callback_arg->kind == ZEND_AST_DIM) {
                        // 回调参数是变量、二元操作或数组访问，可能是混淆的
                        has_suspicious_callback = true;
                        printf("检测到可疑回调函数参数（变量/表达式）: %s 的回调参数是 %d 类型\n", 
                               Z_STRVAL_P(zv), callback_arg->kind);
                      }
                    }
                  }
                }
              }
            }
            
            // Check whether the variable is in source table or in tainted table or not.
            // 对于危险函数（在 sink_table 中），如果参数是污点，应该检测
            // 或者函数本身在 webshell_table 中
            // 或者回调函数参数是危险函数（如 array_intersect_ukey 的回调参数是 "assert"）
            // 或者回调函数参数是可疑的（变量、污点或无法静态评估的表达式）
            if (((zend_hash_exists(&sink_table, func_name)) && has_tainted_arg) || 
                (zend_hash_exists(&webshell_table, func_name)) || 
                ((zend_hash_exists(&sink_func_table, func_name)) && has_tainted_arg) ||
                has_dangerous_callback ||
                has_suspicious_callback) {
              printf("检测到危险函数调用: %s (sink_table=%d, has_tainted_arg=%d, webshell_table=%d, sink_func_table=%d, has_dangerous_callback=%d, has_suspicious_callback=%d)\n", 
                     Z_STRVAL_P(zv), 
                     zend_hash_exists(&sink_table, func_name),
                     has_tainted_arg,
                     zend_hash_exists(&webshell_table, func_name),
                     zend_hash_exists(&sink_func_table, func_name),
                     has_dangerous_callback,
                     has_suspicious_callback);
              if (!local)
                webshell = 1;
              else
                local_webshell = 1;
            }
          }
        } else if (name_node->kind == ZEND_AST_VAR) { // $a = "assert"; $a($_POST['cmd']); $a = $_POST['func']; $b = $_POST['cmd']; $a($b);
          name_node = name_node->child[0];
          if (name_node && name_node->kind == ZEND_AST_ZVAL) {
            zval *zv = zend_ast_get_zval(name_node);
            if (zv && Z_TYPE_P(zv) == IS_STRING) {
              zend_string *var_name = zend_ast_get_str(name_node);
              printf("the var name is %s\n", Z_STRVAL_P(zv));
              // Check whether the variable is in sink_var_table (dangerous function variable) or tainted_table
              // For variable function calls like $a(...), if $a is a dangerous function variable,
              // it should be detected as webshell, especially if arguments are tainted
              bool is_sink_var = zend_hash_exists(&sink_var_table, var_name);
              bool is_tainted_var = zend_hash_exists(&tainted_table, var_name);
              bool has_tainted_args = (current->tainted == 1);
              
              // Debug: print hash table lookup results
              printf("DEBUG: 检查变量 $%s - sink_var_table存在=%d, tainted_table存在=%d, current->tainted=%d\n", 
                     Z_STRVAL_P(zv), is_sink_var, is_tainted_var, current->tainted);
              
              // Debug: manually check sink_var_table by iterating
              if (!is_sink_var) {
                  zend_string *key;
                  zval *val;
                  printf("DEBUG: sink_var_table 内容 (共 %d 项):\n", (int)zend_hash_num_elements(&sink_var_table));
                  ZEND_HASH_FOREACH_STR_KEY_VAL(&sink_var_table, key, val) {
                      if (key) {
                          printf("  - key: %s (len=%zu, hash=%lu)\n", ZSTR_VAL(key), ZSTR_LEN(key), key->h);
                          printf("    查找的key: %s (len=%zu, hash=%lu)\n", ZSTR_VAL(var_name), ZSTR_LEN(var_name), var_name->h);
                          if (zend_string_equals(key, var_name)) {
                              printf("  *** 字符串内容匹配！但 zend_hash_exists 返回 false ***\n");
                          }
                      }
                  } ZEND_HASH_FOREACH_END();
              }
              
              // Check if any argument is tainted
              if (!has_tainted_args && current->kind == ZEND_AST_CALL) {
                zend_ast **children = ast_get_children(current, &count);
                if (children && count > 1) {
                  // Check argument list (child[1])
                  zend_ast *arg_list = children[1];
                  if (arg_list && arg_list->kind == ZEND_AST_ARG_LIST) {
                    zend_ast_list *args = zend_ast_get_list(arg_list);
                    if (args) {
                      for (uint32_t i = 0; i < args->children; i++) {
                        if (args->child[i] && args->child[i]->tainted == 1) {
                          has_tainted_args = true;
                          break;
                        }
                      }
                    }
                  }
                }
              }
              
              // If function name variable is a sink variable (dangerous function), it's always dangerous
              // Also check if it's tainted variable with tainted arguments (dynamic assignment from user input)
              // Also check if variable is marked as needing dynamic resolution (may be obfuscated)
              // Get the variable node from current->child[0] (the function name node)
              zend_ast *var_ast = current->child[0];
              bool needs_dynamic_resolve = false;
              if (var_ast && var_ast->kind == ZEND_AST_VAR) {
                needs_dynamic_resolve = (var_ast->tainted & AST_NEED_DYNAMIC_RESOLVE) != 0;
              }
              
              // 对于混淆代码，如果变量需要动态解析，且参数是变量（可能是混淆的），也应该检测
              // 检查参数是否是变量或复杂表达式
              bool has_complex_args = false;
              if (current->kind == ZEND_AST_CALL) {
                zend_ast **children = ast_get_children(current, &count);
                if (children && count > 1) {
                  zend_ast *arg_list = children[1];
                  if (arg_list && arg_list->kind == ZEND_AST_ARG_LIST) {
                    zend_ast_list *args = zend_ast_get_list(arg_list);
                    if (args && args->children > 0) {
                      // 检查第一个参数是否是变量或复杂表达式
                      zend_ast *first_arg = args->child[0];
                      if (first_arg) {
                        if (first_arg->kind == ZEND_AST_VAR || 
                            first_arg->kind == ZEND_AST_CALL ||
                            (first_arg->kind == ZEND_AST_BINARY_OP && 
                             (first_arg->attr == ZEND_BW_XOR || first_arg->attr == ZEND_BW_OR || first_arg->attr == ZEND_BW_AND))) {
                          has_complex_args = true;
                        }
                      }
                    }
                  }
                }
              }
              
              // 如果变量需要动态解析（可能是混淆的函数名），且参数是变量或复杂表达式（可能是混淆的），应该检测
              if (is_sink_var || 
                  (is_tainted_var && has_tainted_args) || 
                  (needs_dynamic_resolve && (has_tainted_args || has_complex_args))) {
                printf("检测到危险函数变量调用: $%s (sink_var=%d, tainted_var=%d, has_tainted_args=%d, needs_dynamic_resolve=%d, has_complex_args=%d)\n", 
                       Z_STRVAL_P(zv), is_sink_var, is_tainted_var, has_tainted_args, needs_dynamic_resolve, has_complex_args);
                if (!local)
                  webshell = 1;
                else
                  local_webshell = 1;
              }
            }
          }
        } else if (name_node->kind == ZEND_AST_DIM) { // $_POST['func']($_POST['cmd'])
          name_node = name_node->child[0];
          if (name_node && name_node->kind == ZEND_AST_VAR) {
            name_node = name_node->child[0];
            if (name_node && name_node->kind == ZEND_AST_ZVAL) {
              zval *zv = zend_ast_get_zval(name_node);
              if (zv && Z_TYPE_P(zv) == IS_STRING) {
                printf("the array name is %s\n", Z_STRVAL_P(zv));
                zend_string *var_name = zend_ast_get_str(name_node);
                // Check whether the variable is in source table or in tainted table or not.
                if ((zend_hash_exists(&var_source_table, var_name)) || (zend_hash_exists(&sink_var_table, var_name))){
                  printf("the var name is %s\n", Z_STRVAL_P(zv));
                  if (!local)
                    webshell = 1;
                  else
                    local_webshell = 1;
                }
              }
            }
          }
        }
      }

    }
      zend_ast **ast_child = ast_get_children(current,&count);

      for (int i = 0; i < count; i++) { // 假设最多10个子节点
          int reverse_i = count - i - 1;
          if (ast_child[reverse_i] != NULL) {
              if (ast_child[reverse_i]->kind != ZEND_AST_FUNC_DECL)
                push(stack, ast_child[reverse_i]); // 将非空子节点加入栈
          }
      }
  }
  free(stack->data); // 释放栈内存
  free(stack);

}

//节点生成函数
zend_ast_zval* my_create_zval_ast(zval *zv, zend_ast *father) {
    zend_ast_zval *node = (zend_ast_zval *)emalloc(sizeof(zend_ast_zval));
    node->kind = ZEND_AST_ZVAL;
    node->attr = 0;
    ZVAL_COPY(&node->val, zv);
    node->tainted = 0;
    node->father = father;
    return node;
}

zend_ast_zval* my_create_zval_ast_arena(zval *zv, zend_ast *father, zend_arena **ast_arena) {
    zend_ast_zval *node = (zend_ast_zval *)zend_arena_alloc(ast_arena, sizeof(zend_ast_zval));
    node->kind = ZEND_AST_ZVAL;
    node->attr = 0;
    ZVAL_COPY(&node->val, zv);
    node->tainted = 0;
    node->father = father;
    return node;
}

zend_ast_list* my_create_ast_list(uint32_t children_count, zend_ast_kind kind) {
    size_t size = sizeof(zend_ast_list) + sizeof(zend_ast *) * (children_count -1);
    zend_ast_list *list = (zend_ast_list *)emalloc(size);
    
    // 初始化所有字段
    memset(list, 0, size);  // 先清零整个结构
    
    list->kind = kind;
    list->attr = 0;
    list->children = children_count;
    ((zend_ast*)list)->father = NULL;  // 初始化 father 字段
    ((zend_ast*)list)->tainted = 0;    // 初始化 tainted 字段
    
    for(uint32_t i = 0; i < children_count; i++) {
       list->child[i] = NULL;
    }
    return list;
}

zend_ast_list* my_create_ast_list_arena(uint32_t children_count, zend_ast_kind kind, zend_arena **ast_arena) {
    size_t size = sizeof(zend_ast_list) + sizeof(zend_ast *) * (children_count -1);
    zend_ast_list *list = (zend_ast_list *)zend_arena_alloc(ast_arena, size);
    
    // 初始化所有字段
    memset(list, 0, size);  // 先清零整个结构
    
    list->kind = kind;
    list->attr = 0;
    list->children = children_count;
    list->lineno = 0;  // 明确初始化 lineno
    ((zend_ast*)list)->father = NULL;  // 初始化 father 字段
    ((zend_ast*)list)->tainted = 0;    // 初始化 tainted 字段
    
    for(uint32_t i = 0; i < children_count; i++) {
       list->child[i] = NULL;
    }
    return list;
}

zend_ast *my_zend_ast_create(zend_ast_kind kind, zend_ast *child0, zend_ast *child1, zend_ast *father) {
    zend_ast *node = (zend_ast *)emalloc(sizeof(zend_ast));
    node->kind = kind;
    node->attr = 0;
    node->child[0] = child0;
    node->child[1] = child1;

    return node;
}

zend_ast *my_ast_create_ex(zend_ast_kind kind, uint32_t children, ...) {
    size_t size = sizeof(zend_ast) + (children - 1) * sizeof(zend_ast *);
    zend_ast *node = emalloc(size);

    node->kind = kind;
    node->attr = 0;
    node->lineno = 0;
    node->tainted = 0;
    node->father = NULL;

    va_list args;
    va_start(args, children);
    for (uint32_t i = 0; i < children; ++i) {
        node->child[i] = va_arg(args, zend_ast *);
    }
    va_end(args);

    return node;
}

zend_ast *my_ast_create_ex_arena(zend_ast_kind kind, uint32_t children, zend_arena **ast_arena, ...) {
    size_t size = sizeof(zend_ast) + (children - 1) * sizeof(zend_ast *);
    zend_ast *node = zend_arena_alloc(ast_arena, size);
    
    // 初始化所有字段
    memset(node, 0, size);

    node->kind = kind;
    node->attr = 0;
    node->lineno = 0;
    node->tainted = 0;
    node->father = NULL;

    va_list args;
    va_start(args, ast_arena);
    for (uint32_t i = 0; i < children; ++i) {
        node->child[i] = va_arg(args, zend_ast *);
    }
    va_end(args);
    
    // 确保未使用的子节点为 NULL
    for (uint32_t i = children; i < 10; ++i) {
        if (i < (size - sizeof(zend_ast)) / sizeof(zend_ast *)) {
            node->child[i] = NULL;
        }
    }

    return node;
}
zend_ast *create_var_ast(const char *var_name) {
    if (!var_name) {
        return NULL;
    }
    zval *zv = (zval *)emalloc(sizeof(zval));
    ZVAL_STR(zv, zend_string_init(var_name, strlen(var_name), 0));
    zend_ast *zval_ast = (zend_ast *)my_create_zval_ast(zv, NULL);

    zend_ast *var_ast = (zend_ast *)emalloc(sizeof(zend_ast));
    var_ast->kind = ZEND_AST_VAR;
    var_ast->attr = 0;
    var_ast->lineno = 0;
    var_ast->child[0] = zval_ast;

    return var_ast;
}

zend_ast *create_var_ast_arena(const char *var_name, zend_arena **ast_arena) {
    if (!var_name) {
        return NULL;
    }
    zval *zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(zv, zend_string_init(var_name, strlen(var_name), 0));
    zend_ast *zval_ast = (zend_ast *)my_create_zval_ast_arena(zv, NULL, ast_arena);

    zend_ast *var_ast = (zend_ast *)zend_arena_alloc(ast_arena, sizeof(zend_ast));
    var_ast->kind = ZEND_AST_VAR;
    var_ast->attr = 0;
    var_ast->lineno = 0;
    var_ast->tainted = 0;
    var_ast->father = NULL;
    var_ast->child[0] = zval_ast;
    var_ast->child[1] = NULL;

    return var_ast;
}

zend_ast *create_string_ast(const char *str) {
    zval *zv = (zval *)emalloc(sizeof(zval));
    ZVAL_STR(zv, zend_string_init(str, strlen(str), 0));
    return (zend_ast *)my_create_zval_ast(zv, NULL);  // ZEND_AST_ZVAL
}

// 替换原有 或'||'的定义
#ifndef T_BOOLEAN_OR
#define T_BOOLEAN_OR 285
#endif
#ifndef ZEND_BINARY_OP_OR
#define ZEND_BINARY_OP_OR T_BOOLEAN_OR
#endif

static zend_ast *g_root_ast = NULL;

//cause seg
zend_ast *create_binary_op_ast(uint32_t op_type, zend_ast *left, zend_ast *right, zend_arena **ast_arena) {
    zend_ast *node = my_ast_create_ex_arena(ZEND_AST_BINARY_OP, 2, ast_arena, left, right);
    
    // 直接使用操作符类型，不进行任何转换
    node->attr = op_type;
    
    return node;
}

// 替代 create_unary_op_ast
zend_ast *create_unary_op_ast(zend_ast_attr op_type, zend_ast *expr, zend_arena **ast_arena) {
    zend_ast *node = my_ast_create_ex_arena(ZEND_AST_UNARY_OP, 1, ast_arena, expr);
    node->attr = op_type;
    return node;
}

const char* get_var_name(zend_ast *var_ast) {
    if (!var_ast || var_ast->kind != ZEND_AST_VAR) {
        return NULL;
    }
    zend_ast *name_ast = var_ast->child[0];
    if (!name_ast) {
        return NULL;
    }
    if (name_ast->kind == ZEND_AST_ZVAL) {
        zval *zv = zend_ast_get_zval(name_ast);
        if (Z_TYPE_P(zv) == IS_STRING) {
            return Z_STRVAL_P(zv);
        }
    }
    return NULL;
}

// 递归深拷贝AST节点
zend_ast* deep_copy_ast(zend_ast *ast, zend_arena **ast_arena) {
    if (!ast) return NULL;
    
    if (ast_kind_is_decl(ast->kind)) {
        // 处理声明类型节点
        zend_ast_decl *decl = (zend_ast_decl*)ast;
        zend_ast_decl *new_decl = (zend_ast_decl*)zend_arena_alloc(ast_arena, sizeof(zend_ast_decl));
        
        memcpy(new_decl, decl, sizeof(zend_ast_decl));
        for (uint32_t i = 0; i < 5; i++) {
            new_decl->child[i] = deep_copy_ast(decl->child[i], ast_arena);
            if (new_decl->child[i]) 
               new_decl->child[i]->father = (zend_ast*)new_decl;
        }
        
        if (decl->name) 
           new_decl->name = zend_string_copy(decl->name);
        if (decl->doc_comment) 
           new_decl->doc_comment = zend_string_copy(decl->doc_comment);
        
        return (zend_ast*)new_decl;
    } else if (zend_ast_is_list(ast)) {
        // 处理列表类型节点
        zend_ast_list *list = zend_ast_get_list(ast);
        zend_ast_list *new_list = my_create_ast_list(list->children, ast->kind);
        
        new_list->attr = list->attr;
        new_list->lineno = list->lineno;
        new_list->tainted = list->tainted;
        new_list->father = NULL;
        
        for (uint32_t i = 0; i < list->children; i++) {
            new_list->child[i] = deep_copy_ast(list->child[i], ast_arena);
            if (new_list->child[i]) 
               new_list->child[i]->father = (zend_ast*)new_list;
        }
        
        return (zend_ast*)new_list;
    } else if (ast->kind == ZEND_AST_ZVAL) {
        // 处理ZVAL类型节点
        zend_ast_zval *zval_ast = (zend_ast_zval*)ast;
        zend_ast_zval *new_zval_ast = (zend_ast_zval*)zend_arena_alloc(ast_arena, sizeof(zend_ast_zval));
        
        new_zval_ast->kind = ZEND_AST_ZVAL;
        new_zval_ast->attr = zval_ast->attr;
        
        zval *zv = zend_ast_get_zval(ast);
        zval new_zv;
        ZVAL_COPY(&new_zv, zv);
        ZVAL_COPY_VALUE(&new_zval_ast->val, &new_zv);
        
        if (ast->father) {
            ((zend_ast*)new_zval_ast)->father = ast->father;
        }
        
        return (zend_ast*)new_zval_ast;
    } else {
        // 处理普通节点
        uint32_t children = zend_ast_get_num_children(ast);
        size_t size = sizeof(zend_ast) + (children > 1 ? (children - 1) * sizeof(zend_ast*) : 0);
        zend_ast *new_ast = zend_arena_alloc(ast_arena, size);
        
        new_ast->kind = ast->kind;
        new_ast->attr = ast->attr;
        new_ast->lineno = ast->lineno;
        new_ast->tainted = ast->tainted;
        new_ast->father = NULL;
        
        for (uint32_t i = 0; i < children; i++) {
            new_ast->child[i] = deep_copy_ast(ast->child[i], ast_arena);
            if (new_ast->child[i]) 
               new_ast->child[i]->father = new_ast;
        }
        
        return new_ast;
    }
}

//深拷贝整个数组节点，用一个新的变量节点来=整个数组节点，通过对变量节点进行判断
zend_ast* deep_copy_dim_to_var(zend_ast *dim_ast, zend_arena **ast_arena, const char *new_var_name) {
    zend_ast *var_ast = create_var_ast_arena(new_var_name, ast_arena);
    zend_ast *dim_copy = deep_copy_ast(dim_ast, ast_arena);

    zend_ast *assign_ast = my_ast_create_ex_arena(ZEND_AST_ASSIGN, 2, ast_arena, var_ast, dim_copy);

    return assign_ast; 
}

static zend_ast* build_in_array_check(zend_ast *var_ast, zend_arena **ast_arena) {
    /* 1) 构造 ["eval","assert",... ] 的数组常量 */
    const char *dangerous_func_names[] = {
        "eval", "assert", "exec", "shell_exec", "system", "preg_replace",
        "file_put_contents", "fwrite", "fputs", "call_user_func_array",
        "array_map", "copy", "call_user_func", "array_filter", "array_walk",
        "array_walk_recursive", "register_tick_function", "eval_r",
        "create_function", "uasort", "array_udiff_assoc",
        "forward_static_call_array", "uksort", "array_reduce",
        "register_shutdown_function", "filter_var", "filter_var_array",
        "preg_replace_callback", "mb_ereg_replace_callback", "popen"
    };
    size_t num_funcs = sizeof(dangerous_func_names) / sizeof(dangerous_func_names[0]);

    /* ZEND_AST_ARRAY: children = num_funcs */
    zend_ast_list *arr_list = my_create_ast_list_arena((uint32_t)num_funcs, ZEND_AST_ARRAY, ast_arena);
    for (uint32_t i = 0; i < (uint32_t)num_funcs; ++i) {
        zval *name_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
        ZVAL_STR(name_zv, zend_string_init(dangerous_func_names[i], strlen(dangerous_func_names[i]), 0));
        zend_ast *val_node = (zend_ast *)my_create_zval_ast_arena(name_zv, NULL, ast_arena); /* ZEND_AST_ZVAL */

        /* ZEND_AST_ARRAY_ELEM(value, key=NULL) */
        zend_ast *elem = my_ast_create_ex_arena(ZEND_AST_ARRAY_ELEM, 2, ast_arena, val_node, NULL);
        arr_list->child[i] = elem;
        elem->father = (zend_ast*)arr_list;
    }

    /* 2) 构造 in_array($var, ["..."], true) 调用 */
    zval *in_array_name_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(in_array_name_zv, zend_string_init("in_array", sizeof("in_array")-1, 0));
    zend_ast *in_array_name_ast = (zend_ast *)my_create_zval_ast_arena(in_array_name_zv, NULL, ast_arena); /* name 节点 */

    /* 第3个参数 true */
    zval *true_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_TRUE(true_zv);
    zend_ast *true_ast = (zend_ast *)my_create_zval_ast_arena(true_zv, NULL, ast_arena);

    /* 参数列表：($var, array_const, true) */
    zend_ast_list *in_array_args = my_create_ast_list_arena(3, ZEND_AST_ARG_LIST, ast_arena);
    in_array_args->child[0] = var_ast;                 /* 直接使用传入的变量 AST */
    in_array_args->child[1] = (zend_ast *)arr_list;    /* 数组常量 */
    in_array_args->child[2] = true_ast;

    /* in_array 调用节点 */
    zend_ast *in_array_call = my_ast_create_ex_arena(ZEND_AST_CALL, 2, ast_arena,
        in_array_name_ast, (zend_ast*)in_array_args);
    return in_array_call; /* 作为 if 的条件 */
}

/* 建议1：构造 __yz_runtime_probe 调用 AST */
static zend_ast* build_probe_call_for_call_ast(
    zend_ast *call_ast,
    zend_arena **ast_arena,
    const char *type_str,
    zend_ast *callee_ast,
    zend_ast *first_arg_ast
) {
    if (!call_ast || !ast_arena || !type_str) return NULL;
    
    /* 1) 函数名：__yz_runtime_probe */
    zval *probe_name_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(probe_name_zv, zend_string_init("__yz_runtime_probe", strlen("__yz_runtime_probe"), 0));
    zend_ast *probe_name_ast = (zend_ast *)my_create_zval_ast_arena(probe_name_zv, NULL, ast_arena);
    
    /* 2) 参数列表：type, __FILE__, __LINE__, __FUNCTION__, callee, [args...] */
    /* 参数1：type 字符串 */
    zval *type_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(type_zv, zend_string_init(type_str, strlen(type_str), 0));
    zend_ast *type_ast = (zend_ast *)my_create_zval_ast_arena(type_zv, NULL, ast_arena);
    
    /* 参数2：__FILE__ */
    zval *file_name_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(file_name_zv, zend_string_init("__FILE__", 8, 0));
    zend_ast *file_name_ast = (zend_ast *)my_create_zval_ast_arena(file_name_zv, NULL, ast_arena);
    
    /* 参数3：__LINE__ */
    zval *line_name_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(line_name_zv, zend_string_init("__LINE__", 8, 0));
    zend_ast *line_name_ast = (zend_ast *)my_create_zval_ast_arena(line_name_zv, NULL, ast_arena);
    
    /* 参数4：__FUNCTION__ */
    zval *func_name_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(func_name_zv, zend_string_init("__FUNCTION__", 12, 0));
    zend_ast *func_name_ast = (zend_ast *)my_create_zval_ast_arena(func_name_zv, NULL, ast_arena);
    
    /* 计算参数数量 */
    uint32_t arg_count = 4;  // type, __FILE__, __LINE__, __FUNCTION__
    if (callee_ast) arg_count++;
    if (first_arg_ast) arg_count++;
    
    zend_ast_list *probe_args = my_create_ast_list_arena(arg_count, ZEND_AST_ARG_LIST, ast_arena);
    probe_args->child[0] = type_ast;
    probe_args->child[1] = file_name_ast;
    probe_args->child[2] = line_name_ast;
    probe_args->child[3] = func_name_ast;
    
    uint32_t idx = 4;
    if (callee_ast) {
        probe_args->child[idx++] = callee_ast;
    }
    if (first_arg_ast) {
        probe_args->child[idx++] = first_arg_ast;
    }
    
    /* 构造 __yz_runtime_probe(...) 调用 */
    zend_ast *probe_call = my_ast_create_ex_arena(ZEND_AST_CALL, 2, ast_arena,
        probe_name_ast, (zend_ast*)probe_args);
    
    return probe_call;
}

/* 用于构造：file_put_contents("/tmp/yz_dyn_cg.jsonl", json_encode([...]), FILE_APPEND); */
/* 生成 JSON 格式的日志：{"type":"dyn_call","file":__FILE__,"line":__LINE__,"caller":__FUNCTION__,"callee":$var} */
/* 注意：var_name 参数用于在日志中记录变量名 */
static zend_ast* build_call_var_log_stmt(zend_ast *var_ast, const char *var_name, zend_arena **ast_arena) {
    /* 函数名：file_put_contents */
    zval *fput_name_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(fput_name_zv, zend_string_init("file_put_contents", sizeof("file_put_contents")-1, 0));
    zend_ast *fput_name_ast = (zend_ast *)my_create_zval_ast_arena(fput_name_zv, NULL, ast_arena);

    /* 参数1：日志路径 - 改为调用图日志 */
    zval *path_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(path_zv, zend_string_init("/tmp/yz_dyn_cg.jsonl", sizeof("/tmp/yz_dyn_cg.jsonl")-1, 0));
    zend_ast *path_ast = (zend_ast *)my_create_zval_ast_arena(path_zv, NULL, ast_arena);

    /* 参数2：构建 JSON 字符串 - 调用图日志格式
     * 生成代码：json_encode(["type" => "dyn_call", "file" => __FILE__, "line" => __LINE__, 
     *                        "caller" => __FUNCTION__, "callee" => $var]) . "\n"
     */
    
    /* 构建数组：["type" => "dyn_call", "file" => __FILE__, "line" => __LINE__, 
     *            "caller" => __FUNCTION__, "callee" => is_string($var) ? $var : null] */
    /* "type" => "dyn_call" */
    zval *type_key_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(type_key_zv, zend_string_init("type", 4, 0));
    zend_ast *type_key_ast = (zend_ast *)my_create_zval_ast_arena(type_key_zv, NULL, ast_arena);
    
    zval *type_val_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(type_val_zv, zend_string_init("dyn_call", 8, 0));
    zend_ast *type_val_ast = (zend_ast *)my_create_zval_ast_arena(type_val_zv, NULL, ast_arena);
    
    zend_ast *type_elem = my_ast_create_ex_arena(ZEND_AST_ARRAY_ELEM, 2, ast_arena, type_val_ast, type_key_ast);
    
    /* "file" => __FILE__ */
    zval *file_key_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(file_key_zv, zend_string_init("file", 4, 0));
    zend_ast *file_key_ast = (zend_ast *)my_create_zval_ast_arena(file_key_zv, NULL, ast_arena);
    
    zval *file_name_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(file_name_zv, zend_string_init("__FILE__", 8, 0));
    zend_ast *file_name_ast = (zend_ast *)my_create_zval_ast_arena(file_name_zv, NULL, ast_arena);
    /* 注意：这里需要构建常量 __FILE__，但为了简化，我们直接使用字符串 */
    /* 实际上在运行时 __FILE__ 会被解析为实际文件名 */
    
    zend_ast *file_elem = my_ast_create_ex_arena(ZEND_AST_ARRAY_ELEM, 2, ast_arena, file_name_ast, file_key_ast);
    
    /* "line" => __LINE__ */
    zval *line_key_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(line_key_zv, zend_string_init("line", 4, 0));
    zend_ast *line_key_ast = (zend_ast *)my_create_zval_ast_arena(line_key_zv, NULL, ast_arena);
    
    zval *line_name_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(line_name_zv, zend_string_init("__LINE__", 8, 0));
    zend_ast *line_name_ast = (zend_ast *)my_create_zval_ast_arena(line_name_zv, NULL, ast_arena);
    
    zend_ast *line_elem = my_ast_create_ex_arena(ZEND_AST_ARRAY_ELEM, 2, ast_arena, line_name_ast, line_key_ast);
    
    /* 构建 "var" => "var_name" (变量名字符串) */
    zval *var_key_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(var_key_zv, zend_string_init("var", 3, 0));
    zend_ast *var_key_ast = (zend_ast *)my_create_zval_ast_arena(var_key_zv, NULL, ast_arena);
    
    zval *var_val_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    if (var_name) {
        ZVAL_STR(var_val_zv, zend_string_init(var_name, strlen(var_name), 0));
    } else {
        ZVAL_STR(var_val_zv, zend_string_init("", 0, 0));
    }
    zend_ast *var_val_ast = (zend_ast *)my_create_zval_ast_arena(var_val_zv, NULL, ast_arena);
    
    zend_ast *var_elem = my_ast_create_ex_arena(ZEND_AST_ARRAY_ELEM, 2, ast_arena, var_val_ast, var_key_ast);
    
    /* 构建 "caller" => current_function_name (调用者函数名) */
    zval *caller_key_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(caller_key_zv, zend_string_init("caller", 6, 0));
    zend_ast *caller_key_ast = (zend_ast *)my_create_zval_ast_arena(caller_key_zv, NULL, ast_arena);
    
    zval *caller_val_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    if (current_function_name) {
        ZVAL_STR(caller_val_zv, zend_string_copy(current_function_name));
    } else {
        ZVAL_STR(caller_val_zv, zend_string_init("__main__", 8, 0));
    }
    zend_ast *caller_val_ast = (zend_ast *)my_create_zval_ast_arena(caller_val_zv, NULL, ast_arena);
    
    zend_ast *caller_elem = my_ast_create_ex_arena(ZEND_AST_ARRAY_ELEM, 2, ast_arena, caller_val_ast, caller_key_ast);
    
    /* "callee" => is_string($var) ? $var : null */
    /* is_string($var) */
    zval *is_string_name_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(is_string_name_zv, zend_string_init("is_string", 9, 0));
    zend_ast *is_string_name_ast = (zend_ast *)my_create_zval_ast_arena(is_string_name_zv, NULL, ast_arena);
    
    zend_ast_list *is_string_args = my_create_ast_list_arena(1, ZEND_AST_ARG_LIST, ast_arena);
    is_string_args->child[0] = var_ast;
    
    zend_ast *is_string_call = my_ast_create_ex_arena(ZEND_AST_CALL, 2, ast_arena,
        is_string_name_ast, (zend_ast*)is_string_args);
    
    /* null */
    zval *null_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_NULL(null_zv);
    zend_ast *null_ast = (zend_ast *)my_create_zval_ast_arena(null_zv, NULL, ast_arena);
    
    /* is_string($var) ? $var : null */
    zend_ast *callee_val_ast = my_ast_create_ex_arena(ZEND_AST_CONDITIONAL, 3, ast_arena,
        is_string_call, var_ast, null_ast);
    
    zval *callee_key_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(callee_key_zv, zend_string_init("callee", 6, 0));
    zend_ast *callee_key_ast = (zend_ast *)my_create_zval_ast_arena(callee_key_zv, NULL, ast_arena);
    
    zend_ast *callee_elem = my_ast_create_ex_arena(ZEND_AST_ARRAY_ELEM, 2, ast_arena, callee_val_ast, callee_key_ast);
    
    /* 构建数组 [type_elem, file_elem, line_elem, caller_elem, callee_elem] */
    zend_ast_list *json_array = my_create_ast_list_arena(5, ZEND_AST_ARRAY, ast_arena);
    json_array->child[0] = type_elem;
    json_array->child[1] = file_elem;
    json_array->child[2] = line_elem;
    json_array->child[3] = caller_elem;
    json_array->child[4] = callee_elem;
    
    /* json_encode(...) */
    zval *json_encode_name_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(json_encode_name_zv, zend_string_init("json_encode", 10, 0));
    zend_ast *json_encode_name_ast = (zend_ast *)my_create_zval_ast_arena(json_encode_name_zv, NULL, ast_arena);
    
    zend_ast_list *json_encode_args = my_create_ast_list_arena(1, ZEND_AST_ARG_LIST, ast_arena);
    json_encode_args->child[0] = (zend_ast*)json_array;
    
    zend_ast *json_encode_call = my_ast_create_ex_arena(ZEND_AST_CALL, 2, ast_arena,
        json_encode_name_ast, (zend_ast*)json_encode_args);
    
    /* json_encode(...) . "\n" */
    zval *nl_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(nl_zv, zend_string_init("\n", 1, 0));
    zend_ast *nl_ast = (zend_ast *)my_create_zval_ast_arena(nl_zv, NULL, ast_arena);
    zend_ast *msg_ast = create_binary_op_ast(ZEND_CONCAT, json_encode_call, nl_ast, ast_arena);

    /* 参数3：flags = FILE_APPEND = 8 */
    zval *flags_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_LONG(flags_zv, 8);  // FILE_APPEND
    zend_ast *flags_ast = (zend_ast *)my_create_zval_ast_arena(flags_zv, NULL, ast_arena);

    /* 实参列表 */
    zend_ast_list *args = my_create_ast_list_arena(3, ZEND_AST_ARG_LIST, ast_arena);
    args->child[0] = path_ast;
    args->child[1] = msg_ast;
    args->child[2] = flags_ast;

    /* 调用节点 */
    zend_ast *call = my_ast_create_ex_arena(ZEND_AST_CALL, 2, ast_arena,
        fput_name_ast, (zend_ast*)args);
    return call;
}

/* 用于构造：file_put_contents("/tmp/yz_assert_log.jsonl", "[BLOCK] fn=" . $var . "\n", 10); */
/* 保留旧版本以兼容，但建议使用 build_call_var_log_stmt */
static zend_ast* build_file_put_contents_stmt(zend_ast *var_ast, zend_arena **ast_arena) {
    /* 函数名 */
    zval *fput_name_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(fput_name_zv, zend_string_init("file_put_contents", sizeof("file_put_contents")-1, 0));
    zend_ast *fput_name_ast = (zend_ast *)my_create_zval_ast_arena(fput_name_zv, NULL, ast_arena);

    /* 参数1：日志路径 */
    zval *path_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(path_zv, zend_string_init("/tmp/yz_assert_log.jsonl", sizeof("/tmp/yz_assert_log.jsonl")-1, 0));
    zend_ast *path_ast = (zend_ast *)my_create_zval_ast_arena(path_zv, NULL, ast_arena);

    /* 参数2：拼接消息 "[BLOCK] fn=" . $var . "\n" */
    zval *prefix_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(prefix_zv, zend_string_init("[BLOCK] fn=", sizeof("[BLOCK] fn=")-1, 0));
    zend_ast *prefix_ast = (zend_ast *)my_create_zval_ast_arena(prefix_zv, NULL, ast_arena);

    /* prefix . var */
    zend_ast *prefix_concat_var = create_binary_op_ast(ZEND_CONCAT, prefix_ast, var_ast, ast_arena);

    /* (prefix . var) . "\n" */
    zval *nl_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(nl_zv, zend_string_init("\n", 1, 0));
    zend_ast *nl_ast = (zend_ast *)my_create_zval_ast_arena(nl_zv, NULL, ast_arena);
    zend_ast *msg_ast = create_binary_op_ast(ZEND_CONCAT, prefix_concat_var, nl_ast, ast_arena);

    /* 参数3：flags = FILE_APPEND|LOCK_EX = 8|2 = 10 */
    zval *flags_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_LONG(flags_zv, 10);
    zend_ast *flags_ast = (zend_ast *)my_create_zval_ast_arena(flags_zv, NULL, ast_arena);

    /* 实参列表 */
    zend_ast_list *args = my_create_ast_list_arena(3, ZEND_AST_ARG_LIST, ast_arena);
    args->child[0] = path_ast;
    args->child[1] = msg_ast;
    args->child[2] = flags_ast;

    /* 调用节点 */
    zend_ast *call = my_ast_create_ex_arena(ZEND_AST_CALL, 2, ast_arena,
        fput_name_ast, (zend_ast*)args);
    return call;
}

/* 用于构造：file_put_contents("/tmp/yz_dyn_cg.jsonl", json_encode([...]), FILE_APPEND); */
/* 生成 JSON 格式的日志：{"type":"eval","file":__FILE__,"line":__LINE__} */
static zend_ast* build_eval_log_stmt(zend_ast *eval_node, zend_arena **ast_arena) {
    /* 函数名：file_put_contents */
    zval *fput_name_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(fput_name_zv, zend_string_init("file_put_contents", sizeof("file_put_contents")-1, 0));
    zend_ast *fput_name_ast = (zend_ast *)my_create_zval_ast_arena(fput_name_zv, NULL, ast_arena);

    /* 参数1：日志路径 - 改为调用图日志 */
    zval *path_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(path_zv, zend_string_init("/tmp/yz_dyn_cg.jsonl", sizeof("/tmp/yz_dyn_cg.jsonl")-1, 0));
    zend_ast *path_ast = (zend_ast *)my_create_zval_ast_arena(path_zv, NULL, ast_arena);

    /* 参数2：构建 JSON 字符串 json_encode(["type" => "EVAL", "line" => __LINE__]) . "\n" */
    
    /* 构建数组：["type" => "EVAL", "line" => lineno] */
    /* "type" => "EVAL" */
    zval *type_key_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(type_key_zv, zend_string_init("type", 4, 0));
    zend_ast *type_key_ast = (zend_ast *)my_create_zval_ast_arena(type_key_zv, NULL, ast_arena);
    
    zval *type_val_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(type_val_zv, zend_string_init("eval", 4, 0));
    zend_ast *type_val_ast = (zend_ast *)my_create_zval_ast_arena(type_val_zv, NULL, ast_arena);
    
    zend_ast *type_elem = my_ast_create_ex_arena(ZEND_AST_ARRAY_ELEM, 2, ast_arena, type_val_ast, type_key_ast);
    
    /* "file" => __FILE__ */
    zval *file_key_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(file_key_zv, zend_string_init("file", 4, 0));
    zend_ast *file_key_ast = (zend_ast *)my_create_zval_ast_arena(file_key_zv, NULL, ast_arena);
    
    zval *file_name_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(file_name_zv, zend_string_init("__FILE__", 8, 0));
    zend_ast *file_name_ast = (zend_ast *)my_create_zval_ast_arena(file_name_zv, NULL, ast_arena);
    
    zend_ast *file_elem = my_ast_create_ex_arena(ZEND_AST_ARRAY_ELEM, 2, ast_arena, file_name_ast, file_key_ast);
    
    /* "line" => __LINE__ */
    zval *line_key_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(line_key_zv, zend_string_init("line", 4, 0));
    zend_ast *line_key_ast = (zend_ast *)my_create_zval_ast_arena(line_key_zv, NULL, ast_arena);
    
    zval *line_name_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(line_name_zv, zend_string_init("__LINE__", 8, 0));
    zend_ast *line_name_ast = (zend_ast *)my_create_zval_ast_arena(line_name_zv, NULL, ast_arena);
    
    zend_ast *line_elem = my_ast_create_ex_arena(ZEND_AST_ARRAY_ELEM, 2, ast_arena, line_name_ast, line_key_ast);
    
    /* 构建数组 [type_elem, file_elem, line_elem] */
    zend_ast_list *json_array = my_create_ast_list_arena(3, ZEND_AST_ARRAY, ast_arena);
    json_array->child[0] = type_elem;
    json_array->child[1] = file_elem;
    json_array->child[2] = line_elem;
    
    /* json_encode(...) */
    zval *json_encode_name_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(json_encode_name_zv, zend_string_init("json_encode", 10, 0));
    zend_ast *json_encode_name_ast = (zend_ast *)my_create_zval_ast_arena(json_encode_name_zv, NULL, ast_arena);
    
    zend_ast_list *json_encode_args = my_create_ast_list_arena(1, ZEND_AST_ARG_LIST, ast_arena);
    json_encode_args->child[0] = (zend_ast*)json_array;
    
    zend_ast *json_encode_call = my_ast_create_ex_arena(ZEND_AST_CALL, 2, ast_arena,
        json_encode_name_ast, (zend_ast*)json_encode_args);
    
    /* json_encode(...) . "\n" */
    zval *nl_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(nl_zv, zend_string_init("\n", 1, 0));
    zend_ast *nl_ast = (zend_ast *)my_create_zval_ast_arena(nl_zv, NULL, ast_arena);
    zend_ast *msg_ast = create_binary_op_ast(ZEND_CONCAT, json_encode_call, nl_ast, ast_arena);

    /* 参数3：flags = FILE_APPEND = 8 */
    zval *flags_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_LONG(flags_zv, 8);  // FILE_APPEND
    zend_ast *flags_ast = (zend_ast *)my_create_zval_ast_arena(flags_zv, NULL, ast_arena);

    /* 实参列表 */
    zend_ast_list *args = my_create_ast_list_arena(3, ZEND_AST_ARG_LIST, ast_arena);
    args->child[0] = path_ast;
    args->child[1] = msg_ast;
    args->child[2] = flags_ast;

    /* 调用节点 */
    zend_ast *call = my_ast_create_ex_arena(ZEND_AST_CALL, 2, ast_arena,
        fput_name_ast, (zend_ast*)args);
    return call;
}

/* 构造：exit(1); 作为语句 */
static zend_ast* build_exit_stmt(zend_arena **ast_arena) {
    zval *one_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_LONG(one_zv, 1);
    zend_ast *one_ast = (zend_ast *)my_create_zval_ast_arena(one_zv, NULL, ast_arena);
    zend_ast *exit_ast = my_ast_create_ex_arena(ZEND_AST_EXIT, 1, ast_arena, one_ast);
    return exit_ast;
}

/* 建议1：用 assert(__yz_runtime_probe(...)) 替换原先的 if + file_put_contents */
zend_ast* insert_assert_before_at_index(zend_ast *stmt_list_ast, uint32_t index, zend_arena **ast_arena, char *var_name) {
    if (!stmt_list_ast || stmt_list_ast->kind != ZEND_AST_STMT_LIST) return stmt_list_ast;
    if (!var_name) return stmt_list_ast;

    /* 构造 $var 节点 */
    zend_ast *var_ast = create_var_ast_arena(var_name, ast_arena);
    if (!var_ast) {
        return stmt_list_ast;
    }

    /* 构造 __yz_runtime_probe("CALL_VAR", __FILE__, __LINE__, __FUNCTION__, $var) */
    zend_ast *probe_call = build_probe_call_for_call_ast(
        NULL,  // call_ast 不需要，因为我们只传参数
        ast_arena,
        "CALL_VAR",
        var_ast,  // callee_ast
        NULL      // first_arg_ast，对于 CALL_VAR 暂时不传参数
    );
    
    if (!probe_call) {
        return stmt_list_ast;
    }

    /* 构造 assert(__yz_runtime_probe(...)) */
    zval *assert_name_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
    ZVAL_STR(assert_name_zv, zend_string_init("assert", 6, 0));
    zend_ast *assert_name_ast = (zend_ast *)my_create_zval_ast_arena(assert_name_zv, NULL, ast_arena);
    
    zend_ast_list *assert_args = my_create_ast_list_arena(1, ZEND_AST_ARG_LIST, ast_arena);
    assert_args->child[0] = probe_call;
    
    zend_ast *assert_call = my_ast_create_ex_arena(ZEND_AST_CALL, 2, ast_arena,
        assert_name_ast, (zend_ast*)assert_args);

    /* 把 assert 语句插入到 stmt_list_ast 的 index 位置 */
    zend_ast_list *list = zend_ast_get_list(stmt_list_ast);
    uint32_t old_n = list->children;
    if (index > old_n) index = old_n;

    zend_ast_list *new_list = my_create_ast_list_arena(old_n + 1, ZEND_AST_STMT_LIST, ast_arena);
    for (uint32_t i = 0; i < index; i++) {
        new_list->child[i] = list->child[i];
        if (new_list->child[i]) new_list->child[i]->father = (zend_ast*)new_list;
    }
    new_list->child[index] = assert_call;
    if (new_list->child[index]) new_list->child[index]->father = (zend_ast*)new_list;

    for (uint32_t i = index; i < old_n; i++) {
        new_list->child[i+1] = list->child[i];
        if (new_list->child[i+1]) new_list->child[i+1]->father = (zend_ast*)new_list;
    }

    // 设置 new_list 的 father 指针
    ((zend_ast*)new_list)->father = stmt_list_ast->father;

    return (zend_ast*)new_list;
}

static void replace_child_in_parent(zend_ast *parent, zend_ast *old_child, zend_ast *new_child) {
    if (!parent || !old_child || !new_child) return;
    if (old_child == new_child) return;  // 避免替换自身
    
    uint32_t count = 0;
    zend_ast **children = ast_get_children(parent, &count);
    if (!children) return;
    
    for (uint32_t i = 0; i < count; i++) {
        if (children[i] == old_child) {
            children[i] = new_child;
            if (new_child) {
                new_child->father = parent;
            }
            return;
        }
    }
}

//对数组节点检测插入赋值语句
static zend_ast* insert_stmt_before_at_index(zend_ast *stmt_list_ast, uint32_t index, zend_ast *stmt, zend_arena **ast_arena) {
    if (!stmt_list_ast || stmt_list_ast->kind != ZEND_AST_STMT_LIST) return stmt_list_ast;
    zend_ast_list *list = zend_ast_get_list(stmt_list_ast);
    uint32_t old_n = list->children;
    if (index > old_n) index = old_n;

    zend_ast_list *new_list = my_create_ast_list_arena(old_n + 1, ZEND_AST_STMT_LIST, ast_arena);

    for (uint32_t i = 0; i < index; i++) {
        new_list->child[i] = list->child[i];
        if (new_list->child[i]) new_list->child[i]->father = (zend_ast*)new_list;
    }
    new_list->child[index] = stmt;
    if (stmt) stmt->father = (zend_ast*)new_list;

    for (uint32_t i = index; i < old_n; i++) {
        new_list->child[i + 1] = list->child[i];
        if (new_list->child[i + 1]) new_list->child[i + 1]->father = (zend_ast*)new_list;
    }

    // 设置 new_list 的 father 指针
    ((zend_ast*)new_list)->father = stmt_list_ast->father;

    return (zend_ast*)new_list;
}

static zend_bool is_known_sink_function(zend_string *func_name) {
    if (!func_name) {
        return 0;
    }
    if (zend_hash_exists(&sink_table, func_name)) {
        return 1;
    }
    if (zend_hash_exists(&sink_func_table, func_name)) {
        return 1;
    }
    if (zend_hash_exists(&webshell_table, func_name)) {
        return 1;
    }
    return 0;
}

static void add_sink_var_from_assignment(zend_ast *var_node, zend_string *func_name) {
    if (!var_node || var_node->kind != ZEND_AST_VAR || !func_name) {
        return;
    }
    zend_ast *name_node = var_node->child[0];
    if (!name_node || name_node->kind != ZEND_AST_ZVAL) {
        return;
    }
    zval *zv = zend_ast_get_zval(name_node);
    if (!zv || Z_TYPE_P(zv) != IS_STRING) {
        return;
    }
    zend_string *var_name = zend_ast_get_str(name_node);
    if (!var_name) {
        return;
    }
    if (!zend_hash_exists(&sink_var_table, var_name)) {
        zval sink_var_val;
        ZVAL_LONG(&sink_var_val, sink_var_count);
        sink_var_count++;
        zend_hash_add(&sink_var_table, var_name, &sink_var_val);
        printf("动态识别危险函数变量: $%s -> %s\n", var_name->val, ZSTR_VAL(func_name));
    }
}

static zend_string* evaluate_concat_expression(zend_ast *expr) {
    if (!expr) return NULL;
    zend_string *left = evaluate_string_expression(expr->child[0]);
    zend_string *right = evaluate_string_expression(expr->child[1]);
    if (!left || !right) {
        if (left) zend_string_release(left);
        if (right) zend_string_release(right);
        return NULL;
    }
    size_t new_len = ZSTR_LEN(left) + ZSTR_LEN(right);
    zend_string *result = zend_string_alloc(new_len, 0);
    memcpy(ZSTR_VAL(result), ZSTR_VAL(left), ZSTR_LEN(left));
    memcpy(ZSTR_VAL(result) + ZSTR_LEN(left), ZSTR_VAL(right), ZSTR_LEN(right));
    ZSTR_VAL(result)[new_len] = '\0';
    zend_string_release(left);
    zend_string_release(right);
    return result;
}

// 评估字符串异或操作 (^)
static zend_string* evaluate_xor_expression(zend_ast *expr) {
    if (!expr) return NULL;
    zend_string *left = evaluate_string_expression(expr->child[0]);
    zend_string *right = evaluate_string_expression(expr->child[1]);
    if (!left || !right) {
        if (left) zend_string_release(left);
        if (right) zend_string_release(right);
        return NULL;
    }
    // 取较短字符串的长度
    size_t len = ZSTR_LEN(left) < ZSTR_LEN(right) ? ZSTR_LEN(left) : ZSTR_LEN(right);
    if (len == 0) {
        zend_string_release(left);
        zend_string_release(right);
        return NULL;
    }
    zend_string *result = zend_string_alloc(len, 0);
    for (size_t i = 0; i < len; i++) {
        ZSTR_VAL(result)[i] = ZSTR_VAL(left)[i] ^ ZSTR_VAL(right)[i];
    }
    ZSTR_VAL(result)[len] = '\0';
    zend_string_release(left);
    zend_string_release(right);
    return result;
}

// 评估字符串按位或操作 (|)
static zend_string* evaluate_or_expression(zend_ast *expr) {
    if (!expr) return NULL;
    zend_string *left = evaluate_string_expression(expr->child[0]);
    zend_string *right = evaluate_string_expression(expr->child[1]);
    if (!left || !right) {
        if (left) zend_string_release(left);
        if (right) zend_string_release(right);
        return NULL;
    }
    // 取较短字符串的长度
    size_t len = ZSTR_LEN(left) < ZSTR_LEN(right) ? ZSTR_LEN(left) : ZSTR_LEN(right);
    if (len == 0) {
        zend_string_release(left);
        zend_string_release(right);
        return NULL;
    }
    zend_string *result = zend_string_alloc(len, 0);
    for (size_t i = 0; i < len; i++) {
        ZSTR_VAL(result)[i] = ZSTR_VAL(left)[i] | ZSTR_VAL(right)[i];
    }
    ZSTR_VAL(result)[len] = '\0';
    zend_string_release(left);
    zend_string_release(right);
    return result;
}

// 评估字符串按位与操作 (&)
static zend_string* evaluate_and_expression(zend_ast *expr) {
    if (!expr) return NULL;
    zend_string *left = evaluate_string_expression(expr->child[0]);
    zend_string *right = evaluate_string_expression(expr->child[1]);
    if (!left || !right) {
        if (left) zend_string_release(left);
        if (right) zend_string_release(right);
        return NULL;
    }
    // 取较短字符串的长度
    size_t len = ZSTR_LEN(left) < ZSTR_LEN(right) ? ZSTR_LEN(left) : ZSTR_LEN(right);
    if (len == 0) {
        zend_string_release(left);
        zend_string_release(right);
        return NULL;
    }
    zend_string *result = zend_string_alloc(len, 0);
    for (size_t i = 0; i < len; i++) {
        ZSTR_VAL(result)[i] = ZSTR_VAL(left)[i] & ZSTR_VAL(right)[i];
    }
    ZSTR_VAL(result)[len] = '\0';
    zend_string_release(left);
    zend_string_release(right);
    return result;
}

static zend_string* evaluate_strtr_strings(zend_string *input, zend_string *from, zend_string *to) {
    if (!input || !from || !to) {
        return NULL;
    }
    size_t map_len = ZSTR_LEN(from) < ZSTR_LEN(to) ? ZSTR_LEN(from) : ZSTR_LEN(to);
    if (map_len == 0) {
        return zend_string_copy(input);
    }
    zend_string *result = zend_string_init(ZSTR_VAL(input), ZSTR_LEN(input), 0);
    char *res = ZSTR_VAL(result);
    const char *from_val = ZSTR_VAL(from);
    const char *to_val = ZSTR_VAL(to);
    for (size_t i = 0; i < ZSTR_LEN(result); i++) {
        for (size_t j = 0; j < map_len; j++) {
            if (res[i] == from_val[j]) {
                res[i] = to_val[j];
                break;
            }
        }
    }
    return result;
}

static zend_string* evaluate_strtr_call(zend_ast *call_ast) {
    if (!call_ast) return NULL;
    zend_ast *args_ast = call_ast->child[1];
    if (!args_ast || !zend_ast_is_list(args_ast)) {
        return NULL;
    }
    zend_ast_list *args = zend_ast_get_list(args_ast);
    if (!args || args->children != 3 || !args->child) {
        return NULL;
    }
    zend_string *input = evaluate_string_expression(args->child[0]);
    zend_string *from = evaluate_string_expression(args->child[1]);
    zend_string *to = evaluate_string_expression(args->child[2]);
    if (!input || !from || !to) {
        if (input) zend_string_release(input);
        if (from) zend_string_release(from);
        if (to) zend_string_release(to);
        return NULL;
    }
    zend_string *result = evaluate_strtr_strings(input, from, to);
    zend_string_release(input);
    zend_string_release(from);
    zend_string_release(to);
    return result;
}

static zend_string* string_replace_all(zend_string *subject, zend_string *search, zend_string *replace) {
    if (!subject || !search || !replace || ZSTR_LEN(search) == 0) {
        return NULL;
    }
    const char *subject_val = ZSTR_VAL(subject);
    const char *search_val = ZSTR_VAL(search);
    size_t subject_len = ZSTR_LEN(subject);
    size_t search_len = ZSTR_LEN(search);
    size_t replace_len = ZSTR_LEN(replace);
    size_t count = 0;
    const char *cursor = subject_val;
    const char *end = subject_val + subject_len;
    while (cursor < end) {
        const char *found = strstr(cursor, search_val);
        if (!found) break;
        count++;
        cursor = found + search_len;
    }
    if (count == 0) {
        return zend_string_copy(subject);
    }
    size_t new_len = subject_len + count * (replace_len - search_len);
    zend_string *result = zend_string_alloc(new_len, 0);
    char *dst = ZSTR_VAL(result);
    cursor = subject_val;
    while (cursor < end) {
        const char *found = strstr(cursor, search_val);
        if (!found) {
            size_t remaining = end - cursor;
            memcpy(dst, cursor, remaining);
            dst += remaining;
            break;
        }
        size_t chunk = found - cursor;
        memcpy(dst, cursor, chunk);
        dst += chunk;
        memcpy(dst, ZSTR_VAL(replace), replace_len);
        dst += replace_len;
        cursor = found + search_len;
    }
    dst[0] = '\0';
    return result;
}

static zend_string* url_decode_string(zend_string *input, zend_bool raw) {
    if (!input) return NULL;
    zend_string *result = zend_string_alloc(ZSTR_LEN(input), 0);
    char *dst = ZSTR_VAL(result);
    const char *src = ZSTR_VAL(input);
    size_t len = ZSTR_LEN(input);
    size_t i = 0;
    while (i < len) {
        unsigned char c = (unsigned char)src[i];
        if (!raw && c == '+') {
            *dst++ = ' ';
            i++;
            continue;
        }
        if (c == '%' && i + 2 < len) {
            unsigned char high = (unsigned char)src[i + 1];
            unsigned char low = (unsigned char)src[i + 2];
            if (isxdigit(high) && isxdigit(low)) {
                char hex[3] = {(char)high, (char)low, '\0'};
                *dst++ = (char)strtol(hex, NULL, 16);
                i += 3;
                continue;
            }
        }
        *dst++ = (char)c;
        i++;
    }
    size_t out_len = dst - ZSTR_VAL(result);
    ZSTR_VAL(result)[out_len] = '\0';
    return zend_string_truncate(result, out_len, 0);
}

static zend_string* rot13_string(zend_string *input) {
    if (!input) return NULL;
    zend_string *result = zend_string_init(ZSTR_VAL(input), ZSTR_LEN(input), 0);
    char *val = ZSTR_VAL(result);
    for (size_t i = 0; i < ZSTR_LEN(result); i++) {
        unsigned char ch = (unsigned char)val[i];
        if (ch >= 'a' && ch <= 'z') {
            val[i] = 'a' + (ch - 'a' + 13) % 26;
        } else if (ch >= 'A' && ch <= 'Z') {
            val[i] = 'A' + (ch - 'A' + 13) % 26;
        }
    }
    return result;
}

static zend_string* base64_decode_string(zend_string *input) {
    if (!input) return NULL;
    static const signed char decode_table[256] = {
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,62,-1,-1,-1,63,
        52,53,54,55,56,57,58,59,60,61,-1,-1,-1,-2,-1,-1,
        -1,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,
        15,16,17,18,19,20,21,22,23,24,25,-1,-1,-1,-1,-1,
        -1,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,
        41,42,43,44,45,46,47,48,49,50,51,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1
    };
    size_t in_len = ZSTR_LEN(input);
    zend_string *result = zend_string_alloc((in_len / 4 + 1) * 3, 0);
    unsigned char *out = (unsigned char*)ZSTR_VAL(result);
    size_t out_len = 0;
    int val = 0;
    int bits = -8;
    const unsigned char *data = (const unsigned char*)ZSTR_VAL(input);
    for (size_t i = 0; i < in_len; i++) {
        signed char d = decode_table[data[i]];
        if (d == -1) {
            continue;
        }
        if (d == -2) {
            break;
        }
        val = (val << 6) + d;
        bits += 6;
        if (bits >= 0) {
            out[out_len++] = (unsigned char)((val >> bits) & 0xFF);
            bits -= 8;
        }
    }
    ZSTR_VAL(result)[out_len] = '\0';
    return zend_string_truncate(result, out_len, 0);
}


static zend_string* evaluate_string_call(zend_ast *call_ast) {
    if (!call_ast) return NULL;
    zend_ast *name_node = call_ast->child[0];
    if (!name_node || name_node->kind != ZEND_AST_ZVAL) {
        return NULL;
    }
    zval *zv = zend_ast_get_zval(name_node);
    if (!zv || Z_TYPE_P(zv) != IS_STRING) {
        return NULL;
    }
    zend_string *func_name = zend_ast_get_str(name_node);
    if (!func_name) {
        return NULL;
    }
    if (zend_string_equals_literal_ci(func_name, "strtr")) {
        return evaluate_strtr_call(call_ast);
    }
    if (zend_string_equals_literal_ci(func_name, "strrev")) {
        zend_ast *args_ast = call_ast->child[1];
        if (!args_ast || !zend_ast_is_list(args_ast)) {
            return NULL;
        }
        zend_ast_list *args = zend_ast_get_list(args_ast);
        if (!args || args->children != 1 || !args->child) {
            return NULL;
        }
        zend_string *value = evaluate_string_expression(args->child[0]);
        if (!value) {
            return NULL;
        }
        zend_string *result = zend_string_alloc(ZSTR_LEN(value), 0);
        char *res = ZSTR_VAL(result);
        for (size_t i = 0; i < ZSTR_LEN(value); i++) {
            res[i] = ZSTR_VAL(value)[ZSTR_LEN(value) - 1 - i];
        }
        res[ZSTR_LEN(value)] = '\0';
        zend_string_release(value);
        return result;
    }
    if (zend_string_equals_literal_ci(func_name, "strtolower")) {
        zend_ast *args_ast = call_ast->child[1];
        if (!args_ast || !zend_ast_is_list(args_ast)) {
            return NULL;
        }
        zend_ast_list *args = zend_ast_get_list(args_ast);
        if (!args || args->children != 1 || !args->child) {
            return NULL;
        }
        zend_string *value = evaluate_string_expression(args->child[0]);
        if (!value) {
            return NULL;
        }
        zend_string *result = zend_string_init(ZSTR_VAL(value), ZSTR_LEN(value), 0);
        for (size_t i = 0; i < ZSTR_LEN(result); i++) {
            ZSTR_VAL(result)[i] = tolower((unsigned char)ZSTR_VAL(result)[i]);
        }
        zend_string_release(value);
        return result;
    }
    if (zend_string_equals_literal_ci(func_name, "str_replace")) {
        return evaluate_str_replace_call(call_ast);
    }
    if (zend_string_equals_literal_ci(func_name, "base64_decode")) {
        return evaluate_base64_decode_call(call_ast);
    }
    if (zend_string_equals_literal_ci(func_name, "urldecode")) {
        return evaluate_url_decode_call(call_ast, 0);
    }
    if (zend_string_equals_literal_ci(func_name, "rawurldecode")) {
        return evaluate_url_decode_call(call_ast, 1);
    }
    if (zend_string_equals_literal_ci(func_name, "str_rot13")) {
        return evaluate_rot13_call(call_ast);
    }
    return NULL;
}

static zend_string* evaluate_str_replace_call(zend_ast *call_ast) {
    zend_ast *args_ast = call_ast->child[1];
    if (!args_ast || !zend_ast_is_list(args_ast)) {
        return NULL;
    }
    zend_ast_list *args = zend_ast_get_list(args_ast);
    if (!args || args->children < 3 || !args->child) {
        return NULL;
    }
    zend_string *search = evaluate_string_expression(args->child[0]);
    zend_string *replace = evaluate_string_expression(args->child[1]);
    zend_string *subject = evaluate_string_expression(args->child[2]);
    if (!search || !replace || !subject) {
        if (search) zend_string_release(search);
        if (replace) zend_string_release(replace);
        if (subject) zend_string_release(subject);
        return NULL;
    }
    zend_string *result = string_replace_all(subject, search, replace);
    zend_string_release(search);
    zend_string_release(replace);
    zend_string_release(subject);
    return result;
}

static zend_string* evaluate_base64_decode_call(zend_ast *call_ast) {
    zend_ast *args_ast = call_ast->child[1];
    if (!args_ast || !zend_ast_is_list(args_ast)) {
        return NULL;
    }
    zend_ast_list *args = zend_ast_get_list(args_ast);
    if (args->children < 1) {
        return NULL;
    }
    zend_string *value = evaluate_string_expression(args->child[0]);
    if (!value) {
        return NULL;
    }
    zend_string *result = base64_decode_string(value);
    zend_string_release(value);
    return result;
}

static zend_string* evaluate_url_decode_call(zend_ast *call_ast, zend_bool raw) {
    zend_ast *args_ast = call_ast->child[1];
    if (!args_ast || !zend_ast_is_list(args_ast)) {
        return NULL;
    }
    zend_ast_list *args = zend_ast_get_list(args_ast);
    if (args->children < 1) {
        return NULL;
    }
    zend_string *value = evaluate_string_expression(args->child[0]);
    if (!value) {
        return NULL;
    }
    zend_string *result = url_decode_string(value, raw);
    zend_string_release(value);
    return result;
}

static zend_string* evaluate_rot13_call(zend_ast *call_ast) {
    zend_ast *args_ast = call_ast->child[1];
    if (!args_ast || !zend_ast_is_list(args_ast)) {
        return NULL;
    }
    zend_ast_list *args = zend_ast_get_list(args_ast);
    if (args->children < 1) {
        return NULL;
    }
    zend_string *value = evaluate_string_expression(args->child[0]);
    if (!value) {
        return NULL;
    }
    zend_string *result = rot13_string(value);
    zend_string_release(value);
    return result;
}

static zend_string* evaluate_string_expression(zend_ast *expr) {
    if (!expr) return NULL;
    switch (expr->kind) {
        case ZEND_AST_ZVAL: {
            zval *zv = zend_ast_get_zval(expr);
            if (!zv || Z_TYPE_P(zv) != IS_STRING) {
                return NULL;
            }
            return zend_string_copy(Z_STR_P(zv));
        }
        case ZEND_AST_VAR: {
            // 支持变量引用，如 $a, $s 等
            zend_ast *name_node = expr->child[0];
            if (!name_node || name_node->kind != ZEND_AST_ZVAL) {
                return NULL;
            }
            zval *zv = zend_ast_get_zval(name_node);
            if (!zv || Z_TYPE_P(zv) != IS_STRING) {
                return NULL;
            }
            zend_string *var_name = zend_ast_get_str(name_node);
            if (!var_name) {
                return NULL;
            }
            // 从变量值表中查找变量值
            zval *var_val = zend_hash_find(&var_value_table, var_name);
            if (var_val && Z_TYPE_P(var_val) == IS_STRING) {
                return zend_string_copy(Z_STR_P(var_val));
            }
            return NULL;
        }
        case ZEND_AST_CALL:
            return evaluate_string_call(expr);
        case ZEND_AST_BINARY_OP:
            if (expr->attr == ZEND_CONCAT) {
                return evaluate_concat_expression(expr);
            } else if (expr->attr == ZEND_BW_XOR) {
                // 字符串异或操作 (^)
                return evaluate_xor_expression(expr);
            } else if (expr->attr == ZEND_BW_OR) {
                // 字符串按位或操作 (|)
                return evaluate_or_expression(expr);
            } else if (expr->attr == ZEND_BW_AND) {
                // 字符串按位与操作 (&)
                return evaluate_and_expression(expr);
            }
            return NULL;
        default:
            return NULL;
    }
}

/* 统一调用图（合并静态和动态调用图） */
static HashTable merged_call_graph;

/* 建议1：合并静态和动态调用图 */
static void merge_call_graphs(void) {
    /* 初始化合并后的调用图 */
    zend_hash_init(&merged_call_graph, 8, NULL, ZVAL_PTR_DTOR, 0);
    
    /* 1. 先把 call_graph_static 拷贝进 merged */
    zend_string *caller_key;
    zval *caller_val;
    ZEND_HASH_FOREACH_STR_KEY_VAL(&call_graph_static, caller_key, caller_val) {
        if (caller_key && caller_val && Z_TYPE_P(caller_val) == IS_PTR) {
            HashTable *static_callee_set = (HashTable *)Z_PTR_P(caller_val);
            
            /* 在 merged_call_graph 中查找或创建 caller */
            zend_string *caller_str = zend_string_copy(caller_key);
            zval *merged_caller_val = zend_hash_find(&merged_call_graph, caller_str);
            HashTable *merged_callee_set = NULL;
            
            if (merged_caller_val && Z_TYPE_P(merged_caller_val) == IS_PTR) {
                merged_callee_set = (HashTable *)Z_PTR_P(merged_caller_val);
            } else {
                merged_callee_set = (HashTable *)emalloc(sizeof(HashTable));
                zend_hash_init(merged_callee_set, 8, NULL, NULL, 1);
                
                zval new_caller_val;
                ZVAL_PTR(&new_caller_val, merged_callee_set);
                zend_hash_add(&merged_call_graph, caller_str, &new_caller_val);
            }
            
            /* 将静态调用图的 callee 添加到合并图中 */
            if (merged_callee_set && static_callee_set) {
                zend_string *callee_key;
                ZEND_HASH_FOREACH_STR_KEY(static_callee_set, callee_key) {
                    if (callee_key && !zend_hash_exists(merged_callee_set, callee_key)) {
                        zval callee_val;
                        ZVAL_LONG(&callee_val, 1);
                        zend_hash_add(merged_callee_set, callee_key, &callee_val);
                    }
                } ZEND_HASH_FOREACH_END();
            }
        }
    } ZEND_HASH_FOREACH_END();
    
    /* 2. 再把 call_graph_extra 里的边插进去（不存在就加，存在就保持） */
    ZEND_HASH_FOREACH_STR_KEY_VAL(&call_graph_extra, caller_key, caller_val) {
        if (caller_key && caller_val && Z_TYPE_P(caller_val) == IS_PTR) {
            HashTable *extra_callee_set = (HashTable *)Z_PTR_P(caller_val);
            
            /* 在 merged_call_graph 中查找或创建 caller */
            zend_string *caller_str = zend_string_copy(caller_key);
            zval *merged_caller_val = zend_hash_find(&merged_call_graph, caller_str);
            HashTable *merged_callee_set = NULL;
            
            if (merged_caller_val && Z_TYPE_P(merged_caller_val) == IS_PTR) {
                merged_callee_set = (HashTable *)Z_PTR_P(merged_caller_val);
            } else {
                merged_callee_set = (HashTable *)emalloc(sizeof(HashTable));
                zend_hash_init(merged_callee_set, 8, NULL, NULL, 1);
                
                zval new_caller_val;
                ZVAL_PTR(&new_caller_val, merged_callee_set);
                zend_hash_add(&merged_call_graph, caller_str, &new_caller_val);
            }
            
            /* 将动态调用图的 callee 添加到合并图中 */
            if (merged_callee_set && extra_callee_set) {
                zend_string *callee_key;
                ZEND_HASH_FOREACH_STR_KEY(extra_callee_set, callee_key) {
                    if (callee_key && !zend_hash_exists(merged_callee_set, callee_key)) {
                        zval callee_val;
                        ZVAL_LONG(&callee_val, 1);
                        zend_hash_add(merged_callee_set, callee_key, &callee_val);
                    }
                } ZEND_HASH_FOREACH_END();
            }
        }
    } ZEND_HASH_FOREACH_END();
    
    printf("已合并静态和动态调用图，合并后共有 %u 个调用者\n", 
           zend_hash_num_elements(&merged_call_graph));
}

/* 建议2：基于调用图的全局污点路径搜索 */
static int path_search_from_entry_to_sink(const char *entry_func, HashTable *visited) {
    if (!entry_func || !visited) return 0;
    
    zend_string *entry_str = zend_string_init(entry_func, strlen(entry_func), 0);
    
    /* 检查是否已访问过（避免循环） */
    if (zend_hash_exists(visited, entry_str)) {
        zend_string_release(entry_str);
        return 0;
    }
    
    /* 标记为已访问 */
    zval visit_val;
    ZVAL_LONG(&visit_val, 1);
    zend_hash_add(visited, entry_str, &visit_val);
    
    /* 在合并调用图中查找该函数的调用关系 */
    zval *caller_val = zend_hash_find(&merged_call_graph, entry_str);
    int found_sink = 0;
    
    if (caller_val && Z_TYPE_P(caller_val) == IS_PTR) {
        HashTable *callee_set = (HashTable *)Z_PTR_P(caller_val);
        if (callee_set) {
            zend_string *callee_key;
            ZEND_HASH_FOREACH_STR_KEY(callee_set, callee_key) {
                if (callee_key) {
                    /* 检查是否是危险函数（sink） */
                    if (is_known_sink_function(callee_key)) {
                        printf("发现从入口 %s 到危险函数 %s 的调用路径（通过调用图）\n", 
                               entry_func, ZSTR_VAL(callee_key));
                        found_sink = 1;
                    } else {
                        /* 递归搜索 */
                        found_sink = path_search_from_entry_to_sink(ZSTR_VAL(callee_key), visited);
                        if (found_sink) break;
                    }
                }
            } ZEND_HASH_FOREACH_END();
        }
    }
    
    zend_string_release(entry_str);
    return found_sink;
}

/* 全局标志：通过调用图发现的危险路径 */
static int global_dynamic_path_detected = 0;

/* 建议2：全局污点分析（利用合并后的调用图） */
static void global_taint_analysis_with_cg(void) {
    printf("开始基于调用图的全局污点分析...\n");
    
    /* 入口点：__main__ 或已知的源函数 */
    const char *entry_points[] = {"__main__"};
    size_t num_entries = sizeof(entry_points) / sizeof(entry_points[0]);
    
    HashTable visited;
    zend_hash_init(&visited, 8, NULL, NULL, 1);
    
    for (size_t i = 0; i < num_entries; i++) {
        if (path_search_from_entry_to_sink(entry_points[i], &visited)) {
            printf("警告：通过动态补充的调用图，发现从 %s 到危险函数的路径\n", 
                   entry_points[i]);
            global_dynamic_path_detected = 1;  /* 设置全局标志 */
        }
    }
    
    zend_hash_destroy(&visited);
}

/* 构建静态调用图：收集静态可解析的函数调用 */
static void build_static_call_graph(zend_ast *ast) {
    if (!ast) return;
    Stack *stack = (Stack *)malloc(sizeof(Stack));
    initStack(stack, 10000);  // 增加栈大小以处理大型AST
    push(stack, ast);
    
    zend_string *current_caller = NULL;  // 当前函数名
    
    while (!isEmpty(stack)) {
        zend_ast *current = pop(stack);
        if (!current) continue;
        
        /* 跟踪当前函数名 */
        if (current->kind == ZEND_AST_FUNC_DECL || current->kind == ZEND_AST_METHOD) {
            zend_ast_decl *decl = (zend_ast_decl *)current;
            if (decl->name) {
                if (current_caller) {
                    zend_string_release(current_caller);
                }
                current_caller = zend_string_copy(decl->name);
            }
        }
        
        /* 收集静态可解析的函数调用（函数名是直接字符串，不是变量） */
        if (current->kind == ZEND_AST_CALL) {
            zend_ast *func_ast = current->child[0];
            if (func_ast && func_ast->kind == ZEND_AST_ZVAL) {
                zval *zv = zend_ast_get_zval(func_ast);
                if (zv && Z_TYPE_P(zv) == IS_STRING) {
                    zend_string *callee = zend_ast_get_str(func_ast);
                    const char *caller_name = current_caller ? ZSTR_VAL(current_caller) : "__main__";
                    
                    zend_string *caller_str = zend_string_init(caller_name, strlen(caller_name), 0);
                    
                    /* 检查 call_graph_static 中是否已有该 caller */
                    zval *caller_val = zend_hash_find(&call_graph_static, caller_str);
                    HashTable *callee_set = NULL;
                    
                    if (caller_val && Z_TYPE_P(caller_val) == IS_PTR) {
                        callee_set = (HashTable *)Z_PTR_P(caller_val);
                    } else {
                        /* 创建新的 callee 集合 */
                        callee_set = (HashTable *)emalloc(sizeof(HashTable));
                        zend_hash_init(callee_set, 8, NULL, NULL, 1);
                        
                        zval new_caller_val;
                        ZVAL_PTR(&new_caller_val, callee_set);
                        zend_hash_add(&call_graph_static, caller_str, &new_caller_val);
                    }
                    
                    /* 将 callee 添加到集合中 */
                    if (callee_set) {
                        zval callee_val;
                        ZVAL_LONG(&callee_val, 1);
                        zend_hash_add(callee_set, callee, &callee_val);
                    }
                    
                    zend_string_release(caller_str);
                }
            }
        }
        
        uint32_t count = 0;
        zend_ast **children = ast_get_children(current, &count);
        for (uint32_t i = 0; i < count; i++) {
            if (children[i]) {
                push(stack, children[i]);
            }
        }
    }
    
    if (current_caller) {
        zend_string_release(current_caller);
    }
    
    free(stack->data);
    free(stack);
}

static void dynamic_function_analysis(zend_ast *ast) {
    if (!ast) return;
    Stack *stack = (Stack *)malloc(sizeof(Stack));
    initStack(stack, 10000);  // 增加栈大小以处理大型AST
    push(stack, ast);
    while (!isEmpty(stack)) {
        zend_ast *current = pop(stack);
        if (!current) continue;
        
        /* 跟踪当前函数名（用于记录调用者） */
        if (current->kind == ZEND_AST_FUNC_DECL || current->kind == ZEND_AST_METHOD) {
            zend_ast_decl *decl = (zend_ast_decl *)current;
            if (decl->name) {
                if (current_function_name) {
                    zend_string_release(current_function_name);
                }
                current_function_name = zend_string_copy(decl->name);
            }
        }
        
        if (current->kind == ZEND_AST_ASSIGN) {
            zend_ast *var_node = current->child[0];
            zend_ast *expr_node = current->child[1];
            if (var_node && expr_node) {
                zend_string *resolved = evaluate_string_expression(expr_node);
                if (resolved) {
                    if (is_known_sink_function(resolved)) {
                        add_sink_var_from_assignment(var_node, resolved);
                        printf("静态识别危险函数变量: 通过字符串表达式求值得到 %s\n", ZSTR_VAL(resolved));
                    }
                    zend_string_release(resolved);
                } else {
                    /* 如果表达式包含位运算（异或、按位或、按位与），可能是混淆的代码
                     * 尝试检测是否可能是危险函数名 */
                    if (expr_node->kind == ZEND_AST_BINARY_OP) {
                        // 检查是否是位运算操作
                        if (expr_node->attr == ZEND_BW_XOR || 
                            expr_node->attr == ZEND_BW_OR || 
                            expr_node->attr == ZEND_BW_AND) {
                            // 对于混淆代码，即使无法静态求值，也应该标记为可疑
                            // 如果变量后续被用于函数调用，应该被检测
                            if (var_node->kind == ZEND_AST_VAR) {
                                // 标记这个变量为可疑，需要动态检测
                                var_node->tainted |= AST_NEED_DYNAMIC_RESOLVE;
                                printf("警告: 检测到可能混淆的函数名赋值（包含位运算），变量需要动态检测\n");
                            }
                        }
                    }
                    /* TODO 3: 静态搞不定，标记为需要动态解析 */
                    /* 如果 var_node 是变量，标记它需要动态解析 */
                    if (var_node->kind == ZEND_AST_VAR) {
                        var_node->tainted |= AST_NEED_DYNAMIC_RESOLVE;
                    }
                }
            }
        }
        uint32_t count = 0;
        zend_ast **children = ast_get_children(current, &count);
        for (uint32_t i = 0; i < count; i++) {
            if (children[i]) {
                push(stack, children[i]);
            }
        }
    }
    free(stack->data);
    free(stack);
}

//对各个可能产生危险的语法节点进行assert插入检测
void traverse_and_modify_ast(zend_ast *ast, zend_arena **ast_arena, HashTable *var_table) {
    Stack* stack = (Stack*)malloc(sizeof(Stack));
    initStack(stack, 10000);  // 增加栈大小以处理大型AST
    push(stack, ast);

    while (!isEmpty(stack)) {
        zend_ast* current = pop(stack);
        if (!current) continue;
        
        // 验证 current 节点是否仍然有效
        if (current->kind > 1000) {
            continue;  // 跳过无效的节点类型
        }

        int ast_modified = 0;  // 标记AST是否被修改

        /* 1) 函数调用相关：$var() / $arr['x']() 插桩 */
        if (current->kind == ZEND_AST_CALL) {
            zend_ast *func_ast = current->child[0];
            if (!func_ast) {
                // 继续遍历子节点
                uint32_t count = 0;
                zend_ast **children = ast_get_children(current, &count);
                for (uint32_t i = 0; i < count; i++) {
                    if (children[i]) push(stack, children[i]);
                }
                continue;
            }

            /* 1.1 $var() 形式 - 动态函数调用 */
            if (func_ast->kind == ZEND_AST_VAR) {
                // 安全地获取 parent，检查 current 是否仍然有效
                zend_ast *parent = NULL;
                if (current && current->father) {
                    parent = current->father;
                    // 验证 parent 是否仍然有效（检查它是否仍然是有效的 AST 节点）
                    if (parent->kind > 1000) {
                        parent = NULL;  // 无效的节点类型
                    }
                }
                if (!parent || parent->kind != ZEND_AST_STMT_LIST) {
                    // 继续遍历子节点
                    uint32_t count = 0;
                    zend_ast **children = ast_get_children(current, &count);
                    for (uint32_t i = 0; i < count; i++) {
                        if (children[i]) push(stack, children[i]);
                    }
                    continue;
                }
                
                /* 建议3：根据 AST_NEED_DYNAMIC_RESOLVE 标记决定是否插桩 */
                bool should_instrument = true;
                if (func_ast->tainted & AST_NEED_DYNAMIC_RESOLVE) {
                    /* 静态搞不定的变量，需要动态解析，应该插桩 */
                    printf("检测到需要动态解析的变量函数调用，将进行插桩\n");
                    should_instrument = true;
                } else {
                    /* 静态能解析的变量，可以选择不插桩或插简单日志 */
                    /* 为了保持兼容性，这里仍然插桩，但可以添加标记 */
                    should_instrument = true;
                }
                
                const char *var_name = get_var_name(func_ast);
                if (var_name && should_instrument) {
                    zend_ast_list *list = zend_ast_get_list(parent);
                    if (!list) {
                        // 继续遍历子节点
                        uint32_t count = 0;
                        zend_ast **children = ast_get_children(current, &count);
                        for (uint32_t i = 0; i < count; i++) {
                            if (children[i]) push(stack, children[i]);
                        }
                        continue;
                    }
                    
                    for (uint32_t i = 0; i < list->children; i++) {
                        if (list->child[i] == current) {
                            zend_ast *new_list = insert_assert_before_at_index(
                                parent, i, ast_arena, (char*)var_name);
                            if (new_list && new_list != parent) {
                                // insert_assert_before_at_index 已经更新了所有子节点的 father 指针
                                // 包括 current 节点，所以 current->father 应该已经指向 new_list 了
                                
                                // 重要：在替换 parent 之前，确保 current->father 已经正确更新
                                // 因为 replace_child_in_parent 可能会访问 parent->father
                                zend_ast_list *new_list_ptr = zend_ast_get_list(new_list);
                                if (new_list_ptr && i + 1 < new_list_ptr->children) {
                                    // current 在新列表中的位置是 i+1（因为我们在 i 位置插入了新节点）
                                    if (new_list_ptr->child[i + 1] == current) {
                                        // 确保 current->father 指向 new_list
                                        current->father = new_list;
                                    }
                                }
                                
                                // 现在安全地替换 parent
                                if (parent->father) {
                                    replace_child_in_parent(parent->father, parent, new_list);
                                } else {
                                    g_root_ast = new_list;
                                }
                                
                                // 重要：修改 AST 后，不要继续访问 current 或 parent
                                ast_modified = 1;
                                break;  // 立即退出循环
                            }
                            break;
                        }
                    }
                }
                /* 处理完动态函数调用后，跳过后续的静态函数处理 */
                if (ast_modified) {
                    continue;
                }
            }
            /* 1.2 $arr['x']() 形式 */
            else if (func_ast->kind == ZEND_AST_DIM) {
                zend_ast *dim_var = func_ast->child[0];
                if (!dim_var) {
                    // 继续遍历子节点
                    uint32_t count = 0;
                    zend_ast **children = ast_get_children(current, &count);
                    for (uint32_t i = 0; i < count; i++) {
                        if (children[i]) push(stack, children[i]);
                    }
                    continue;
                }
                
                const char *var_name = get_var_name(dim_var);
                if (var_name) {
                    char tmp_var_name[32];
                    snprintf(tmp_var_name, sizeof(tmp_var_name), "__tmp_");
                    strncat(tmp_var_name, var_name, sizeof(tmp_var_name) - strlen(tmp_var_name) - 1);

                    zend_ast *assign_ast = deep_copy_dim_to_var(func_ast, ast_arena, tmp_var_name);
                    zend_ast *parent = current->father;
                    if (parent && parent->kind == ZEND_AST_STMT_LIST) {
                        zend_ast_list *list = zend_ast_get_list(parent);
                        if (list) {
                            for (uint32_t i = 0; i < list->children; i++) {
                                if (list->child[i] == current) {
                                    // 先插入赋值，再插入断言
                                    zend_ast *new_list = insert_stmt_before_at_index(
                                        parent, i, assign_ast, ast_arena);
                                    if (new_list && new_list != parent) {
                                        // insert_stmt_before_at_index 已经更新了所有子节点的 father 指针
                                        // 包括 current 节点，所以 current->father 已经指向 new_list 了
                                        
                                        new_list = insert_assert_before_at_index(
                                            new_list, i + 1, ast_arena, tmp_var_name);
                                        if (new_list) {
                                            // insert_assert_before_at_index 已经更新了所有子节点的 father 指针
                                            // 包括 current 节点，所以 current->father 已经指向 new_list 了
                                            
                                            if (parent->father) {
                                                replace_child_in_parent(parent->father, parent, new_list);
                                            } else {
                                                g_root_ast = new_list;
                                            }
                                            ast_modified = 1;
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                    }
                }
                /* 处理完数组形式动态调用后，跳过后续的静态函数处理 */
                if (ast_modified) {
                    continue;
                }
            }
            /* 1.3 静态已知危险函数调用（如 eval, system, assert 等）—— 统一插入 assert probe */
            else if (func_ast->kind == ZEND_AST_ZVAL) {
                zval *zv = zend_ast_get_zval(func_ast);
                if (zv && Z_TYPE_P(zv) == IS_STRING) {
                    zend_string *func_name = zend_ast_get_str(func_ast);
                    /* 检查是否是已知的危险函数 */
                    if (is_known_sink_function(func_name)) {
                        /* 找到所在语句和语句列表 */
                        zend_ast *stmt_list_ast = NULL;
                        zend_ast *stmt_ast = find_stmt_and_list_for_node(current, &stmt_list_ast);
                        
                        if (stmt_ast && stmt_list_ast && stmt_list_ast->kind == ZEND_AST_STMT_LIST) {
                            zend_ast_list *list = zend_ast_get_list(stmt_list_ast);
                            if (list) {
                                for (uint32_t i = 0; i < list->children; i++) {
                                    if (list->child[i] == stmt_ast) {
                                        /* 获取第一个参数（如果有） */
                                        zend_ast *first_arg = NULL;
                                        if (current->child[1] && current->child[1]->kind == ZEND_AST_ARG_LIST) {
                                            zend_ast_list *args = zend_ast_get_list(current->child[1]);
                                            if (args && args->children > 0 && args->child) {
                                                first_arg = args->child[0];
                                            }
                                        }
                                        
                                        /* 构造 __yz_runtime_probe("sink_call", __FILE__, __LINE__, __FUNCTION__, func_name, first_arg) */
                                        /* 先构造函数名字符串节点 */
                                        zval *func_name_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
                                        ZVAL_STR(func_name_zv, zend_string_copy(func_name));
                                        zend_ast *func_name_ast = (zend_ast *)my_create_zval_ast_arena(func_name_zv, NULL, ast_arena);
                                        
                                        zend_ast *probe_call = build_probe_call_for_call_ast(
                                            current,
                                            ast_arena,
                                            "sink_call",
                                            func_name_ast,  // callee_ast，函数名
                                            first_arg       // first_arg_ast，第一个参数
                                        );
                                        
                                        if (probe_call) {
                                            /* 构造 assert(__yz_runtime_probe(...)) */
                                            zval *assert_name_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
                                            ZVAL_STR(assert_name_zv, zend_string_init("assert", 6, 0));
                                            zend_ast *assert_name_ast = (zend_ast *)my_create_zval_ast_arena(assert_name_zv, NULL, ast_arena);
                                            
                                            zend_ast_list *assert_args = my_create_ast_list_arena(1, ZEND_AST_ARG_LIST, ast_arena);
                                            assert_args->child[0] = probe_call;
                                            
                                            zend_ast *assert_call = my_ast_create_ex_arena(ZEND_AST_CALL, 2, ast_arena,
                                                assert_name_ast, (zend_ast*)assert_args);
                                            
                                            /* 把 assert 语句插入到这条语句之前 */
                                            zend_ast *new_list = insert_stmt_before_at_index(stmt_list_ast, i, assert_call, ast_arena);
                                            
                                            /* 用新的 stmt_list 替换原来的 */
                                            if (new_list && new_list != stmt_list_ast) {
                                                new_list->father = stmt_list_ast->father;
                                                
                                                if (stmt_list_ast->father) {
                                                    replace_child_in_parent(stmt_list_ast->father, stmt_list_ast, new_list);
                                                } else {
                                                    g_root_ast = new_list;
                                                }
                                                ast_modified = 1;
                                                printf("已为危险函数 %s 插入断言探针\n", ZSTR_VAL(func_name));
                                            }
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                        /* 处理完静态危险函数后，标记已修改，跳过后续处理 */
                        if (ast_modified) {
                            continue;
                        }
                    }
                }
            }
        }
        /* 3) eval/include 相关断言插桩 —— 使用 assert(__yz_runtime_probe(...)) */
        else if (current->kind == ZEND_AST_INCLUDE_OR_EVAL) {
            // 找到"所在语句"以及它的语句列表
            zend_ast *stmt_list_ast = NULL;
            zend_ast *stmt_ast = find_stmt_and_list_for_node(current, &stmt_list_ast);

            if (stmt_ast && stmt_list_ast && stmt_list_ast->kind == ZEND_AST_STMT_LIST) {
                zend_ast_list *list = zend_ast_get_list(stmt_list_ast);
                if (list) {
                    for (uint32_t i = 0; i < list->children; i++) {
                        if (list->child[i] == stmt_ast) {
                            /* 获取 eval 的参数（代码字符串） */
                            zend_ast *eval_arg = NULL;
                            if (current->child && current->child[0]) {
                                eval_arg = current->child[0];
                            }
                            
                            /* 构造 __yz_runtime_probe("eval", __FILE__, __LINE__, __FUNCTION__, $code_str) */
                            zend_ast *probe_call = build_probe_call_for_call_ast(
                                current,
                                ast_arena,
                                "eval",
                                NULL,      // callee_ast，eval 不需要
                                eval_arg   // first_arg_ast，eval 的代码字符串
                            );
                            
                            if (probe_call) {
                                /* 构造 assert(__yz_runtime_probe(...)) */
                                zval *assert_name_zv = (zval *)zend_arena_alloc(ast_arena, sizeof(zval));
                                ZVAL_STR(assert_name_zv, zend_string_init("assert", 6, 0));
                                zend_ast *assert_name_ast = (zend_ast *)my_create_zval_ast_arena(assert_name_zv, NULL, ast_arena);
                                
                                zend_ast_list *assert_args = my_create_ast_list_arena(1, ZEND_AST_ARG_LIST, ast_arena);
                                assert_args->child[0] = probe_call;
                                
                                zend_ast *assert_call = my_ast_create_ex_arena(ZEND_AST_CALL, 2, ast_arena,
                                    assert_name_ast, (zend_ast*)assert_args);
                                
                                /* 把 assert 语句插入到这条语句之前 */
                                zend_ast *new_list = insert_stmt_before_at_index(stmt_list_ast, i, assert_call, ast_arena);

                                /* 用新的 stmt_list 替换原来的 */
                                if (new_list && new_list != stmt_list_ast) {
                                    // 更新 new_list 的 father 指针
                                    new_list->father = stmt_list_ast->father;
                                    
                                    if (stmt_list_ast->father) {
                                        replace_child_in_parent(stmt_list_ast->father, stmt_list_ast, new_list);
                                    } else {
                                        g_root_ast = new_list;
                                    }
                                    ast_modified = 1;
                                }
                            }
                            break;
                        }
                    }
                }
            }
        }

        /* 如果AST被修改，跳过继续遍历当前节点的子节点，因为结构已经改变 */
        if (ast_modified) {
            // 重要：修改 AST 后，current 节点可能已经被替换或失效
            // 不要继续访问 current 的任何字段，直接跳过
            continue;
        }

        /* 继续遍历子节点 */
        // 在访问 current 的子节点之前，再次验证 current 是否仍然有效
        if (!current) {
            continue;
        }
        
        uint32_t count;
        zend_ast **children = ast_get_children(current, &count);
        if (!children) {
            continue;
        }
        
        for (uint32_t i = 0; i < count; i++) {
            if (children[i]) {
                // 验证子节点是否仍然有效
                if (children[i]->kind > 1000) {
                    continue;  // 跳过无效的节点类型
                }
                push(stack, children[i]);
            }
        }
    }

    free(stack->data);
    free(stack);
}


/* 辅助函数：从 JSON 字符串中提取字段值（简单实现，不依赖 JSON 库） */
static int extract_json_string_field(const char *json_str, const char *field_name, char *output, size_t output_size) {
    char search_pattern[256];
    snprintf(search_pattern, sizeof(search_pattern), "\"%s\"", field_name);
    
    const char *field_pos = strstr(json_str, search_pattern);
    if (!field_pos) {
        return 0;
    }
    
    /* 找到冒号 */
    const char *colon_pos = strchr(field_pos, ':');
    if (!colon_pos) {
        return 0;
    }
    
    /* 跳过空白字符 */
    colon_pos++;
    while (*colon_pos == ' ' || *colon_pos == '\t') {
        colon_pos++;
    }
    
    /* 提取字符串值（支持双引号字符串） */
    if (*colon_pos == '"') {
        colon_pos++;  // 跳过开头的引号
        size_t i = 0;
        while (*colon_pos != '"' && *colon_pos != '\0' && i < output_size - 1) {
            if (*colon_pos == '\\' && *(colon_pos + 1) == '"') {
                output[i++] = '"';
                colon_pos += 2;
            } else {
                output[i++] = *colon_pos++;
            }
        }
        output[i] = '\0';
        return 1;
    }
    
    /* 提取数字值（用于 line 字段） */
    if (*colon_pos >= '0' && *colon_pos <= '9') {
        size_t i = 0;
        while (*colon_pos >= '0' && *colon_pos <= '9' && i < output_size - 1) {
            output[i++] = *colon_pos++;
        }
        output[i] = '\0';
        return 1;
    }
    
    return 0;
}

/* 建议4：检查是否有断言失败或探针命中 */
static int has_assert_fail_or_probe_hit(void) {
    return dynamic_webshell_hit > 0;
}

/* 从动态日志中读取并更新调用图 */
static void load_dynamic_edges_and_update_graph(const char *log_path) {
    FILE *fp = fopen(log_path, "r");
    if (!fp) {
        /* 日志文件不存在是正常的（可能没有执行插桩后的脚本） */
        return;
    }
    
    char buf[4096];
    int line_count = 0;
    
    printf("正在读取动态日志: %s\n", log_path);
    
    while (fgets(buf, sizeof(buf), fp)) {
        line_count++;
        
        /* 移除换行符 */
        size_t len = strlen(buf);
        if (len > 0 && buf[len - 1] == '\n') {
            buf[len - 1] = '\0';
        }
        
        /* 跳过空行 */
        if (len <= 1) {
            continue;
        }
        
        /* 检查日志类型 - 新的调用图日志格式 */
        if (strstr(buf, "\"type\":\"dyn_call\"") || strstr(buf, "\"type\":\"dyn_call\"")) {
            /* 解析 file, line, caller, callee 字段 */
            char file[512] = {0};
            char line_str[64] = {0};
            char caller[256] = {0};
            char callee[256] = {0};
            
            extract_json_string_field(buf, "file", file, sizeof(file));
            extract_json_string_field(buf, "line", line_str, sizeof(line_str));
            extract_json_string_field(buf, "caller", caller, sizeof(caller));
            
            if (extract_json_string_field(buf, "callee", callee, sizeof(callee))) {
                if (strlen(callee) > 0 && strcmp(callee, "null") != 0) {
                    zend_string *func_name = zend_string_init(callee, strlen(callee), 0);
                    const char *caller_name = strlen(caller) > 0 ? caller : "__main__";
                    
                    printf("动态确认函数调用: %s -> %s (file: %s, line: %s)\n", 
                           caller_name, callee, strlen(file) > 0 ? file : "?", line_str);
                    
                    /* 将调用边添加到 call_graph_extra */
                    zend_string *caller_str = zend_string_init(caller_name, strlen(caller_name), 0);
                    
                    /* 检查 call_graph_extra 中是否已有该 caller */
                    zval *caller_val = zend_hash_find(&call_graph_extra, caller_str);
                    HashTable *callee_set = NULL;
                    
                    if (caller_val && Z_TYPE_P(caller_val) == IS_PTR) {
                        callee_set = (HashTable *)Z_PTR_P(caller_val);
                    } else {
                        /* 创建新的 callee 集合 */
                        callee_set = (HashTable *)emalloc(sizeof(HashTable));
                        zend_hash_init(callee_set, 8, NULL, NULL, 1);
                        
                        zval new_caller_val;
                        ZVAL_PTR(&new_caller_val, callee_set);
                        zend_hash_add(&call_graph_extra, caller_str, &new_caller_val);
                    }
                    
                    /* 将 callee 添加到集合中 */
                    if (callee_set) {
                        zval callee_val;
                        ZVAL_LONG(&callee_val, 1);
                        zend_hash_add(callee_set, func_name, &callee_val);
                        printf("  添加动态调用边: %s -> %s\n", caller_name, callee);
                    }
                    
                    zend_string_release(caller_str);
                    
                    /* 检查是否是已知的危险函数 */
                    if (is_known_sink_function(func_name)) {
                        /* 将函数名添加到 sink_func_table（如果还没有） */
                        if (!zend_hash_exists(&sink_func_table, func_name)) {
                            zval func_val;
                            ZVAL_LONG(&func_val, sink_func_count);
                            sink_func_count++;
                            zend_hash_add(&sink_func_table, func_name, &func_val);
                            printf("已将危险函数 %s 添加到 sink_func_table\n", callee);
                        }
                    }
                    
                    zend_string_release(func_name);
                }
            }
        }
        else if (strstr(buf, "\"type\":\"eval\"") || strstr(buf, "\"type\":\"eval\"")) {
            /* 处理 EVAL 类型的日志 - 记录到 suspect_site_table */
            char line_str[64] = {0};
            if (extract_json_string_field(buf, "line", line_str, sizeof(line_str))) {
                printf("动态确认 EVAL 调用: line=%s\n", line_str);
                
                /* 构建 key: "file:line" */
                char site_key[512] = {0};
                if (current_filename) {
                    snprintf(site_key, sizeof(site_key), "%s:%s", 
                            ZSTR_VAL(current_filename), line_str);
                } else {
                    snprintf(site_key, sizeof(site_key), "?:%s", line_str);
                }
                
                zend_string *site_key_str = zend_string_init(site_key, strlen(site_key), 0);
                if (!zend_hash_exists(&suspect_site_table, site_key_str)) {
                    zval site_val;
                    ZVAL_STR(&site_val, zend_string_init("EVAL", 4, 0));
                    zend_hash_add(&suspect_site_table, site_key_str, &site_val);
                    printf("已将 EVAL 调用点添加到 suspect_site_table: %s\n", site_key);
                }
                zend_string_release(site_key_str);
            }
        }
        /* 建议2：解析 assert_fail / probe_hit 日志 */
        else if (strstr(buf, "\"type\":\"assert_fail\"") || strstr(buf, "\"type\":\"probe_hit\"")) {
            char line_str[64] = {0};
            char callee[256] = {0};
            extract_json_string_field(buf, "line", line_str, sizeof(line_str));
            extract_json_string_field(buf, "callee", callee, sizeof(callee));
            
            printf("检测到断言失败/探针命中: line=%s, callee=%s\n", line_str, callee);
            
            /* 构建 key: "file:line" */
            char site_key[512] = {0};
            if (current_filename) {
                snprintf(site_key, sizeof(site_key), "%s:%s",
                         ZSTR_VAL(current_filename), line_str);
            } else {
                snprintf(site_key, sizeof(site_key), "?:%s", line_str);
            }
            
            zend_string *site_key_str = zend_string_init(site_key, strlen(site_key), 0);
            if (!zend_hash_exists(&suspect_site_table, site_key_str)) {
                zval site_val;
                /* 可以把 callee 写进去，如 "ASSERT_FAIL(eval)" */
                char reason_buf[512] = {0};
                if (strlen(callee) > 0) {
                    snprintf(reason_buf, sizeof(reason_buf), "ASSERT_FAIL(%s)", callee);
                } else {
                    snprintf(reason_buf, sizeof(reason_buf), "ASSERT_FAIL");
                }
                zend_string *reason = zend_string_init(reason_buf, strlen(reason_buf), 0);
                ZVAL_STR(&site_val, reason);
                zend_hash_add(&suspect_site_table, site_key_str, &site_val);
                printf("已将断言失败点添加到 suspect_site_table: %s\n", site_key);
            }
            zend_string_release(site_key_str);
            
            /* ★★ 关键：这里直接打标记，后面判定用 */
            dynamic_webshell_hit++;
            printf("动态断言命中计数: %d\n", dynamic_webshell_hit);
        }
    }
    
    fclose(fp);
    
    if (line_count > 0) {
        printf("已处理 %d 条动态日志记录\n", line_count);
    } else {
        printf("动态日志文件为空或格式不正确\n");
    }
}

// 4. 导出AST并生成新脚本
void export_and_run(zend_ast *ast, const char *src_filename) {
    if (!ast) {
        printf("警告: AST为空，跳过导出\n");
        return;
    }
    
    // 导出AST为PHP代码，并在开头添加 __yz_runtime_probe 函数定义
    const char *probe_function = 
        "<?php\n"
        "// 动态探针函数：检查参数是否可疑\n"
        "function __yz_runtime_probe($type, $file, $line, $func, $callee = null, $arg = null) {\n"
        "    $log_file = '/tmp/yz_assert_log.jsonl';\n"
        "    $suspicious = false;\n"
        "    $reason = '';\n"
        "    \n"
        "    // 检查参数是否来自用户输入\n"
        "    $is_tainted = false;\n"
        "    if ($arg !== null) {\n"
        "        $arg_str = is_string($arg) ? $arg : (string)$arg;\n"
        "        // 简单检查：是否包含典型webshell特征\n"
        "        $webshell_patterns = ['eval', 'assert', 'system', 'exec', 'shell_exec', 'passthru', 'base64_decode', 'gzinflate', 'str_rot13'];\n"
        "        foreach ($webshell_patterns as $pattern) {\n"
        "            if (stripos($arg_str, $pattern) !== false) {\n"
        "                $suspicious = true;\n"
        "                $reason = 'tainted user payload with code: ' . substr($arg_str, 0, 100);\n"
        "                break;\n"
        "            }\n"
        "        }\n"
        "        // 检查是否来自超全局变量\n"
        "        foreach (['_GET', '_POST', '_REQUEST', '_COOKIE', '_FILES'] as $super) {\n"
        "            if (isset($GLOBALS[$super]) && is_array($GLOBALS[$super])) {\n"
        "                foreach ($GLOBALS[$super] as $val) {\n"
        "                    if (is_string($val) && strpos($arg_str, $val) !== false) {\n"
        "                        $is_tainted = true;\n"
        "                        break 2;\n"
        "                    }\n"
        "                }\n"
        "            }\n"
        "        }\n"
        "    }\n"
        "    \n"
        "    // 检查函数名是否危险\n"
        "    if ($callee !== null) {\n"
        "        $callee_str = is_string($callee) ? $callee : (string)$callee;\n"
        "        $dangerous_funcs = ['eval', 'assert', 'exec', 'shell_exec', 'system', 'preg_replace', 'file_put_contents', 'fwrite', 'fputs', 'call_user_func_array', 'array_map', 'copy', 'call_user_func'];\n"
        "        if (in_array(strtolower($callee_str), $dangerous_funcs)) {\n"
        "            $suspicious = true;\n"
        "            if (empty($reason)) {\n"
        "                $reason = 'dangerous function: ' . $callee_str;\n"
        "            }\n"
        "        }\n"
        "    }\n"
        "    \n"
        "    // 如果可疑，记录日志并返回false（触发assert失败）\n"
        "    if ($suspicious || ($is_tainted && $arg !== null)) {\n"
        "        $log_entry = json_encode([\n"
        "            'type' => 'assert_fail',\n"
        "            'file' => $file,\n"
        "            'line' => $line,\n"
        "            'caller' => $func ?: '__main__',\n"
        "            'callee' => $callee ? (is_string($callee) ? $callee : (string)$callee) : null,\n"
        "            'reason' => $reason ?: 'suspicious parameter detected',\n"
        "            'score' => 0.9\n"
        "        ]) . \"\\n\";\n"
        "        file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);\n"
        "        return false;  // 触发assert失败，终止执行\n"
        "    }\n"
        "    \n"
        "    // 安全，返回true\n"
        "    return true;\n"
        "}\n"
        "\n";
    
    const char *suffix = "\n";
    zend_string *generated_code = zend_ast_export(probe_function, ast, suffix);
    
    if (!generated_code) {
        printf("警告: AST导出失败，跳过文件生成\n");
        return;
    }

    // 只取文件名部分
    const char *base = strrchr(src_filename, '/');
    base = base ? base + 1 : src_filename;

    // 拼接新文件名
    const char *dir = "/home/yz/Desktop";
    char filename[512];
    snprintf(filename, sizeof(filename), "%s/%s_test.php", dir, base);

    // 写入临时文件
    FILE *fp = fopen(filename, "w");
    if (!fp) {
        printf("警告: 无法写入文件 %s，跳过导出\n", filename);
        zend_string_release(generated_code);
        return;
    }
    fwrite(ZSTR_VAL(generated_code), ZSTR_LEN(generated_code), 1, fp);
    fclose(fp);

    // 建议3：在沙箱环境中执行生成的脚本（用于动态补充调用图）
    printf("正在沙箱执行插桩后的脚本以收集动态调用信息...\n");
    char command[1024];
    /* 添加沙箱限制：
     * - disable_functions: 禁用危险系统调用
     * - max_execution_time: 限制执行时间（3秒）
     * - memory_limit: 限制内存（32M）
     * - 重定向输出到日志文件
     */
    snprintf(command, sizeof(command),
             "php -d disable_functions=system,exec,shell_exec,passthru,popen,proc_open,"
             "pcntl_exec,proc_open,proc_get_status,proc_nice,proc_terminate "
             "-d max_execution_time=3 "
             "-d memory_limit=32M "
             "%s > /tmp/yz_php_stdout.log 2>&1",
             filename);
    int ret = system(command);
    if (ret != 0) {
        printf("警告: 脚本执行返回非零退出码 %d（可能是防御逻辑触发了 exit 或超时）\n", ret);
    } else {
        printf("脚本执行完成\n");
    }

    // 清理资源
    zend_string_release(generated_code);
}

// 全局变量，用于在段错误处理中记录文件信息
static size_t g_file_size_on_segfault = 0;
static size_t g_file_lines_on_segfault = 0;
static const char* g_file_name_on_segfault = NULL;

// 段错误处理函数
static void segfault_handler(int sig) {
    printf("\n错误: 程序在处理文件时发生段错误（Segmentation Fault）\n");
    printf("可能原因:\n");
    printf("  1. 文件包含超长的字符串字面量（如超长base64编码）\n");
    printf("  2. 词法分析器缓冲区溢出\n");
    printf("  3. 文件格式异常或损坏\n");
    if (g_file_size_on_segfault > 0) {
        printf("文件信息: 大小 %zu 字节", g_file_size_on_segfault);
        if (g_file_lines_on_segfault > 0) {
            printf("，约 %zu 行", g_file_lines_on_segfault);
        }
        printf("\n");
    }
    if (g_file_name_on_segfault) {
        printf("文件路径: %s\n", g_file_name_on_segfault);
    }
    printf("\n========================================\n");
    printf("检测结果: 无法处理（词法分析器限制）\n");
    printf("========================================\n");
    if (g_file_name_on_segfault) {
        printf("文件: %s\n", g_file_name_on_segfault);
    }
    printf("原因: 词法分析器在处理文件时崩溃（段错误）\n");
    printf("建议: 检查文件内容，或使用其他检测工具\n");
    exit(1);
}
  
int main(int argc, char *argv[]) {
  int a = 0;
  int i;

  // 在程序开始时就设置信号处理器，捕获段错误
  signal(SIGSEGV, segfault_handler);

  // 检查命令行参数
  if (argc < 2) {
    printf("Usage: %s <php_file>\n", argv[0]);
    printf("检测PHP文件是否为Webshell\n");
    return 1;
  }

  // 记录文件名到全局变量（用于段错误处理）
  g_file_name_on_segfault = argv[1];

  // 检查文件是否存在并获取文件大小
  FILE *test_file = fopen(argv[1], "rb");
  if (!test_file) {
    printf("错误: 无法打开文件 '%s'\n", argv[1]);
    return 1;
  }
  
  // 获取文件大小
  fseek(test_file, 0, SEEK_END);
  long file_size_check = ftell(test_file);
  fclose(test_file);
  
  // 提前检查文件大小，对于超大文件直接拒绝
  if (file_size_check > 5 * 1024 * 1024) {  // 5MB
    printf("========================================\n");
    printf("PHP WebShell 检测工具\n");
    printf("========================================\n");
    printf("正在分析文件: %s\n", argv[1]);
    printf("----------------------------------------\n");
    printf("错误: 文件过大（%ld 字节，超过 5MB），无法处理\n", file_size_check);
    printf("可能原因: 文件过大，超出词法分析器处理能力\n");
    printf("\n========================================\n");
    printf("检测结果: 无法处理（文件过大）\n");
    printf("========================================\n");
    printf("文件: %s\n", argv[1]);
    printf("原因: 文件大小超出处理限制（5MB）\n");
    printf("建议: 使用其他检测工具或预处理文件\n");
    return 1;
  }

  printf("========================================\n");
  printf("PHP WebShell 检测工具\n");
  printf("========================================\n");
  printf("正在分析文件: %s\n", argv[1]);
  printf("----------------------------------------\n");

        start_memory_manager();
        zend_interned_strings_init();

        zend_ast *ast;
        zend_arena *ast_arena;

/*
        FILE *file = fopen(argv[1], "r");

        fseek(file, 0, SEEK_END);
        int size = ftell(file);
        fseek(file, 0, SEEK_SET);
        char *source = (char *)malloc(sizeof(char) * size + 1);
        fread(source, 1, size, file);
        fclose(file);
        source[size] = '\0';
        printf("file name is %s\n", argv[1]);
        printf("file size is %d\n", size);
        //printf("code is %s\n", source);

        zend_string *filename = zend_string_init(argv[1], strlen(argv[1]),0);
        zend_string *code = zend_string_init(source, strlen(source) - 1, 0);
        printf("code is %s\n", code->val);

*/

    FILE *file = fopen(argv[1], "rb");
    struct stat st;
    fstat(fileno(file), &st);
    size_t file_size = st.st_size;
    char *source = NULL;
    size_t bytes_read = 0;
    if (file_size > 0) {
        source = malloc(file_size + 1);
        bytes_read = fread(source, 1, file_size, file);
    } else {
        source = malloc(1);
        if (source) *source = '\0';
        bytes_read = 0;
    }
    fclose(file);
    source[bytes_read] = '\0';
    zend_string *filename = zend_string_init(argv[1], strlen(argv[1]),0);
    zend_string *code = zend_string_init(source, bytes_read, 0);
    current_filename = zend_string_copy(filename);
    free(source);

        zend_hash_init(&tainted_table, 64, NULL, NULL, 1);
        zend_hash_init(&local_tainted_table, 64, NULL, NULL, 1);

        zend_hash_init(&var_source_table, 64, NULL, NULL, 1);
        zend_hash_init(&func_source_table, 64, NULL, NULL, 1);

        zend_hash_init(&sink_table, 64, NULL, NULL, 1);
        zend_hash_init(&sink_var_table, 64, NULL, NULL, 1);
        zend_hash_init(&var_value_table, 64, NULL, ZVAL_PTR_DTOR, 0);
        zend_hash_init(&sink_func_table, 64, NULL, NULL, 1);
        zend_hash_init(&local_sink_table, 64, NULL, NULL, 1);

        zend_hash_init(&webshell_table, 64, NULL, NULL, 1);
        //suspect_site_table 初始化
        zend_hash_init(&suspect_site_table, 8, NULL, ZVAL_PTR_DTOR, 0);
        //call_graph_extra 初始化（动态补充的调用图边）
        zend_hash_init(&call_graph_extra, 8, NULL, ZVAL_PTR_DTOR, 0);
        //call_graph_static 初始化（静态调用图）
        zend_hash_init(&call_graph_static, 8, NULL, ZVAL_PTR_DTOR, 0);

        int var_source_num = 6;
        char *var_source[6] = {"_POST", "_GET", "_REQUEST", "_COOKIE", "_FILES", "_SERVER"};

        for (i = 0;i < var_source_num;i++) {
          zend_string *string_var = zend_string_init(var_source[i], strlen(var_source[i]), 0);
          zval index_val;
          ZVAL_LONG(&index_val, i+1);
          zend_hash_add(&var_source_table, string_var, &index_val);
        }

        int func_source_num = 4;
        char *func_source[4] = {"file_get_contents", "fopen", "fread", "getallheaders"};

        for (i = 0;i < func_source_num;i++) {
          zend_string *string_var = zend_string_init(func_source[i], strlen(func_source[i]), 0);
          zval index_val;
          ZVAL_LONG(&index_val, i+1);
          zend_hash_add(&func_source_table, string_var, &index_val);
        }

        func_source_count = func_source_num;

        int sink_num = 31;
        char *sink_name[31] = {"eval", "assert", "exec", "shell_exec", "system", "preg_replace", "file_put_contents", "fwrite", "fputs", "call_user_func_array", "array_map", "copy", "call_user_func", "array_filter", "array_walk", "array_walk_recursive", "register_tick_function", "eval_r", "create_function", "uasort", "array_udiff_assoc", "forward_static_call_array", "uksort", "array_reduce", "register_shutdown_function", "filter_var", "filter_var_array", "preg_replace_callback", "mb_ereg_replace_callback", "popen", "yaml_parse"};

        for (i = 0;i < sink_num;i++) {
          zend_string *string_var = zend_string_init(sink_name[i], strlen(sink_name[i]), 0);
          zval index_val;
          ZVAL_LONG(&index_val, i+1);
          zend_hash_add(&sink_table, string_var, &index_val);
        }

        sink_count = sink_num;

        printf("正在编译PHP代码到AST...\n");
        
        // 更新全局变量（用于段错误处理）
        g_file_size_on_segfault = file_size;
        g_file_lines_on_segfault = 0;
        
        // 检查文件大小和行数，避免词法分析器处理超大文件时崩溃
        // 对于大文件，简化检查以避免在检查过程中崩溃
        size_t line_count_estimate = 0;
        size_t check_limit = bytes_read;
        
        // 对于大文件（>500KB），只检查前100KB来估算行数，避免全文件扫描导致崩溃
        if (file_size > 500 * 1024) {
            check_limit = 100 * 1024;  // 只检查前100KB
            printf("警告: 文件较大 (%zu 字节)，将进行简化检查\n", file_size);
        }
        
        for (size_t i = 0; i < check_limit; i++) {
            if (source[i] == '\n') {
                line_count_estimate++;
            }
        }
        
        // 如果只检查了部分文件，估算总行数
        if (check_limit < bytes_read) {
            line_count_estimate = (line_count_estimate * bytes_read) / check_limit;
        }
        
        g_file_lines_on_segfault = line_count_estimate;
        
        if (file_size > 1 * 1024 * 1024) {  // 1MB
            printf("警告: 文件较大 (%zu 字节，约 %zu 行)，词法分析可能需要较长时间\n", 
                   file_size, line_count_estimate);
        }
        
        // 检查行数，如果行数过多也可能导致问题
        if (line_count_estimate > 10000) {
            printf("警告: 文件行数较多（约 %zu 行），可能导致词法分析器处理困难\n", line_count_estimate);
            // 对于超大文件，直接拒绝处理
            if (line_count_estimate > 20000 || file_size > 2 * 1024 * 1024) {
                printf("\n========================================\n");
                printf("检测结果: 无法处理（文件过大）\n");
                printf("========================================\n");
                printf("文件: %s\n", ZSTR_VAL(filename));
                printf("原因: 文件过大（%zu 字节，约 %zu 行），超出词法分析器处理能力\n", 
                       file_size, line_count_estimate);
                printf("建议: 使用其他检测工具或预处理文件\n");
                zend_string_release(code);
                zend_string_release(filename);
                return 1;
            }
        }
        
        // 检查是否有超长的字符串字面量（可能导致词法分析器崩溃）
        // 对于大文件，简化字符串检查，只检查前100KB
        size_t max_string_length = 0;
        size_t current_string_length = 0;
        int in_string = 0;
        int in_single_quote = 0;
        int in_double_quote = 0;
        int line_count = 0;
        int max_line_count = 0;
        char quote_char = 0;
        int has_variable_interpolation = 0;
        
        // 限制字符串检查的范围，避免大文件导致崩溃
        size_t string_check_limit = (file_size > 500 * 1024) ? 100 * 1024 : bytes_read;
        
        for (size_t i = 0; i < string_check_limit; i++) {
            // 处理换行符
            if (source[i] == '\n') {
                if (in_string) {
                    line_count++;
                }
            }
            
            if (!in_string) {
                // 检查是否是字符串开始
                if (source[i] == '"') {
                    in_string = 1;
                    in_double_quote = 1;
                    quote_char = '"';
                    current_string_length = 1;
                    line_count = 1;
                    has_variable_interpolation = 0;
                } else if (source[i] == '\'') {
                    in_string = 1;
                    in_single_quote = 1;
                    quote_char = '\'';
                    current_string_length = 1;
                    line_count = 1;
                    has_variable_interpolation = 0;
                }
            } else {
                current_string_length++;
                
                // 检查变量插值（双引号字符串中）
                if (in_double_quote && i > 0 && source[i-1] != '\\') {
                    if (source[i] == '$' || (source[i] == '.' && i > 0 && source[i-1] == '"')) {
                        has_variable_interpolation = 1;
                    }
                }
                
                // 检查字符串结束
                if (source[i] == quote_char) {
                    // 检查是否是转义的引号（需要检查前一个字符是否是反斜杠）
                    int is_escaped = 0;
                    if (i > 0 && source[i-1] == '\\') {
                        // 检查是否是双重转义（\\"）
                        if (i > 1 && source[i-2] == '\\') {
                            is_escaped = 0;  // \\" 表示转义的反斜杠+引号，引号未转义
                        } else {
                            is_escaped = 1;  // \" 表示转义的引号
                        }
                    }
                    
                    if (!is_escaped) {
                        // 对于双引号，检查是否是变量插值的结束（如 ".$var."）
                        // 格式：字符串结束引号后跟点号，然后是变量或另一个字符串
                        if (quote_char == '"' && i + 1 < bytes_read) {
                            // 跳过空白字符
                            size_t j = i + 1;
                            while (j < bytes_read && (source[j] == ' ' || source[j] == '\t' || source[j] == '\n' || source[j] == '\r')) {
                                j++;
                            }
                            
                            // 检查 ".$var." 或 "string".$var."string" 模式
                            if (j < bytes_read && (source[j] == '.' || source[j] == '$')) {
                                // 可能是变量插值，继续处理字符串（不结束字符串）
                                continue;
                            }
                        }
                        
                        // 字符串真正结束
                        if (current_string_length > max_string_length) {
                            max_string_length = current_string_length;
                            max_line_count = line_count;
                        }
                        
                        // 检查是否是有问题的字符串
                        if (current_string_length > 5000 || line_count > 10) {
                            printf("警告: 检测到复杂字符串字面量（长度: %zu 字节，跨 %d 行）\n", 
                                   current_string_length, line_count);
                            if (has_variable_interpolation) {
                                printf("  包含变量插值，可能导致词法分析器处理困难\n");
                            }
                        }
                        
                        in_string = 0;
                        in_single_quote = 0;
                        in_double_quote = 0;
                        current_string_length = 0;
                        line_count = 0;
                        has_variable_interpolation = 0;
                    }
                }
            }
        }
        
        // 如果字符串没有正确结束，也可能导致问题
        if (in_string) {
            printf("错误: 检测到未闭合的字符串字面量（可能跨多行，长度: %zu 字节）\n", current_string_length);
            printf("可能原因: 多行字符串或字符串中包含复杂内容\n");
            printf("此类文件可能导致词法分析器崩溃，无法继续处理\n");
            printf("建议: 请检查文件内容，或使用其他检测工具\n");
            zend_string_release(code);
            zend_string_release(filename);
            return 1;
        }
        
        // 检查是否包含可能导致段错误的字符串
        int should_skip = 0;
        if (max_string_length > 100000) {  // 100KB
            printf("错误: 检测到超长字符串字面量（%zu 字节，跨 %d 行），可能导致词法分析器崩溃\n", 
                   max_string_length, max_line_count);
            printf("可能原因: 文件包含超长的base64编码或其他编码字符串\n");
            printf("此类文件已知会导致段错误，跳过词法分析以避免崩溃\n");
            should_skip = 1;
        } else if (max_string_length > 5000 && max_line_count > 10) {
            // 检测到较长的多行字符串（>5KB 且跨 >10 行），特别是包含变量插值的
            printf("错误: 检测到复杂的多行字符串字面量（长度: %zu 字节，跨 %d 行）\n", 
                   max_string_length, max_line_count);
            printf("可能原因: 字符串包含HTML/CSS/JavaScript代码或变量插值\n");
            printf("此类文件在词法分析阶段已知会导致段错误，跳过词法分析以避免崩溃\n");
            printf("建议: 请使用其他检测工具或预处理文件\n");
            should_skip = 1;
        } else if (max_string_length > 10000 && max_line_count > 5) {
            printf("警告: 检测到较长的多行字符串字面量（%zu 字节，跨 %d 行）\n", 
                   max_string_length, max_line_count);
            printf("可能原因: 字符串包含HTML/CSS/JavaScript代码或变量插值\n");
            printf("建议: 此类文件可能导致词法分析器处理困难，可能发生段错误\n");
        }
        
        if (should_skip) {
            // 不调用词法分析器，直接返回错误
            printf("\n========================================\n");
            printf("检测结果: 无法处理（词法分析器限制）\n");
            printf("========================================\n");
            printf("文件: %s\n", ZSTR_VAL(filename));
            printf("原因: 文件包含可能导致词法分析器崩溃的复杂字符串\n");
            printf("建议: 使用其他检测工具或预处理文件后再检测\n");
            zend_string_release(code);
            zend_string_release(filename);
            return 1;
        }
        
        // 信号处理器已在程序开始时设置，这里只需要更新文件信息
        g_file_size_on_segfault = file_size;
        g_file_lines_on_segfault = line_count_estimate;
        g_file_name_on_segfault = ZSTR_VAL(filename);
        
        // 启用短标签支持（<? 和 <?=）
        CG(short_tags) = 1;
        
        // 尝试进行词法分析
        printf("正在尝试词法分析（文件大小: %zu 字节，约 %zu 行）...\n", file_size, line_count_estimate);
        ast = zend_compile_string_to_ast(code, &ast_arena, filename);
        
        // 词法分析成功后，清除段错误处理中的文件信息
        g_file_size_on_segfault = 0;
        g_file_lines_on_segfault = 0;
        g_file_name_on_segfault = NULL;
        
        // 检查词法分析是否成功
        if (ast == NULL) {
            printf("\n错误: 词法分析失败，无法将PHP代码编译为AST\n");
            printf("可能原因:\n");
            printf("  1. PHP代码存在语法错误\n");
            printf("  2. 文件过大或过于复杂，超出词法分析器处理能力\n");
            printf("  3. 文件包含特殊字符或编码问题\n");
            printf("文件信息: 大小 %zu 字节，约 %zu 行\n", file_size, line_count_estimate);
            printf("\n========================================\n");
            printf("检测结果: 无法处理（词法分析失败）\n");
            printf("========================================\n");
            printf("文件: %s\n", ZSTR_VAL(filename));
            printf("原因: 词法分析器无法处理该文件\n");
            printf("建议: 检查文件语法或使用其他检测工具\n");
            zend_string_release(code);
            zend_string_release(filename);
            if (current_filename) {
                zend_string_release(current_filename);
            }
            return 1;
        }

if (ast != NULL) {
    ast->father = NULL;
    g_root_ast = ast;

    // 先初始化 father 指针等
    traverse_ast(g_root_ast);
    
    // 构建静态调用图
    printf("正在构建静态调用图...\n");
    build_static_call_graph(g_root_ast);
    
    dynamic_function_analysis(g_root_ast);

    // 初始化tainted_table并添加已知危险函数
    HashTable var_table;
    zend_hash_init(&var_table, 8, NULL, NULL, 0);

    // 处理AST：此时 father 已经正确，可以安全使用 current->father
    traverse_and_modify_ast(g_root_ast, &ast_arena, &var_table);
    printf("AST插桩完成，重新建立父子关系...\n");
    traverse_ast(g_root_ast);

    // 设置 current_filename 的位置
    if (current_filename) {
        zend_string_release(current_filename);
    }
    current_filename = zend_string_copy(filename);

    const char *skip_probe = getenv("YZ_SKIP_RUNTIME_PROBE");
    if (!skip_probe || strcmp(skip_probe, "1") != 0) {
        printf("执行带有防御逻辑的脚本以辅助动态确认...\n");
        export_and_run(g_root_ast ? g_root_ast : ast, argv[1]);
        
        // ★★ 新增：运行结束后，把 /tmp/yz_dyn_cg.jsonl 中的信息回填到调用图 / sink 表 ★★
        load_dynamic_edges_and_update_graph("/tmp/yz_dyn_cg.jsonl");
    } else {
        printf("检测到环境变量 YZ_SKIP_RUNTIME_PROBE=1，跳过运行时插桩执行。\n");
    }

    // 建议1：合并静态和动态调用图
    printf("正在合并静态和动态调用图...\n");
    merge_call_graphs();

    // 进行污点追踪和Webshell检测
    printf("正在进行污点分析...\n");
    taint_track(g_root_ast ? g_root_ast : ast);
    
    printf("正在进行Sink点分析...\n");
    sink_track(g_root_ast ? g_root_ast : ast, &sink_var_table, &sink_var_count);
    
    // 建议2：基于调用图的全局污点分析
    global_taint_analysis_with_cg();
    
    printf("正在进行Webshell检测...\n");
    webshell_check(g_root_ast ? g_root_ast : ast, 0);
    
    printf("----------------------------------------\n");
    
    /* TODO 2: 在检测结果里单独打印 suspect_site_table */
    printf("动态确认的危险调用点:\n");
    if (zend_hash_num_elements(&suspect_site_table) > 0) {
        zend_string *key;
        zval *val;
        ZEND_HASH_FOREACH_STR_KEY_VAL(&suspect_site_table, key, val) {
            if (key && val && Z_TYPE_P(val) == IS_STRING) {
                printf("  - %s: %s\n", ZSTR_VAL(key), Z_STRVAL_P(val));
            }
        } ZEND_HASH_FOREACH_END();
    } else {
        printf("  (无)\n");
    }
    printf("\n");
    
    /* 打印静态调用图边 */
    printf("静态调用图边:\n");
    if (zend_hash_num_elements(&call_graph_static) > 0) {
        zend_string *caller_key;
        zval *caller_val;
        ZEND_HASH_FOREACH_STR_KEY_VAL(&call_graph_static, caller_key, caller_val) {
            if (caller_key && caller_val && Z_TYPE_P(caller_val) == IS_PTR) {
                HashTable *callee_set = (HashTable *)Z_PTR_P(caller_val);
                if (callee_set && zend_hash_num_elements(callee_set) > 0) {
                    zend_string *callee_key;
                    ZEND_HASH_FOREACH_STR_KEY(callee_set, callee_key) {
                        printf("  - %s -> %s (静态)\n", ZSTR_VAL(caller_key), ZSTR_VAL(callee_key));
                    } ZEND_HASH_FOREACH_END();
                }
            }
        } ZEND_HASH_FOREACH_END();
    } else {
        printf("  (无)\n");
    }
    printf("\n");
    
    /* 打印动态补充的调用图边 */
    printf("动态补充的调用图边:\n");
    if (zend_hash_num_elements(&call_graph_extra) > 0) {
        zend_string *caller_key;
        zval *caller_val;
        ZEND_HASH_FOREACH_STR_KEY_VAL(&call_graph_extra, caller_key, caller_val) {
            if (caller_key && caller_val && Z_TYPE_P(caller_val) == IS_PTR) {
                HashTable *callee_set = (HashTable *)Z_PTR_P(caller_val);
                if (callee_set && zend_hash_num_elements(callee_set) > 0) {
                    zend_string *callee_key;
                    ZEND_HASH_FOREACH_STR_KEY(callee_set, callee_key) {
                        printf("  - %s -> %s (动态)\n", ZSTR_VAL(caller_key), ZSTR_VAL(callee_key));
                    } ZEND_HASH_FOREACH_END();
                }
            }
        } ZEND_HASH_FOREACH_END();
    } else {
        printf("  (无)\n");
    }
    printf("\n");
    
    /* 建议4：在最终webshell结论里，显式考虑 call_graph_extra / suspect_site_table */
    int dynamic_path_found = 0;
    /* 检查动态调用图中是否存在从入口到危险函数的路径 */
    if (zend_hash_num_elements(&call_graph_extra) > 0) {
        zend_string *caller_key;
        zval *caller_val;
        ZEND_HASH_FOREACH_STR_KEY_VAL(&call_graph_extra, caller_key, caller_val) {
            if (caller_key && caller_val && Z_TYPE_P(caller_val) == IS_PTR) {
                HashTable *callee_set = (HashTable *)Z_PTR_P(caller_val);
                if (callee_set) {
                    zend_string *callee_key;
                    ZEND_HASH_FOREACH_STR_KEY(callee_set, callee_key) {
                        if (callee_key && is_known_sink_function(callee_key)) {
                            const char *caller_name = ZSTR_VAL(caller_key);
                            /* 检查是否是入口函数（__main__）或已知的调用者 */
                            if (strcmp(caller_name, "__main__") == 0) {
                                dynamic_path_found = 1;
                                printf("动态确认路径: %s -> %s (通过动态执行补充)\n", 
                                       caller_name, ZSTR_VAL(callee_key));
                            }
                        }
                    } ZEND_HASH_FOREACH_END();
                }
            }
        } ZEND_HASH_FOREACH_END();
    }
    
    /* 建议4：动态断言命中则强制标记为 Webshell */
    if (dynamic_webshell_hit > 0) {
        printf("\n========================================\n");
        printf("动态检测：命中断言 %d 次，判定为 WebShell\n", dynamic_webshell_hit);
        printf("========================================\n");
        webshell = 1;
    }
    
    /* 检查 suspect_site_table 中是否有 ASSERT_FAIL/EVAL/SINK_HIT */
    int suspect_count = 0;
    if (zend_hash_num_elements(&suspect_site_table) > 0) {
        zend_string *key;
        zval *val;
        ZEND_HASH_FOREACH_STR_KEY_VAL(&suspect_site_table, key, val) {
            if (key && val && Z_TYPE_P(val) == IS_STRING) {
                const char *reason = Z_STRVAL_P(val);
                if (strstr(reason, "ASSERT_FAIL") || strstr(reason, "EVAL") || strstr(reason, "SINK_HIT")) {
                    suspect_count++;
                }
            }
        } ZEND_HASH_FOREACH_END();
    }
    
    if (suspect_count > 0 && dynamic_webshell_hit == 0) {
        printf("\n动态检测：发现 %d 处可疑调用点，标记为高危可疑\n", suspect_count);
        /* 可以根据需要决定是否也标记为webshell */
    }
    
    printf("检测结果:\n");
    printf("DEBUG: webshell=%d, dynamic_path_found=%d, global_dynamic_path_detected=%d, dynamic_webshell_hit=%d, suspect_site_table_size=%u\n",
           webshell, dynamic_path_found, global_dynamic_path_detected, dynamic_webshell_hit, 
           zend_hash_num_elements(&suspect_site_table));
    if (webshell || dynamic_path_found || global_dynamic_path_detected || 
        dynamic_webshell_hit > 0 || zend_hash_num_elements(&suspect_site_table) > 0) {
        printf("⚠️  警告: 检测到 WebShell!\n");
        printf("该文件包含危险的代码模式，可能被用于恶意目的。\n");
        if (dynamic_webshell_hit > 0) {
            printf("动态断言拦截到 %d 次可疑调用，直接判定为恶意。\n", dynamic_webshell_hit);
        }
        if (dynamic_path_found) {
            printf("通过动态执行补充调用图，发现从入口到危险函数的调用路径（变量函数形式），因此将该样本判定为 Webshell。\n");
        }
        if (global_dynamic_path_detected) {
            printf("通过调用图路径搜索，发现从入口到危险函数的调用路径。\n");
        }
        if (zend_hash_num_elements(&suspect_site_table) > 0) {
            printf("动态确认了 %u 处危险调用点（eval等）。\n",
                   zend_hash_num_elements(&suspect_site_table));
        }
    } else {
        printf("✓ 未检测到 WebShell\n");
        printf("该文件看起来是正常的PHP代码。\n");
    }
    printf("========================================\n");
 
 //
 
 
    // 清理
    zend_hash_destroy(&var_table);
    // source 已经在前面 free 过了，这里不需要再次 free
    // free(source);  // 删除：避免 double free
    zend_string_release(filename);
    zend_string_release(code);
    
    // 清理哈希表
    zend_hash_destroy(&tainted_table);
    zend_hash_destroy(&local_tainted_table);
    zend_hash_destroy(&var_source_table);
    zend_hash_destroy(&func_source_table);
    zend_hash_destroy(&sink_table);
    zend_hash_destroy(&sink_var_table);
    zend_hash_destroy(&var_value_table);
    zend_hash_destroy(&sink_func_table);
    zend_hash_destroy(&local_sink_table);
    zend_hash_destroy(&webshell_table);
    //suspect_site_table 清理
    zend_hash_destroy(&suspect_site_table);
    //call_graph_extra 清理（需要先清理内部的 HashTable）
    zend_string *caller_key;
    zval *caller_val;
    ZEND_HASH_FOREACH_STR_KEY_VAL(&call_graph_extra, caller_key, caller_val) {
        if (caller_val && Z_TYPE_P(caller_val) == IS_PTR) {
            HashTable *callee_set = (HashTable *)Z_PTR_P(caller_val);
            if (callee_set) {
                zend_hash_destroy(callee_set);
                efree(callee_set);
            }
        }
    } ZEND_HASH_FOREACH_END();
    zend_hash_destroy(&call_graph_extra);
    //call_graph_static 清理（需要先清理内部的 HashTable）
    ZEND_HASH_FOREACH_STR_KEY_VAL(&call_graph_static, caller_key, caller_val) {
        if (caller_val && Z_TYPE_P(caller_val) == IS_PTR) {
            HashTable *callee_set = (HashTable *)Z_PTR_P(caller_val);
            if (callee_set) {
                zend_hash_destroy(callee_set);
                efree(callee_set);
            }
        }
    } ZEND_HASH_FOREACH_END();
    zend_hash_destroy(&call_graph_static);
    //merged_call_graph 清理（需要先清理内部的 HashTable）
    ZEND_HASH_FOREACH_STR_KEY_VAL(&merged_call_graph, caller_key, caller_val) {
        if (caller_val && Z_TYPE_P(caller_val) == IS_PTR) {
            HashTable *callee_set = (HashTable *)Z_PTR_P(caller_val);
            if (callee_set) {
                zend_hash_destroy(callee_set);
                efree(callee_set);
            }
        }
    } ZEND_HASH_FOREACH_END();
    zend_hash_destroy(&merged_call_graph);
} else {
    printf("----------------------------------------\n");
    printf("错误: PHP代码存在语法错误，无法进行分析\n");
    printf("========================================\n");
    return 1;
}

  // 返回适当的退出码：0表示正常，1表示检测到Webshell或错误
  return webshell ? 1 : 0;
}

