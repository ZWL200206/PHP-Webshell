#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PHP WebShell 批量检测脚本
功能：对指定文件夹下的所有PHP文件进行批量检测，并输出Excel格式的检测报告
"""

import os
import subprocess
import re
import sys
from pathlib import Path
from datetime import datetime
import argparse

try:
    import pandas as pd
    from openpyxl import load_workbook
    from openpyxl.styles import PatternFill, Font, Alignment
except ImportError:
    print("错误: 需要安装 pandas 和 openpyxl 库")
    print("请运行: pip install pandas openpyxl")
    sys.exit(1)


class WebShellDetector:
    def __init__(self, detector_path="./webshell_check", timeout=30):
        """
        初始化检测器
        
        Args:
            detector_path: 检测程序路径（编译后的可执行文件）
            timeout: 单个文件检测超时时间（秒）
        """
        self.detector_path = detector_path
        self.timeout = timeout
        
        # 检查检测程序是否存在
        if not os.path.exists(detector_path):
            print(f"错误: 检测程序不存在: {detector_path}")
            print("请先编译 main.c 生成可执行文件，或指定正确的路径")
            sys.exit(1)
    
    def detect_file(self, php_file_path):
        """
        检测单个PHP文件
        
        Args:
            php_file_path: PHP文件路径
            
        Returns:
            dict: 检测结果字典
        """
        result = {
            'file_path': php_file_path,
            'file_name': os.path.basename(php_file_path),
            'is_webshell': False,
            'detection_method': '',
            'details': '',
            'dynamic_assert_hits': 0,
            'suspect_sites': 0,
            'error': None,
            'error_type': None,  # 错误类型：'segfault', 'timeout', 'syntax_error', 'other'
            'exit_code': None
        }
        
        try:
            # 清理临时日志文件（避免上次检测的干扰）
            temp_logs = ['/tmp/yz_assert_log.jsonl', '/tmp/yz_dyn_cg.jsonl', '/tmp/yz_php_stdout.log']
            for log_file in temp_logs:
                if os.path.exists(log_file):
                    try:
                        os.remove(log_file)
                    except:
                        pass
            
            # 调用检测程序
            cmd = [self.detector_path, php_file_path]
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding='utf-8',
                errors='ignore'
            )
            
            try:
                stdout, stderr = process.communicate(timeout=self.timeout)
                result['exit_code'] = process.returncode
            except subprocess.TimeoutExpired:
                process.kill()
                stdout, stderr = process.communicate()
                result['error'] = f"检测超时（>{self.timeout}秒）"
                result['error_type'] = 'timeout'
                result['exit_code'] = -1
                return result
            except Exception as e:
                result['error'] = f"执行错误: {str(e)}"
                result['error_type'] = 'other'
                return result
            
            # 解析输出
            output = stdout + stderr
            
            # 首先检查是否成功检测到WebShell（如果检测成功，说明程序正常运行，不应该再检查段错误）
            # 检查是否检测到WebShell
            if "⚠️  警告: 检测到 WebShell!" in output or "警告: 检测到 WebShell!" in output:
                result['is_webshell'] = True
                result['detection_method'] = '检测到WebShell'
            
            # 解析动态断言命中次数
            assert_match = re.search(r'动态断言拦截到 (\d+) 次可疑调用', output)
            if assert_match:
                result['dynamic_assert_hits'] = int(assert_match.group(1))
                result['is_webshell'] = True
                result['detection_method'] = '动态断言拦截'
            
            # 解析动态检测信息
            if "动态检测：命中断言" in output:
                hit_match = re.search(r'动态检测：命中断言 (\d+) 次', output)
                if hit_match:
                    result['dynamic_assert_hits'] = int(hit_match.group(1))
                    result['is_webshell'] = True
                    result['detection_method'] = '动态断言命中'
            
            # 解析可疑调用点数量
            suspect_match = re.search(r'动态确认了 (\d+) 处危险调用点', output)
            if suspect_match:
                result['suspect_sites'] = int(suspect_match.group(1))
            
            # 解析动态路径检测
            if "通过动态执行补充调用图" in output:
                result['is_webshell'] = True
                if not result['detection_method']:
                    result['detection_method'] = '动态调用图路径'
            
            if "通过调用图路径搜索" in output:
                result['is_webshell'] = True
                if not result['detection_method']:
                    result['detection_method'] = '调用图路径搜索'
            
            # 如果已经成功检测到WebShell，说明程序正常运行，不需要再检查段错误
            if result['is_webshell']:
                # 程序正常运行并检测到WebShell，不需要检查段错误
                pass
            else:
                # 只有在没有检测到WebShell的情况下，才检查段错误和词法分析器限制
                # 检查段错误（Segmentation Fault）和词法分析器限制
                # 1. 通过退出码检测（段错误通常导致负退出码，如 -11 表示 SIGSEGV）
                # 2. 通过输出信息检测
                # 3. 检测修改后的 main.c 输出的"无法处理（词法分析器限制）"信息
                
                # 检查是否是词法分析器限制（修改后的 main.c 会提前退出）
                if "无法处理（词法分析器限制）" in output or \
                   "检测结果: 无法处理（词法分析器限制）" in output or \
                   "此类文件在词法分析阶段已知会导致段错误" in output or \
                   "此类文件已知会导致段错误，跳过词法分析以避免崩溃" in output or \
                   "检测到未闭合的字符串字面量" in output or \
                   "此类文件可能导致词法分析器崩溃，无法继续处理" in output:
                    result['error'] = "无法处理（词法分析器限制）"
                    result['error_type'] = 'segfault'  # 归类为段错误类型
                    result['detection_method'] = '词法分析器限制（无法处理）'
                    # 尝试从输出中提取更多信息
                    if "检测到复杂的多行字符串字面量" in output:
                        result['details'] = "文件包含复杂的多行字符串（包含变量插值或HTML/CSS/JavaScript代码），词法分析器无法处理"
                    elif "检测到超长字符串字面量" in output:
                        result['details'] = "文件包含超长字符串字面量（如超长base64编码），词法分析器无法处理"
                    elif "检测到未闭合的字符串字面量" in output:
                        result['details'] = "文件包含未闭合的字符串字面量，词法分析器无法处理"
                    else:
                        result['details'] = "文件包含可能导致词法分析器崩溃的复杂字符串，已提前退出以避免段错误"
                    return result
                
                # 检查实际的段错误（程序崩溃）
                # 但如果是词法分析器相关的崩溃，应该归类为词法分析器限制
                if "词法分析器缓冲区溢出" in output or \
                   ("词法分析器" in output and ("崩溃" in output or "溢出" in output or "无法处理" in output)):
                    # 词法分析器相关的崩溃，归类为词法分析器限制
                    result['error'] = "无法处理（词法分析器限制）"
                    result['error_type'] = 'segfault'  # 归类为段错误类型，但标记为词法分析器限制
                    result['detection_method'] = '词法分析器限制（无法处理）'
                    if "词法分析器缓冲区溢出" in output:
                        result['details'] = "词法分析器缓冲区溢出，导致程序崩溃"
                    elif "文件包含超长的字符串字面量" in output:
                        result['details'] = "文件包含超长字符串字面量（如超长base64编码），导致词法分析器崩溃"
                    else:
                        result['details'] = "词法分析器在处理文件时崩溃，无法继续处理"
                    return result
                
                # 检查实际的段错误（程序崩溃，非词法分析器相关）
                # 注意：排除警告性信息（如"可能发生段错误"），只检查实际的段错误信息
                if (result['exit_code'] is not None and result['exit_code'] < 0) or \
                   "Segmentation fault" in output or \
                   ("段错误" in output and ("程序在处理文件时发生段错误" in output or "Segmentation Fault" in output)) or \
                   "Segmentation Fault" in output or \
                   "segfault_handler" in output or \
                   "程序在处理文件时发生段错误" in output:
                    result['error'] = "段错误（Segmentation Fault）"
                    result['error_type'] = 'segfault'
                    result['detection_method'] = '段错误（程序崩溃）'
                    # 尝试从输出中提取更多信息
                    if "文件包含超长的字符串字面量" in output:
                        result['details'] = "文件包含超长字符串字面量（如超长base64编码），导致程序崩溃"
                    elif "文件格式异常或损坏" in output:
                        result['details'] = "文件格式异常或损坏"
                    else:
                        result['details'] = "程序在处理文件时发生段错误，可能由于文件过大或包含超长字符串"
                    return result
            
            # 检查退出码（1表示检测到WebShell或错误）
            if result['exit_code'] == 1 and not result['is_webshell'] and not result['error']:
                # 可能是语法错误或其他错误
                if "错误:" in output or "语法错误" in output or "语法" in output:
                    result['error'] = "PHP语法错误或文件无法解析"
                    result['error_type'] = 'syntax_error'
                elif "检测到 WebShell" not in output:
                    # 退出码为1但输出中没有明确说明，可能是其他错误
                    # 检查是否是词法分析器限制（可能已经在上面的检查中处理了，但这里作为后备）
                    if "无法处理" in output or "词法分析器限制" in output:
                        result['error'] = "无法处理（词法分析器限制）"
                        result['error_type'] = 'segfault'
                        result['detection_method'] = '词法分析器限制（无法处理）'
                    else:
                        result['error'] = "检测过程出现错误（退出码1）"
                        result['error_type'] = 'other'
            
            # 提取详细信息
            details_list = []
            if result['dynamic_assert_hits'] > 0:
                details_list.append(f"动态断言命中: {result['dynamic_assert_hits']}次")
            if result['suspect_sites'] > 0:
                details_list.append(f"可疑调用点: {result['suspect_sites']}处")
            if "动态路径" in output:
                details_list.append("发现动态调用路径")
            if result['error']:
                error_msg = result['error']
                if result['error_type'] == 'segfault':
                    error_msg = f"⚠️ 段错误: {error_msg}"
                elif result['error_type'] == 'timeout':
                    error_msg = f"⏱️ 超时: {error_msg}"
                elif result['error_type'] == 'syntax_error':
                    error_msg = f"❌ 语法错误: {error_msg}"
                details_list.append(error_msg)
            
            result['details'] = '; '.join(details_list) if details_list else '无'
            
            # 如果未检测到WebShell
            if not result['is_webshell'] and result['exit_code'] == 0 and not result['error']:
                result['detection_method'] = '未检测到WebShell'
            
        except Exception as e:
            result['error'] = f"检测异常: {str(e)}"
            result['error_type'] = 'other'
        
        return result
    
    def batch_detect(self, folder_path, recursive=False):
        """
        批量检测文件夹下的所有PHP文件
        
        Args:
            folder_path: 文件夹路径
            recursive: 是否递归检测子文件夹
            
        Returns:
            list: 检测结果列表
        """
        results = []
        folder = Path(folder_path)
        
        if not folder.exists():
            print(f"错误: 文件夹不存在: {folder_path}")
            return results
        
        # 收集所有PHP文件
        if recursive:
            php_files = list(folder.rglob("*.php"))
        else:
            php_files = list(folder.glob("*.php"))
        
        if not php_files:
            print(f"警告: 在 {folder_path} 中未找到PHP文件")
            return results
        
        print(f"找到 {len(php_files)} 个PHP文件，开始批量检测...")
        print("=" * 60)
        
        for i, php_file in enumerate(php_files, 1):
            file_path = str(php_file)
            print(f"[{i}/{len(php_files)}] 检测: {file_path}")
            
            result = self.detect_file(file_path)
            results.append(result)
            
            # 显示简要结果
            if result['is_webshell']:
                print(f"  ⚠️  检测到WebShell - {result['detection_method']}")
            elif result['error_type'] == 'segfault':
                # 区分实际的段错误和词法分析器限制
                if "无法处理（词法分析器限制）" in result.get('error', '') or \
                   "词法分析器限制" in result.get('detection_method', ''):
                    print(f"  🟠 无法处理（词法分析器限制）: {result['error']}")
                else:
                    print(f"  🔴 段错误: {result['error']}")
            elif result['error']:
                print(f"  ❌ 错误: {result['error']}")
            else:
                print(f"  ✓ 正常")
            print()
        
        return results
    
    def export_to_excel(self, results, output_file):
        """
        将检测结果导出到Excel文件
        
        Args:
            results: 检测结果列表
            output_file: 输出Excel文件路径
        """
        if not results:
            print("警告: 没有检测结果可导出")
            return
        
        # 准备数据
        data = []
        for result in results:
            # 确定检测结果状态
            if result['error_type'] == 'segfault':
                # 区分实际的段错误和词法分析器限制
                if "无法处理（词法分析器限制）" in result.get('error', '') or \
                   "词法分析器限制" in result.get('detection_method', ''):
                    status = '无法处理（词法分析器限制）'
                else:
                    status = '段错误'
            elif result['error_type'] == 'timeout':
                status = '超时'
            elif result['error_type'] == 'syntax_error':
                status = '语法错误'
            elif result['error']:
                status = '错误'
            elif result['is_webshell']:
                status = 'WebShell'
            else:
                status = '正常'
            
            data.append({
                '文件路径': result['file_path'],
                '文件名': result['file_name'],
                '检测结果': status,
                '检测方法': result['detection_method'],
                '动态断言命中次数': result['dynamic_assert_hits'],
                '可疑调用点数量': result['suspect_sites'],
                '详细信息': result['details'],
                '错误信息': result['error'] if result['error'] else '',
                '错误类型': result['error_type'] if result['error_type'] else '',
                '退出码': result['exit_code']
            })
        
        # 创建DataFrame
        df = pd.DataFrame(data)
        
        # 导出到Excel
        df.to_excel(output_file, index=False, engine='openpyxl')
        
        # 美化Excel格式
        wb = load_workbook(output_file)
        ws = wb.active
        
        # 设置列宽
        column_widths = {
            'A': 50,  # 文件路径
            'B': 30,  # 文件名
            'C': 12,  # 检测结果
            'D': 25,  # 检测方法
            'E': 18,  # 动态断言命中次数
            'F': 18,  # 可疑调用点数量
            'G': 40,  # 详细信息
            'H': 30,  # 错误信息
            'I': 12,  # 错误类型
            'J': 10   # 退出码
        }
        
        for col, width in column_widths.items():
            ws.column_dimensions[col].width = width
        
        # 设置表头样式
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF", size=11)
        
        for cell in ws[1]:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center")
        
        # 设置数据行样式
        webshell_fill = PatternFill(start_color="FFE6E6", end_color="FFE6E6", fill_type="solid")
        normal_fill = PatternFill(start_color="E6F3E6", end_color="E6F3E6", fill_type="solid")
        error_fill = PatternFill(start_color="FFF4E6", end_color="FFF4E6", fill_type="solid")
        segfault_fill = PatternFill(start_color="FFCCCC", end_color="FFCCCC", fill_type="solid")  # 段错误：浅红色
        lexer_limit_fill = PatternFill(start_color="FFB3B3", end_color="FFB3B3", fill_type="solid")  # 词法分析器限制：稍深的红色
        timeout_fill = PatternFill(start_color="FFFFCC", end_color="FFFFCC", fill_type="solid")    # 超时：浅黄色
        syntax_error_fill = PatternFill(start_color="FFE6CC", end_color="FFE6CC", fill_type="solid")  # 语法错误：浅橙色
        
        for row_idx, row in enumerate(ws.iter_rows(min_row=2, max_row=ws.max_row), start=2):
            result_cell = row[2]  # 检测结果列（C列）
            error_type_cell = row[8] if len(row) > 8 else None  # 错误类型列（I列）
            
            if result_cell.value == 'WebShell':
                for cell in row:
                    cell.fill = webshell_fill
            elif result_cell.value == '无法处理（词法分析器限制）':
                for cell in row:
                    cell.fill = lexer_limit_fill
            elif result_cell.value == '段错误':
                for cell in row:
                    cell.fill = segfault_fill
            elif result_cell.value == '超时':
                for cell in row:
                    cell.fill = timeout_fill
            elif result_cell.value == '语法错误':
                for cell in row:
                    cell.fill = syntax_error_fill
            elif result_cell.value == '正常':
                for cell in row:
                    cell.fill = normal_fill
            else:
                for cell in row:
                    cell.fill = error_fill
        
        # 设置文本对齐
        for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
            for cell in row:
                cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
        
        # 冻结首行
        ws.freeze_panes = "A2"
        
        # 保存文件
        wb.save(output_file)
        
        print(f"\n检测结果已导出到: {output_file}")
        
        # 统计信息
        webshell_count = sum(1 for r in results if r['is_webshell'])
        normal_count = sum(1 for r in results if not r['is_webshell'] and not r['error'])
        # 区分实际的段错误和词法分析器限制
        lexer_limit_count = sum(1 for r in results if r['error_type'] == 'segfault' and 
                                ("无法处理（词法分析器限制）" in r.get('error', '') or 
                                 "词法分析器限制" in r.get('detection_method', '')))
        segfault_count = sum(1 for r in results if r['error_type'] == 'segfault' and 
                            not ("无法处理（词法分析器限制）" in r.get('error', '') or 
                                 "词法分析器限制" in r.get('detection_method', '')))
        timeout_count = sum(1 for r in results if r['error_type'] == 'timeout')
        syntax_error_count = sum(1 for r in results if r['error_type'] == 'syntax_error')
        other_error_count = sum(1 for r in results if r['error'] and r['error_type'] not in ['segfault', 'timeout', 'syntax_error'])
        
        print("\n" + "=" * 60)
        print("检测统计:")
        print(f"  总文件数: {len(results)}")
        print(f"  WebShell: {webshell_count}")
        print(f"  正常文件: {normal_count}")
        print(f"  无法处理（词法分析器限制）: {lexer_limit_count}")
        print(f"  段错误（程序崩溃）: {segfault_count}")
        print(f"  超时: {timeout_count}")
        print(f"  语法错误: {syntax_error_count}")
        print(f"  其他错误: {other_error_count}")
        print("=" * 60)


def main():
    parser = argparse.ArgumentParser(
        description='PHP WebShell 批量检测工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 检测当前目录下的PHP文件
  python batch_detect.py -f ./test_files
  
  # 递归检测子文件夹
  python batch_detect.py -f ./test_files -r
  
  # 指定检测程序路径和输出文件
  python batch_detect.py -f ./test_files -d ./webshell_check -o results.xlsx
  
  # 设置超时时间
  python batch_detect.py -f ./test_files -t 60
        """
    )
    
    parser.add_argument('-f', '--folder', required=True,
                       help='要检测的文件夹路径')
    parser.add_argument('-d', '--detector', default='./webshell_check',
                       help='检测程序路径 (默认: ./webshell_check)')
    parser.add_argument('-o', '--output', 
                       default=f'webshell_detection_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx',
                       help='输出Excel文件路径 (默认: webshell_detection_YYYYMMDD_HHMMSS.xlsx)')
    parser.add_argument('-r', '--recursive', action='store_true',
                       help='递归检测子文件夹')
    parser.add_argument('-t', '--timeout', type=int, default=30,
                       help='单个文件检测超时时间（秒，默认: 30）')
    
    args = parser.parse_args()
    
    # 创建检测器
    detector = WebShellDetector(detector_path=args.detector, timeout=args.timeout)
    
    # 批量检测
    results = detector.batch_detect(args.folder, recursive=args.recursive)
    
    if results:
        # 导出到Excel
        detector.export_to_excel(results, args.output)
    else:
        print("没有检测结果")


if __name__ == '__main__':
    main()

