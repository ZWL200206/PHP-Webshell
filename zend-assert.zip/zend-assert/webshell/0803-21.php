<?php
//函数过滤器，学过python的小伙伴一定看的懂，就是将数组中的每个值放到指定的函数中，返回一个只含有true的结果，上方的array_map也和python的map函数基本相像
$arr = array_filert($_GET['func'],array($_GET['a']));
?>